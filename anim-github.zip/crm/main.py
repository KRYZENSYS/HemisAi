#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI-Powered Telegram Business CRM & Cloud Control Hub  (v3)
Faqat Python standart kutubxonasi. Termux uchun.
  python main.py              — hammasi: server + cloudflared tunnel + bot (polling/webhook)
  python main.py setwebhook   — qo'lda webhook ulash (MODE=webhook uchun)
  python main.py info         — webhook holati
"""
import os, sys, re, json, time, hmac, hashlib, sqlite3, threading, base64, uuid, shutil, atexit, subprocess
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl
from datetime import datetime, timezone, timedelta
from collections import defaultdict, deque

# ───────────────────────── Sozlamalar ─────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__))
envf = os.path.join(BASE, ".env")
if os.path.exists(envf):
    for line in open(envf, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            if v.strip():
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
ADMIN_ID = int(os.environ.get("ADMIN_ID", "0") or 0)
PUBLIC_URL_ENV = os.environ.get("PUBLIC_URL", "").rstrip("/")
PUBLIC_URL = PUBLIC_URL_ENV
PORT = int(os.environ.get("PORT", "8080"))
TZ_HOURS = int(os.environ.get("TZ_HOURS", "5"))
MODE = os.environ.get("MODE", "polling").lower()          # polling | webhook
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE, "crm.db"))
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
WEBHOOK_SECRET = hashlib.sha256(("wh:" + BOT_TOKEN).encode()).hexdigest()[:32]
ALLOWED_UPDATES = ["message", "business_connection", "business_message"]
UA = "Mozilla/5.0 (Linux; Android) KryzenCRM/3.0"

SYSTEM_PROMPT = (
    "Sen {owner}ning shaxsiy AI yordamchisisan va Telegram'da unga yozganlarga u nomidan javob berasan. "
    "Qisqa, do'stona va aniq yoz. Foydalanuvchi qaysi tilda yozsa, shu tilda javob ber. "
    "Biznes haqida ma'lumot: {custom_prompt}. "
    "Agar kimdir sendan odammisan yoki bot deb jiddiy so'rasa, AI yordamchi ekaningni ayt. "
    "Pul o'tkazish, parol, kod yoki shaxsiy ma'lumot haqida va'da berma va so'rama; "
    "bunday masalalarda {owner} o'zi javob berishini ayt. Bilmagan narsangni o'ylab topma. "
    "Bugun: {date}, vaqt: {time}."
)

# ───────────────────────── Ma'lumotlar bazasi ─────────────────────────
_lock = threading.Lock()
_conn = sqlite3.connect(DB_PATH, check_same_thread=False)
_conn.row_factory = sqlite3.Row
_conn.executescript("""
CREATE TABLE IF NOT EXISTS connections(
  connection_id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL, user_chat_id INTEGER, owner_name TEXT,
  rights TEXT NOT NULL DEFAULT '{}',
  is_enabled INTEGER NOT NULL DEFAULT 1,
  is_consented INTEGER NOT NULL DEFAULT 0,
  is_consented_funds INTEGER NOT NULL DEFAULT 0,
  ai_enabled INTEGER NOT NULL DEFAULT 1,
  custom_prompt TEXT NOT NULL DEFAULT '',
  handoff_min INTEGER NOT NULL DEFAULT 30,
  created_at TEXT, updated_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_conn_user ON connections(user_id);
CREATE TABLE IF NOT EXISTS audit_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, connection_id TEXT,
  actor TEXT, actor_id INTEGER, action TEXT, detail TEXT, status TEXT DEFAULT 'ok', ts TEXT
);
CREATE INDEX IF NOT EXISTS ix_log_conn ON audit_logs(connection_id, id DESC);
CREATE TABLE IF NOT EXISTS chats(
  connection_id TEXT, chat_id INTEGER, name TEXT, last_ts TEXT,
  ai_off INTEGER NOT NULL DEFAULT 0, paused_until TEXT, msg_count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(connection_id, chat_id)
);
CREATE TABLE IF NOT EXISTS msgs(
  connection_id TEXT, chat_id INTEGER, message_id INTEGER, direction TEXT, ts TEXT,
  PRIMARY KEY(connection_id, chat_id, message_id)
);
""")
for _ddl in ("ALTER TABLE connections ADD COLUMN is_consented_funds INTEGER NOT NULL DEFAULT 0",
             "ALTER TABLE connections ADD COLUMN handoff_min INTEGER NOT NULL DEFAULT 30",
             "ALTER TABLE chats ADD COLUMN ai_off INTEGER NOT NULL DEFAULT 0",
             "ALTER TABLE chats ADD COLUMN paused_until TEXT",
             "ALTER TABLE chats ADD COLUMN msg_count INTEGER NOT NULL DEFAULT 0"):
    try:
        _conn.execute(_ddl)
    except sqlite3.OperationalError:
        pass
_conn.commit()


def q(sql, args=(), fetch=None):
    with _lock:
        cur = _conn.execute(sql, args)
        _conn.commit()
        if fetch == "one":
            r = cur.fetchone()
            return dict(r) if r else None
        if fetch == "all":
            return [dict(r) for r in cur.fetchall()]
        return cur.rowcount


FMT = "%Y-%m-%d %H:%M:%S"


def now_iso():
    return datetime.now(timezone.utc).strftime(FMT)


def log(cid, actor, actor_id, action, detail="", status="ok"):
    q("INSERT INTO audit_logs(connection_id,actor,actor_id,action,detail,status,ts) VALUES(?,?,?,?,?,?,?)",
      (cid, actor, actor_id, action, (detail or "")[:300], status, now_iso()))


def get_conn(cid):
    return q("SELECT * FROM connections WHERE connection_id=?", (cid,), "one")


def user_conn(uid):
    return q("SELECT * FROM connections WHERE user_id=? ORDER BY updated_at DESC LIMIT 1", (uid,), "one")


def save_msg(cid, chat_id, mid, direction):
    q("INSERT OR REPLACE INTO msgs(connection_id,chat_id,message_id,direction,ts) VALUES(?,?,?,?,?)",
      (cid, chat_id, mid, direction, now_iso()))
    q("DELETE FROM msgs WHERE ts < datetime('now','-3 day')")


def touch_chat(cid, chat_id, name, inc=0, paused=None):
    q("INSERT INTO chats(connection_id,chat_id,name,last_ts,msg_count,paused_until) VALUES(?,?,?,?,?,?) "
      "ON CONFLICT(connection_id,chat_id) DO UPDATE SET name=excluded.name,last_ts=excluded.last_ts,"
      "msg_count=chats.msg_count+excluded.msg_count,paused_until=COALESCE(excluded.paused_until,chats.paused_until)",
      (cid, chat_id, name, now_iso(), inc, paused))


def chat_name(chat):
    return (chat.get("first_name", "") + " " + chat.get("last_name", "")).strip() or chat.get("title") \
        or chat.get("username") or str(chat.get("id"))


def pub(c):
    return {"connection_id": c["connection_id"], "owner_name": c["owner_name"],
            "rights": json.loads(c["rights"] or "{}"), "is_enabled": bool(c["is_enabled"]),
            "is_consented": bool(c["is_consented"]), "is_consented_funds": bool(c["is_consented_funds"]),
            "ai_enabled": bool(c["ai_enabled"]), "custom_prompt": c["custom_prompt"],
            "handoff_min": c["handoff_min"]}


def stats_for(cid=None):
    w, a = ("connection_id=? AND ", (cid,)) if cid else ("", ())
    day = "ts >= datetime('now','-1 day')"

    def n(cond):
        return q(f"SELECT COUNT(*) n FROM audit_logs WHERE {w}{cond}", a, "one")["n"]
    out = {"ai_24h": n(f"actor='ai' AND action='auto_reply' AND status='ok' AND {day}"),
           "ai_total": n("actor='ai' AND action='auto_reply' AND status='ok'"),
           "err_24h": n(f"status='error' AND {day}"),
           "admin_24h": n(f"actor='admin' AND {day}")}
    out["chats"] = q("SELECT COUNT(*) n FROM chats" + (" WHERE connection_id=?" if cid else ""), a, "one")["n"]
    return out


# ───────────────────────── Telegram & Groq ─────────────────────────
class ApiError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code, self.msg = code, msg


def _http(url, data=None, headers=None, timeout=30):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read() or b"{}")
        except Exception:
            return {"ok": False, "description": f"HTTP {e.code}"}
    except (urllib.error.URLError, OSError, ValueError) as e:
        return {"ok": False, "description": f"Tarmoq xatosi: {e}"}


def tg(method, payload=None, raw=None, ctype="application/json", timeout=30):
    data = raw if raw is not None else json.dumps(payload or {}).encode()
    res = _http(f"https://api.telegram.org/bot{BOT_TOKEN}/{method}", data, {"Content-Type": ctype}, timeout)
    if not res.get("ok"):
        raise ApiError(400, res.get("description", "Telegram xatosi"))
    return res["result"]


def multipart(fields, files):
    b = uuid.uuid4().hex
    out = []
    for k, v in fields.items():
        out.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    for k, (fn, ct, data) in files.items():
        out.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"; filename="{fn}"\r\n'
                   f'Content-Type: {ct}\r\n\r\n'.encode() + data + b"\r\n")
    out.append(f"--{b}--\r\n".encode())
    return b"".join(out), f"multipart/form-data; boundary={b}"


_hist = defaultdict(lambda: deque(maxlen=8))


def ask_groq(system, hist):
    if not GROQ_API_KEY:
        raise ApiError(500, "GROQ_API_KEY .env da yo'q")
    body = {"model": GROQ_MODEL, "temperature": 0.6, "max_tokens": 400,
            "messages": [{"role": "system", "content": system}] + list(hist)}
    res = _http("https://api.groq.com/openai/v1/chat/completions", json.dumps(body).encode(),
                {"Content-Type": "application/json", "Authorization": f"Bearer {GROQ_API_KEY}", "User-Agent": UA}, 40)
    try:
        return res["choices"][0]["message"]["content"].strip()
    except Exception:
        raise ApiError(502, "Groq xatosi: " + str(res.get("error", res))[:200])


def build_system(c, custom=None):
    t = datetime.now(timezone(timedelta(hours=TZ_HOURS)))
    cp = (c["custom_prompt"] if custom is None else custom) or "kiritilmagan"
    return SYSTEM_PROMPT.format(owner=c["owner_name"], custom_prompt=cp,
                                date=t.strftime("%Y-%m-%d"), time=t.strftime("%H:%M"))


def notify_owner(c, text):
    try:
        tg("sendMessage", {"chat_id": c.get("user_chat_id") or c["user_id"], "text": text})
    except Exception:
        pass


# ───────────────────────── Telegram yangilanishlari ─────────────────────────
def webapp_kb(text="🚀 Panelni ochish"):
    if not PUBLIC_URL:
        return None
    return {"inline_keyboard": [[{"text": text, "web_app": {"url": PUBLIC_URL + "/"}}]]}


def send_text(chat_id, text):
    kb = webapp_kb()
    tg("sendMessage", {"chat_id": chat_id, "text": text, **({"reply_markup": kb} if kb else {})})


def on_business_connection(bc):
    u = bc["user"]
    rights = bc.get("rights") or {"can_reply": bool(bc.get("can_reply", False))}
    owner = (u.get("first_name", "") + " " + u.get("last_name", "")).strip() or u.get("username", "Foydalanuvchi")
    enabled = 1 if bc.get("is_enabled", True) else 0
    cid, ts, rj = bc["id"], now_iso(), json.dumps(rights, sort_keys=True)
    old = get_conn(cid)
    if old:
        changed = json.dumps(json.loads(old["rights"] or "{}"), sort_keys=True) != rj
        q("UPDATE connections SET user_id=?,user_chat_id=?,owner_name=?,rights=?,is_enabled=?,updated_at=?"
          + (",is_consented_funds=0" if changed else "") + " WHERE connection_id=?",
          (u["id"], bc.get("user_chat_id"), owner, rj, enabled, ts, cid))
        log(cid, "system", u["id"], "connection_updated", f"enabled={enabled} rights_changed={changed}")
    else:
        q("INSERT INTO connections(connection_id,user_id,user_chat_id,owner_name,rights,is_enabled,created_at,updated_at)"
          " VALUES(?,?,?,?,?,?,?,?)", (cid, u["id"], bc.get("user_chat_id"), owner, rj, enabled, ts, ts))
        log(cid, "system", u["id"], "connection_created")
    try:
        if not enabled:
            txt = "⚠️ Bot Business profilingizdan uzildi."
        elif not rights.get("can_reply"):
            txt = ("✅ Bot ulandi, lekin «Xabarlarga javob berish» huquqi o'chiq. Telegram → Sozlamalar → Business → "
                   "Chatbots ichida uni yoqing, so'ng paneldan rozilik bering.")
        else:
            txt = "✅ Bot Business profilingizga ulandi. Paneldan rozilik bering va AI'ni sozlang."
        send_text(bc.get("user_chat_id") or u["id"], txt)
    except Exception:
        pass


def on_business_message(m):
    cid = m.get("business_connection_id")
    c = get_conn(cid) if cid else None
    if not c or m.get("sender_business_bot"):          # botning o'z xabari
        return
    frm, chat = m.get("from") or {}, m.get("chat") or {}
    if not chat.get("id"):
        return
    name, mid = chat_name(chat), m.get("message_id")
    if frm.get("id") == c["user_id"]:                  # egasi qo'lda yozdi → AI ma'lum vaqt jim
        if c["handoff_min"] > 0 and mid:
            time.sleep(1.5)
            mine = q("SELECT 1 x FROM msgs WHERE connection_id=? AND chat_id=? AND message_id=? AND direction='out'",
                     (cid, chat["id"], mid), "one")
            if not mine:
                until = (datetime.now(timezone.utc) + timedelta(minutes=c["handoff_min"])).strftime(FMT)
                touch_chat(cid, chat["id"], name, 0, until)
                log(cid, "system", None, "handoff_pause", f"{name}: {c['handoff_min']} daqiqa")
        return
    if frm.get("is_bot"):
        return
    touch_chat(cid, chat["id"], name, 1)
    if mid:
        save_msg(cid, chat["id"], mid, "in")
    text = m.get("text") or m.get("caption")
    rights = json.loads(c["rights"] or "{}")
    if not text or not (c["is_enabled"] and c["is_consented"] and c["ai_enabled"] and rights.get("can_reply")):
        return
    row = q("SELECT ai_off,paused_until FROM chats WHERE connection_id=? AND chat_id=?", (cid, chat["id"]), "one") or {}
    if row.get("ai_off") or (row.get("paused_until") and row["paused_until"] > now_iso()):
        return
    try:
        key = (cid, chat["id"])
        _hist[key].append({"role": "user", "content": text[:2000]})
        try:
            tg("sendChatAction", {"business_connection_id": cid, "chat_id": chat["id"], "action": "typing"})
        except Exception:
            pass
        reply = ask_groq(build_system(c), _hist[key])
        _hist[key].append({"role": "assistant", "content": reply})
        r = tg("sendMessage", {"business_connection_id": cid, "chat_id": chat["id"], "text": reply[:4096]})
        save_msg(cid, chat["id"], r["message_id"], "out")
        log(cid, "ai", None, "auto_reply", f"{name}: {reply}")
    except Exception as e:
        log(cid, "ai", None, "auto_reply", str(getattr(e, "msg", e)), "error")


def cmd_status(m):
    c = user_conn(m["from"]["id"])
    if not c:
        return "Ulanish topilmadi. Telegram → Sozlamalar → Business → Chatbots orqali botni qo'shing."
    r = json.loads(c["rights"] or "{}")
    ok = lambda b: "✅" if b else "❌"
    last = q("SELECT detail,ts FROM audit_logs WHERE connection_id=? AND actor='ai' AND status='error' ORDER BY id DESC LIMIT 1",
             (c["connection_id"],), "one")
    s = (f"{ok(c['is_enabled'])} Ulanish\n{ok(r.get('can_reply'))} «Javob berish» huquqi\n"
         f"{ok(c['is_consented'])} Rozilik\n{ok(c['ai_enabled'])} AI yoqilgan\n"
         f"{ok(GROQ_API_KEY)} Groq kaliti serverda")
    if last:
        s += f"\n\nOxirgi AI xatosi ({last['ts']} UTC):\n{last['detail'][:200]}"
    return s


def handle_update(u):
    try:
        if "business_connection" in u:
            on_business_connection(u["business_connection"])
        elif "business_message" in u:
            on_business_message(u["business_message"])
        elif "message" in u:
            m = u["message"]
            if m["chat"]["type"] != "private":
                return
            t = (m.get("text") or "").split()[0].split("@")[0] if m.get("text") else ""
            if t == "/status":
                send_text(m["chat"]["id"], cmd_status(m))
            elif t in ("/start", "/help", "/panel"):
                send_text(m["chat"]["id"], "👋 Salom! Botni Telegram → Sozlamalar → Business → Chatbots orqali ulang, "
                                           "so'ng panelni oching.\n/status — holatni tekshirish")
    except Exception as e:
        print("update xatosi:", repr(e), file=sys.stderr)


# ───────────────────────── Polling, webhook, tunnel ─────────────────────────
def poll_loop():
    try:
        tg("deleteWebhook", {"drop_pending_updates": False})
    except ApiError as e:
        print("deleteWebhook:", e.msg)
    print("Bot: polling rejimi ishlamoqda")
    off = 0
    while True:
        try:
            for u in tg("getUpdates", {"offset": off, "timeout": 25, "allowed_updates": ALLOWED_UPDATES}, timeout=40):
                off = u["update_id"] + 1
                threading.Thread(target=handle_update, args=(u,), daemon=True).start()
        except ApiError as e:
            print("getUpdates:", e.msg, file=sys.stderr)
            time.sleep(3)
        except Exception as e:
            print("poll xatosi:", repr(e), file=sys.stderr)
            time.sleep(3)


TUN = {"proc": None, "url": ""}


def set_public(url):
    global PUBLIC_URL
    PUBLIC_URL = url.rstrip("/")


def apply_public():
    """Panel tugmasi (va webhook rejimida webhook) joriy HTTPS manzilga ulanadi."""
    try:
        tg("setChatMenuButton", {"menu_button": {"type": "web_app", "text": "Panel",
                                                 "web_app": {"url": PUBLIC_URL + "/"}}})
        if MODE == "webhook":
            tg("setWebhook", {"url": PUBLIC_URL + "/webhook", "secret_token": WEBHOOK_SECRET,
                              "allowed_updates": ALLOWED_UPDATES, "drop_pending_updates": True})
        print("Panel manzili:", PUBLIC_URL)
    except ApiError as e:
        print("apply_public xatosi:", e.msg, file=sys.stderr)


def stop_tunnel():
    p = TUN.get("proc")
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(5)
        except Exception:
            p.kill()
    TUN["proc"] = None


def start_tunnel():
    exe = shutil.which("cloudflared")
    if not exe:
        print("cloudflared topilmadi: pkg install cloudflared", file=sys.stderr)
        return False
    stop_tunnel()
    proc = subprocess.Popen([exe, "tunnel", "--url", f"http://127.0.0.1:{PORT}", "--no-autoupdate"],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    TUN["proc"], found = proc, threading.Event()

    def reader():
        with open(os.path.join(BASE, "tunnel.log"), "w") as lf:
            for line in proc.stdout:
                lf.write(line)
                lf.flush()
                mt = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if mt and not found.is_set():
                    TUN["url"] = mt.group(0)
                    found.set()
    threading.Thread(target=reader, daemon=True).start()
    if not found.wait(60):
        print("Tunnel manzili olinmadi (tunnel.log ni ko'ring)", file=sys.stderr)
        return False
    time.sleep(2)
    return True


def tunnel_supervisor():
    fails = 0
    while True:
        time.sleep(30)
        p = TUN.get("proc")
        dead = p is None or p.poll() is not None
        if not dead:
            try:
                urllib.request.urlopen(urllib.request.Request(PUBLIC_URL + "/health", headers={"User-Agent": UA}),
                                       timeout=10).read()
                fails = 0
            except Exception:
                fails += 1
        if dead or fails >= 3:
            print("Tunnel qayta ishga tushirilmoqda…")
            fails = 0
            if start_tunnel():
                set_public(TUN["url"])
                apply_public()


# ───────────────────────── Web App autentifikatsiya ─────────────────────────
def verify_init(init):
    try:
        p = dict(parse_qsl(init, keep_blank_values=True))
        h = p.pop("hash", "")
        dcs = "\n".join(f"{k}={p[k]}" for k in sorted(p))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest(), h):
            return None
        if time.time() - int(p.get("auth_date", 0)) > 86400 * 3:
            return None
        return json.loads(p["user"])
    except Exception:
        return None


# ───────────────────────── Mijoz API ─────────────────────────
def my_conn(user):
    c = user_conn(user["id"])
    if not c:
        raise ApiError(400, "Ulanish topilmadi")
    return c


def api_me(user, d):
    c = user_conn(user["id"])
    return {"is_admin": user["id"] == ADMIN_ID, "name": user.get("first_name", ""),
            "connection": pub(c) if c else None}


def api_stats(user, d):
    return stats_for(my_conn(user)["connection_id"])


def api_consent(user, d):
    c = my_conn(user)
    if not c["is_enabled"]:
        raise ApiError(400, "Avval botni Business profilingizga ulang")
    v = 1 if d.get("value") else 0
    if v:
        q("UPDATE connections SET is_consented=1,updated_at=? WHERE connection_id=?", (now_iso(), c["connection_id"]))
    else:
        q("UPDATE connections SET is_consented=0,is_consented_funds=0,updated_at=? WHERE connection_id=?",
          (now_iso(), c["connection_id"]))
    log(c["connection_id"], "user", user["id"], "consent_granted" if v else "consent_revoked")
    return {"ok": True}


def api_consent_funds(user, d):
    c = my_conn(user)
    if not c["is_enabled"] or not c["is_consented"]:
        raise ApiError(400, "Avval asosiy rozilikni bering")
    v = 1 if d.get("value") else 0
    q("UPDATE connections SET is_consented_funds=?,updated_at=? WHERE connection_id=?", (v, now_iso(), c["connection_id"]))
    log(c["connection_id"], "user", user["id"], "funds_consent_granted" if v else "funds_consent_revoked")
    return {"ok": True}


def api_settings(user, d):
    c = my_conn(user)
    ai = 1 if d.get("ai_enabled") else 0
    cp = str(d.get("custom_prompt", c["custom_prompt"]))[:2000]
    try:
        ho = max(0, min(1440, int(d.get("handoff_min", c["handoff_min"]))))
    except Exception:
        ho = c["handoff_min"]
    q("UPDATE connections SET ai_enabled=?,custom_prompt=?,handoff_min=?,updated_at=? WHERE connection_id=?",
      (ai, cp, ho, now_iso(), c["connection_id"]))
    log(c["connection_id"], "user", user["id"], "settings_saved", f"ai_enabled={ai} handoff={ho}")
    return {"ok": True}


_last_test = {}


def api_ai_test(user, d):
    c = my_conn(user)
    if time.time() - _last_test.get(user["id"], 0) < 3:
        raise ApiError(429, "Biroz kuting")
    _last_test[user["id"]] = time.time()
    text = str(d.get("text", "")).strip()[:1000]
    if not text:
        raise ApiError(400, "Matn kiriting")
    custom = str(d.get("custom_prompt", c["custom_prompt"]))[:2000]
    return {"reply": ask_groq(build_system(c, custom), [{"role": "user", "content": text}])}


def api_chats(user, d):
    c = my_conn(user)
    rows = q("SELECT chat_id,name,ai_off,paused_until,msg_count,last_ts FROM chats WHERE connection_id=? "
             "ORDER BY last_ts DESC LIMIT 60", (c["connection_id"],), "all")
    now = now_iso()
    for r in rows:
        r["paused"] = bool(r["paused_until"] and r["paused_until"] > now)
    return {"chats": rows}


def api_chat_set(user, d):
    c = my_conn(user)
    cid = int(d.get("chat_id"))
    if "ai_off" in d:
        q("UPDATE chats SET ai_off=? WHERE connection_id=? AND chat_id=?",
          (1 if d["ai_off"] else 0, c["connection_id"], cid))
    if d.get("resume"):
        q("UPDATE chats SET paused_until=NULL WHERE connection_id=? AND chat_id=?", (c["connection_id"], cid))
    log(c["connection_id"], "user", user["id"], "chat_settings", json.dumps(d, ensure_ascii=False))
    return {"ok": True}


def api_logs(user, d):
    c = my_conn(user)
    return {"logs": q("SELECT actor,action,detail,status,ts FROM audit_logs WHERE connection_id=? ORDER BY id DESC LIMIT 100",
                      (c["connection_id"],), "all")}


# ───────────────────────── Admin API ─────────────────────────
def need_admin(user):
    if user["id"] != ADMIN_ID:
        raise ApiError(403, "Faqat Super Admin uchun")


def api_admin_accounts(user, d):
    need_admin(user)
    out = []
    for c in q("SELECT * FROM connections WHERE is_enabled=1 AND is_consented=1 ORDER BY owner_name", fetch="all"):
        p = pub(c)
        p["chats"] = q("SELECT chat_id,name FROM chats WHERE connection_id=? ORDER BY last_ts DESC LIMIT 30",
                       (c["connection_id"],), "all")
        p["msgs"] = q("SELECT chat_id,message_id,direction,ts FROM msgs WHERE connection_id=? ORDER BY ts DESC LIMIT 80",
                      (c["connection_id"],), "all")
        p["stats"] = stats_for(c["connection_id"])
        out.append(p)
    tot = q("SELECT COUNT(*) total, SUM(is_enabled) enabled, SUM(is_consented) consented FROM connections", fetch="one")
    return {"accounts": out, "totals": {k: (v or 0) for k, v in tot.items()}, "stats": stats_for()}


def api_admin_logs(user, d):
    need_admin(user)
    return {"logs": q("SELECT connection_id,actor,action,detail,status,ts FROM audit_logs ORDER BY id DESC LIMIT 150",
                      fetch="all")}


def I(p, key, lo=None, hi=None):
    try:
        v = int(str(p.get(key, "")).strip())
    except Exception:
        raise ApiError(400, f"'{key}' butun son bo'lishi kerak")
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ApiError(400, f"'{key}' noto'g'ri qiymat")
    return v


def S(p, key, maxlen=4096, required=True):
    v = str(p.get(key, "")).strip()
    if required and not v:
        raise ApiError(400, f"'{key}' kerak")
    return v[:maxlen]


def decode_img(raw, jpeg_only=False):
    ctype, raw = "image/jpeg", str(raw)
    if raw.startswith("data:"):
        head, raw = raw.split(",", 1)
        ctype = head[5:].split(";")[0] or ctype
    try:
        blob = base64.b64decode(raw)
    except Exception:
        raise ApiError(400, "Rasm noto'g'ri")
    ok = ("image/jpeg",) if jpeg_only else ("image/jpeg", "image/png")
    if not blob or len(blob) > 5 * 1024 * 1024 or ctype not in ok:
        raise ApiError(400, "Faqat " + ("JPG" if jpeg_only else "JPG/PNG") + ", 5 MB gacha")
    return blob, ctype


def bc(c, **kw):
    return {"business_connection_id": c["connection_id"], **kw}


ACTIONS = {}


def action(name, rights, high=False, notify=True):
    def deco(fn):
        ACTIONS[name] = (rights, high, notify, fn)
        return fn
    return deco


@action("send", ["can_reply"], notify=False)
def a_send(c, p):
    chat = I(p, "chat_id")
    r = tg("sendMessage", bc(c, chat_id=chat, text=S(p, "text")))
    save_msg(c["connection_id"], chat, r["message_id"], "out")
    return {"message_id": r["message_id"]}


@action("edit", ["can_reply"])
def a_edit(c, p):
    return tg("editMessageText", bc(c, chat_id=I(p, "chat_id"), message_id=I(p, "message_id"), text=S(p, "text")))


@action("read", ["can_read_messages"], notify=False)
def a_read(c, p):
    return tg("readBusinessMessage", bc(c, chat_id=I(p, "chat_id"), message_id=I(p, "message_id")))


@action("delete", ["can_delete_sent_messages", "can_delete_all_messages"])
def a_delete(c, p):
    ids = [int(x) for x in S(p, "message_ids").replace(" ", "").split(",") if x.isdigit()][:100]
    if not ids:
        raise ApiError(400, "message_id kiriting")
    return tg("deleteBusinessMessages", bc(c, message_ids=ids))


@action("name", ["can_edit_name"])
def a_name(c, p):
    fn, ln = S(p, "first_name", 64), S(p, "last_name", 64, False)
    r = tg("setBusinessAccountName", bc(c, first_name=fn, last_name=ln))
    q("UPDATE connections SET owner_name=? WHERE connection_id=?", ((fn + " " + ln).strip(), c["connection_id"]))
    return r


@action("bio", ["can_edit_bio"])
def a_bio(c, p):
    return tg("setBusinessAccountBio", bc(c, bio=S(p, "bio", 70, False)))


@action("username", ["can_edit_username"])
def a_username(c, p):
    u = S(p, "username", 32, False).lstrip("@")
    return tg("setBusinessAccountUsername", bc(c, **({"username": u} if u else {})))


@action("photo_set", ["can_edit_profile_photo"])
def a_photo_set(c, p):
    blob, ct = decode_img(p.get("data", ""), jpeg_only=True)
    body, mt = multipart(bc(c, photo=json.dumps({"type": "static", "photo": "attach://pf"}),
                            is_public="true" if p.get("is_public") else "false"), {"pf": ("photo.jpg", ct, blob)})
    return tg("setBusinessAccountProfilePhoto", raw=body, ctype=mt)


@action("photo_remove", ["can_edit_profile_photo"])
def a_photo_remove(c, p):
    return tg("removeBusinessAccountProfilePhoto", bc(c, is_public=bool(p.get("is_public"))))


def _story_fields(c, p, extra=None):
    blob, ct = decode_img(p.get("data", ""))
    f = bc(c, content=json.dumps({"type": "photo", "photo": "attach://sf"}), **(extra or {}))
    cap = S(p, "caption", 200, False)
    if cap:
        f["caption"] = cap
    return multipart(f, {"sf": ("story.jpg", ct, blob)})


@action("story_post", ["can_manage_stories"])
def a_story_post(c, p):
    per = int(p.get("active_period") or 86400)
    body, mt = _story_fields(c, p, {"active_period": per if per in (21600, 43200, 86400, 172800) else 86400})
    return tg("postStory", raw=body, ctype=mt)


@action("story_edit", ["can_manage_stories"])
def a_story_edit(c, p):
    body, mt = _story_fields(c, p, {"story_id": I(p, "story_id")})
    return tg("editStory", raw=body, ctype=mt)


@action("story_delete", ["can_manage_stories"])
def a_story_delete(c, p):
    return tg("deleteStory", bc(c, story_id=I(p, "story_id")))


@action("gift_settings", ["can_change_gift_settings"])
def a_gift_settings(c, p):
    t = p.get("types") or {}
    return tg("setBusinessAccountGiftSettings", bc(
        c, show_gift_button=bool(p.get("show_gift_button")),
        accepted_gift_types={k: bool(t.get(k)) for k in
                             ("unlimited_gifts", "limited_gifts", "unique_gifts", "premium_subscription")}))


@action("balance", ["can_view_gifts_and_stars"], notify=False)
def a_balance(c, p):
    return tg("getBusinessAccountStarBalance", bc(c))


@action("gifts", ["can_view_gifts_and_stars"], notify=False)
def a_gifts(c, p):
    kw = {"limit": 20}
    if str(p.get("offset", "")).strip():
        kw["offset"] = str(p["offset"]).strip()
    return tg("getBusinessAccountGifts", bc(c, **kw))


@action("convert_gift", ["can_convert_gifts_to_stars"], high=True)
def a_convert_gift(c, p):
    return tg("convertGiftToStars", bc(c, owned_gift_id=S(p, "owned_gift_id", 200)))


@action("upgrade_gift", ["can_transfer_and_upgrade_gifts"], high=True)
def a_upgrade_gift(c, p):
    kw = {"keep_original_details": bool(p.get("keep_original_details"))}
    if str(p.get("star_count", "")).strip():
        kw["star_count"] = I(p, "star_count", 0, 100000)
    return tg("upgradeGift", bc(c, owned_gift_id=S(p, "owned_gift_id", 200), **kw))


@action("transfer_gift", ["can_transfer_and_upgrade_gifts"], high=True)
def a_transfer_gift(c, p):
    kw = {}
    if str(p.get("star_count", "")).strip():
        kw["star_count"] = I(p, "star_count", 0, 100000)
    return tg("transferGift", bc(c, owned_gift_id=S(p, "owned_gift_id", 200),
                                 new_owner_chat_id=I(p, "new_owner_chat_id"), **kw))


@action("transfer_stars", ["can_transfer_stars"], high=True)
def a_transfer_stars(c, p):
    return tg("transferBusinessAccountStars", bc(c, star_count=I(p, "star_count", 1, 10000)))


def api_admin_act(user, d):
    need_admin(user)
    name = d.get("action")
    spec = ACTIONS.get(name)
    if not spec:
        raise ApiError(400, "Noma'lum amal")
    rights, high, notify, fn = spec
    c = get_conn(d.get("connection_id", ""))
    if not c:
        raise ApiError(404, "Akkaunt topilmadi")
    if not c["is_enabled"] or not c["is_consented"]:
        raise ApiError(403, "Foydalanuvchi rozilik bermagan yoki ulanish o'chiq")
    have = json.loads(c["rights"] or "{}")
    if not any(have.get(x) for x in rights):
        raise ApiError(403, "Ruxsat berilmagan")
    if high and not c["is_consented_funds"]:
        raise ApiError(403, "Foydalanuvchi bu xavfli amal uchun alohida rozilik bermagan")
    p = d.get("params") or {}
    shown = json.dumps({k: ("<fayl>" if k == "data" else v) for k, v in p.items()}, ensure_ascii=False)
    try:
        res = fn(c, p)
    except ApiError as e:
        log(c["connection_id"], "admin", user["id"], name, f"{shown} | {e.msg}", "error")
        raise
    log(c["connection_id"], "admin", user["id"], name, shown)
    if notify:
        notify_owner(c, f"ℹ️ Admin sizning Business akkauntingizda amal bajardi: {name}")
    return {"ok": True, "result": res}


ROUTES = {
    ("GET", "/api/me"): api_me, ("GET", "/api/stats"): api_stats,
    ("POST", "/api/consent"): api_consent, ("POST", "/api/consent_funds"): api_consent_funds,
    ("POST", "/api/settings"): api_settings, ("POST", "/api/ai/test"): api_ai_test,
    ("GET", "/api/chats"): api_chats, ("POST", "/api/chat_set"): api_chat_set, ("GET", "/api/logs"): api_logs,
    ("GET", "/api/admin/accounts"): api_admin_accounts, ("GET", "/api/admin/logs"): api_admin_logs,
    ("POST", "/api/admin/act"): api_admin_act,
}


# ───────────────────────── HTTP server ─────────────────────────
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 12 * 1024 * 1024:
            raise ApiError(413, "Juda katta")
        return self.rfile.read(n) if n else b""

    def route(self, method):
        try:
            path = self.path.split("?")[0]
            body = self.read_body() if method == "POST" else b""
            if method == "GET" and path == "/":
                return self.send(200, HTML, "text/html; charset=utf-8")
            if method == "GET" and path == "/health":
                return self.send(200, {"ok": True})
            if method == "POST" and path == "/webhook":
                if not hmac.compare_digest(self.headers.get("X-Telegram-Bot-Api-Secret-Token", ""), WEBHOOK_SECRET):
                    return self.send(403, {"error": "forbidden"})
                threading.Thread(target=handle_update, args=(json.loads(body or b"{}"),), daemon=True).start()
                return self.send(200, {"ok": True})
            fn = ROUTES.get((method, path))
            if not fn:
                return self.send(404, {"error": "topilmadi"})
            user = verify_init(self.headers.get("X-Init-Data", ""))
            if not user:
                return self.send(401, {"error": "Panelni Telegram ichidagi «Panel» tugmasi orqali oching"})
            data = json.loads(body) if body else {}
            return self.send(200, fn(user, data))
        except ApiError as e:
            self.send(e.code, {"error": e.msg})
        except Exception as e:
            print("xato:", repr(e), file=sys.stderr)
            self.send(500, {"error": "Server xatosi"})

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")


HTML = r"""<!doctype html><html lang="uz"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#070712"><title>Business CRM</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:#070712;--card:rgba(255,255,255,.055);--bd:rgba(0,229,255,.2);--c1:#00e5ff;--c2:#a855f7;--c3:#ff2bd6;--ok:#34d399;--err:#fb7185;--warn:#fbbf24;--tx:#e8eaf6;--mut:#8b93b8}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
body{background:radial-gradient(800px 480px at 8% -8%,rgba(120,40,220,.28),transparent),radial-gradient(640px 480px at 100% 0,rgba(0,229,255,.14),transparent),var(--bg) fixed;min-height:100vh;
padding:calc(10px + env(safe-area-inset-top,0px)) 12px calc(88px + env(safe-area-inset-bottom,0px));max-width:560px;margin:0 auto}
.hdr{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px}
.logo{font-weight:800;font-size:18px;color:var(--c1);text-shadow:0 0 10px rgba(0,229,255,.7);letter-spacing:.5px}
.mut{color:var(--mut)}.sm{font-size:12px}.b{font-weight:700}
.seg{display:flex;background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:3px}
.seg button{background:none;border:0;color:var(--mut);padding:6px 12px;border-radius:9px;font-weight:700;font-size:13px}
.seg button.on{background:linear-gradient(90deg,var(--c1),var(--c2));color:#05060f}
.card{background:var(--card);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid var(--bd);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 0 18px rgba(0,229,255,.06)}
.h2{font-weight:800;color:var(--c1);margin-bottom:8px;font-size:15px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}
.stat{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:12px}
.stat b{display:block;font-size:24px;color:var(--c1)}
.row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.row:last-child{border-bottom:0}
.chip{display:inline-block;padding:2px 9px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid currentColor}
.ok{color:var(--ok)}.err{color:var(--err)}.warn{color:var(--warn)}
.btn{display:block;width:100%;margin-top:10px;padding:11px 14px;border:0;border-radius:12px;font-weight:800;font-size:14px;color:#05060f;background:linear-gradient(90deg,var(--c1),var(--c2));box-shadow:0 0 14px rgba(0,229,255,.35)}
.btn.ghost{background:transparent;color:var(--c1);border:1px solid var(--c1);box-shadow:none}
.btn.red{background:linear-gradient(90deg,#ff2b6a,#ff7a2b)}
.btn.sm2{width:auto;display:inline-block;padding:6px 10px;font-size:12px;margin:0}
.btn:active{transform:scale(.98)}
.btn[disabled]{opacity:.35;filter:grayscale(1);box-shadow:none}
input,textarea,select{width:100%;margin-top:8px;background:rgba(0,0,0,.45);border:1px solid rgba(0,229,255,.3);border-radius:10px;padding:10px;color:#fff;font:inherit;outline:none}
input:focus,textarea:focus,select:focus{border-color:var(--c3)}
select option{background:#14142a}
input[type=checkbox]{width:auto;margin:0}
label.l{display:flex;align-items:center;gap:10px;margin-top:10px;font-size:14px}
.sw{position:relative;display:inline-block;width:46px;height:26px;flex:none}
.sw input{opacity:0;width:0;height:0;position:absolute}
.sw i{position:absolute;inset:0;background:#2a2d4a;border-radius:999px;transition:.2s}
.sw i:before{content:"";position:absolute;width:20px;height:20px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s}
.sw input:checked+i{background:linear-gradient(90deg,var(--c1),var(--c2))}
.sw input:checked+i:before{transform:translateX(20px)}
.nav{position:fixed;left:0;right:0;bottom:0;display:flex;justify-content:space-around;background:rgba(10,10,26,.92);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-top:1px solid var(--bd);padding:6px 4px calc(6px + env(safe-area-inset-bottom,0px));overflow-x:auto;z-index:20}
.nav button{background:none;border:0;color:var(--mut);display:flex;flex-direction:column;align-items:center;gap:1px;font-size:10px;min-width:56px;padding:4px 2px}
.nav button span{font-size:20px}
.nav button.on{color:var(--c1);text-shadow:0 0 8px rgba(0,229,255,.8)}
.toast{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(90px + env(safe-area-inset-bottom,0px));background:#14142a;border:1px solid var(--c1);padding:10px 16px;border-radius:12px;z-index:50;max-width:90%;font-size:14px;box-shadow:0 0 20px rgba(0,229,255,.3)}
.toast.e{border-color:var(--err)}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.65);display:flex;align-items:center;justify-content:center;z-index:60;padding:20px}
.modal .card{max-width:360px;width:100%;margin:0;background:#12122a}
.steps{padding-left:20px;margin:6px 0}.steps li{margin:6px 0}
.bubble{background:rgba(0,229,255,.1);border:1px solid var(--bd);border-radius:14px;padding:10px 12px;margin-top:10px;white-space:pre-wrap}
.bubble.me{background:rgba(168,85,247,.18);margin-left:30px}
.log{border-bottom:1px solid rgba(255,255,255,.06);padding:7px 0;font-size:12px}
.log div{word-break:break-word;opacity:.8}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
.chips button{background:var(--card);border:1px solid var(--bd);color:var(--tx);border-radius:999px;padding:4px 10px;font-size:12px}
.chips button.on{background:var(--c1);color:#05060f;font-weight:700}
pre{white-space:pre-wrap;word-break:break-all;font-size:11px;margin:0}
.sk{height:70px;border-radius:14px;margin-bottom:12px;background:linear-gradient(90deg,rgba(255,255,255,.04),rgba(255,255,255,.1),rgba(255,255,255,.04));background-size:200% 100%;animation:sk 1.2s infinite}
@keyframes sk{to{background-position:-200% 0}}
.sel{position:sticky;top:0;z-index:10;background:rgba(7,7,18,.9);padding:4px 0 8px}
</style></head><body>
<div id="app"><div class="sk"></div><div class="sk"></div><div class="sk"></div></div>
<script>
let tg=window.Telegram&&window.Telegram.WebApp;
try{tg.ready();tg.expand();tg.setHeaderColor('#070712');tg.setBackgroundColor('#070712')}catch(e){}
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const lt=ts=>{try{return new Date(String(ts).replace(' ','T')+'Z').toLocaleString([],{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}catch(e){return ts}};
const val=id=>{const e=$('#'+id);return e?(e.type=='checkbox'?e.checked:e.value.trim()):''};
const hap=t=>{try{tg.HapticFeedback.notificationOccurred(t)}catch(e){}};
function toast(m,bad){const d=document.createElement('div');d.className='toast'+(bad?' e':'');d.textContent=m;document.body.appendChild(d);hap(bad?'error':'success');setTimeout(()=>d.remove(),3200)}
function confirmBox(msg){return new Promise(res=>{const m=document.createElement('div');m.className='modal';
 m.innerHTML=`<div class="card"><div class="h2">⚠️ Tasdiqlang</div><div>${esc(msg)}</div><button class="btn red" id="y">Ha, bajarish</button><button class="btn ghost" id="n">Bekor qilish</button></div>`;
 document.body.appendChild(m);m.querySelector('#y').onclick=()=>{m.remove();res(true)};m.querySelector('#n').onclick=()=>{m.remove();res(false)}})}
async function api(p,b){
  const ac=new AbortController(),t=setTimeout(()=>ac.abort(),60000);
  try{const r=await fetch(p,{method:b?'POST':'GET',signal:ac.signal,headers:{'Content-Type':'application/json','X-Init-Data':(tg&&tg.initData)||''},body:b?JSON.stringify(b):undefined});
   const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||('Xato '+r.status));return d}
  catch(e){throw new Error(e.name=='AbortError'?'Vaqt tugadi, qayta urinib ko‘ring':e.message)}finally{clearTimeout(t)}
}
const RL={can_reply:'Xabar yuborish/tahrirlash',can_read_messages:'Xabarni o‘qildi deb belgilash',can_delete_sent_messages:'Bot xabarlarini o‘chirish',
can_delete_all_messages:'Barcha xabarlarni o‘chirish',can_edit_name:'Ism/Familiya',can_edit_bio:'Bio',can_edit_profile_photo:'Profil rasmi',
can_edit_username:'Username',can_manage_stories:'Stories',can_view_gifts_and_stars:'Sovg‘a va Stars ko‘rish',
can_change_gift_settings:'Sovg‘a sozlamalari',can_convert_gifts_to_stars:'Sovg‘ani Stars’ga aylantirish',
can_transfer_and_upgrade_gifts:'Sovg‘a o‘tkazish/yangilash',can_transfer_stars:'Stars o‘tkazish'};
const FUND=['can_convert_gifts_to_stars','can_transfer_and_upgrade_gifts','can_transfer_stars'];
const NAV={client:[['home','🏠','Bosh'],['ai','🤖','AI'],['chats','💬','Chatlar'],['sec','🛡','Xavfsizlik'],['log','📜','Tarix']],
 admin:[['acc','👥','Akkaunt'],['msg','✉️','Xabar'],['prof','🪪','Profil'],['story','📸','Story'],['gift','🎁','Sovg‘a'],['alog','📜','Log']]};
const S={mode:'client',page:'home',me:null,stats:null,chats:null,logs:null,filter:'all',acc:null,sel:null,alogs:null,gchat:''};
const CUR=()=>S.acc&&S.acc.accounts.find(x=>x.connection_id===S.sel);

/* ───── umumiy render ───── */
function header(){return `<div class="hdr"><div><div class="logo">⚡ BUSINESS CRM</div><div class="mut sm">AI Hub · ${esc(S.me.name)}</div></div>
 ${S.me.is_admin?`<div class="seg"><button data-a="mode" data-v="client" class="${S.mode=='client'?'on':''}">Mijoz</button><button data-a="mode" data-v="admin" class="${S.mode=='admin'?'on':''}">Admin</button></div>`:''}</div>`}
function nav(){return `<div class="nav">${NAV[S.mode].map(n=>`<button data-a="go" data-v="${n[0]}" class="${S.page==n[0]?'on':''}"><span>${n[1]}</span>${n[2]}</button>`).join('')}</div>`}
function render(body){$('#app').innerHTML=header()+(body??PAGES[S.mode+':'+S.page]())+nav()}
async function load(){
  const k=S.mode+':'+S.page;
  if(S.mode=='client'){
    if(!S.me.connection)return;
    if(S.page=='home')S.stats=await api('/api/stats');
    if(S.page=='chats')S.chats=(await api('/api/chats')).chats;
    if(S.page=='log')S.logs=(await api('/api/logs')).logs;
  }else{
    if(['acc','msg','prof','story','gift'].includes(S.page)){S.acc=await api('/api/admin/accounts');if(!CUR()&&S.acc.accounts.length)S.sel=S.acc.accounts[0].connection_id}
    if(S.page=='alog')S.alogs=(await api('/api/admin/logs')).logs;
  }
}
async function go(page,mode){
  if(mode)S.mode=mode;S.page=page;render('<div class="sk"></div><div class="sk"></div><div class="sk"></div>');
  try{await load();render()}catch(e){render(`<div class="card err">${esc(e.message)}</div>`)}
  window.scrollTo(0,0);
}
function logRows(L,withAcc){return L&&L.length?L.map(l=>`<div class="log"><span class="${l.status=='ok'?'ok':'err'}">●</span> <b>${esc(l.actor)}</b> · ${esc(l.action)} <span class="mut">${lt(l.ts)}</span><div>${esc(l.detail)}</div></div>`).join(''):'<div class="mut sm">Hozircha bo‘sh</div>'}
function sw(id,on,extra){return `<label class="sw"><input type="checkbox" id="${id}" ${on?'checked':''} ${extra||''}><i></i></label>`}

/* ───── MIJOZ sahifalari ───── */
function noConn(){return `<div class="card"><div class="h2">🔌 Ulanish yo‘q</div><ol class="steps"><li>Telegram → <b>Sozlamalar</b></li><li><b>Telegram Business</b> → <b>Chatbots</b></li><li>Ushbu botni qo‘shing va kerakli huquqlarni yoqing</li><li>Bu yerga qaytib «Tekshirish»ni bosing</li></ol><button class="btn" data-a="reload">🔄 Tekshirish</button></div>`}
const PAGES={
'client:home'(){
  const c=S.me.connection;if(!c)return noConn();const st=S.stats||{};
  const state=!c.is_enabled?['Uzilgan','err']:!c.is_consented?['Rozilik kutilmoqda','warn']:!c.rights.can_reply?['Javob huquqi yo‘q','warn']:c.ai_enabled?['AI faol','ok']:['AI to‘xtatilgan','warn'];
  const ck=[[c.is_enabled,'Bot Business’ga ulangan','Telegram → Business → Chatbots'],[c.rights.can_reply,'«Javob berish» huquqi berilgan','Chatbots sozlamasida yoqing'],[c.is_consented,'Siz rozilik bergansiz','Xavfsizlik bo‘limida'],[c.ai_enabled,'AI yoqilgan','AI bo‘limida yoqing']];
  return `<div class="card"><div class="row"><div><div class="b" style="font-size:17px">${esc(c.owner_name)}</div><div class="mut sm">Business akkaunt</div></div><span class="chip ${state[1]}">${state[0]}</span></div>
  <div class="row"><span>🤖 AI avto-javob</span>${sw('aiq',c.ai_enabled,'data-c="aiq"')}</div></div>
  <div class="grid"><div class="stat"><b>${st.ai_24h??'–'}</b><span class="mut sm">AI javob (24s)</span></div><div class="stat"><b>${st.chats??'–'}</b><span class="mut sm">Chatlar</span></div>
  <div class="stat"><b>${st.ai_total??'–'}</b><span class="mut sm">Jami AI javob</span></div><div class="stat"><b class="${st.err_24h?'err':''}">${st.err_24h??'–'}</b><span class="mut sm">Xatolar (24s)</span></div></div>
  <div class="card"><div class="h2">✔️ Tayyorlik</div>${ck.map(x=>`<div class="row"><span>${x[0]?'✅':'❌'} ${x[1]}</span>${x[0]?'':`<span class="mut sm">${x[2]}</span>`}</div>`).join('')}
  ${c.is_consented?'':`<button class="btn" data-a="consent" data-v="1" ${c.is_enabled?'':'disabled'}>✅ Admin hamda AI boshqaruviga rozilik beraman</button>`}</div>`},
'client:ai'(){
  const c=S.me.connection;if(!c)return noConn();
  return `<div class="card"><div class="row"><span class="b">AI avto-javob</span>${sw('ai',c.ai_enabled)}</div>
  <div class="mut sm" style="margin-top:10px">Biznesingiz haqida ma'lumot (AI shu asosida javob beradi):</div>
  <textarea id="cp" rows="7" maxlength="2000" placeholder="Xizmatlar, narxlar, ish vaqti, manzil, aloqa…">${esc(c.custom_prompt)}</textarea>
  <div class="mut sm" id="cnt" style="text-align:right">${c.custom_prompt.length}/2000</div>
  <div class="mut sm" style="margin-top:8px">Siz o‘zingiz chatga yozsangiz, AI shu chatda jim turadi:</div>
  <select id="ho">${[[0,'O‘chiq'],[10,'10 daqiqa'],[30,'30 daqiqa'],[60,'1 soat'],[180,'3 soat'],[720,'12 soat'],[1440,'24 soat']].map(o=>`<option value="${o[0]}" ${o[0]==c.handoff_min?'selected':''}>${o[1]}</option>`).join('')}</select>
  <button class="btn" data-a="save">💾 Saqlash</button></div>
  <div class="card"><div class="h2">🧪 AI sinovi</div><div class="mut sm">Mijoz sifatida yozing — javobni ko‘ring (hech kimga yuborilmaydi).</div>
  <input id="tt" placeholder="Masalan: Narxlar qancha?"><button class="btn" data-a="aitest">Sinash</button><div id="tr"></div></div>`},
'client:chats'(){
  if(!S.me.connection)return noConn();const L=S.chats||[];
  return `<div class="card"><div class="h2">💬 Chatlar</div><div class="mut sm">Har bir chat uchun AI’ni alohida o‘chirishingiz mumkin.</div>
  ${L.length?L.map(x=>`<div class="row"><div><div class="b">${esc(x.name)}</div><div class="mut sm">${x.msg_count} xabar · ${lt(x.last_ts)}${x.paused?` · <span class="warn">AI pauzada</span>`:''}</div>${x.paused?`<button class="btn sm2 ghost" data-a="resume" data-id="${x.chat_id}" style="margin-top:6px">▶ Davom ettirish</button>`:''}</div>${sw('c'+x.chat_id,!x.ai_off,`data-c="chat" data-id="${x.chat_id}"`)}</div>`).join(''):'<div class="mut" style="margin-top:10px">Hali chat yo‘q. Mijoz yozganda shu yerda ko‘rinadi.</div>'}</div>`},
'client:sec'(){
  const c=S.me.connection;if(!c)return noConn();const hasF=FUND.some(k=>c.rights[k]);
  return `<div class="card"><div class="h2">🔑 Telegramda bergan huquqlaringiz</div>${Object.entries(RL).map(([k,l])=>`<div class="row"><span>${l}</span><span class="${c.rights[k]?'ok':'err'}">${c.rights[k]?'✓ berilgan':'✕ yo‘q'}</span></div>`).join('')}
  <div class="mut sm" style="margin-top:8px">Huquqlarni Telegram → Sozlamalar → Business → Chatbots ichida o‘zgartirasiz.</div></div>
  <div class="card"><div class="h2">🤝 Rozilik</div><div class="sm mut">Admin va AI sizning nomingizdan faqat yuqoridagi huquqlar doirasida ishlaydi. Rozilik berilmaguncha hech narsa qila olmaydi. Admin har bir amali haqida sizga xabar keladi va Tarixga yoziladi.</div>
  ${c.is_consented?`<div class="ok b" style="margin-top:10px">✅ Rozilik berilgan</div><button class="btn red" data-a="consent" data-v="0">Rozilikni bekor qilish</button>`:`<button class="btn" data-a="consent" data-v="1" ${c.is_enabled?'':'disabled'}>✅ Admin hamda AI boshqaruviga rozilik beraman</button>`}
  ${hasF&&c.is_consented?`<div style="margin-top:14px;border-top:1px solid rgba(255,255,255,.1);padding-top:12px"><div class="warn b">⚠️ Alohida rozilik: Stars va sovg‘alar</div><div class="sm mut">Stars/sovg‘alarni aylantirish va o‘tkazish uchun alohida ruxsat. Huquqlaringiz o‘zgarsa, bu rozilik avtomatik bekor bo‘ladi.</div>
  ${c.is_consented_funds?`<div class="ok b" style="margin-top:8px">✅ Berilgan</div><button class="btn red" data-a="consentf" data-v="0">Bekor qilish</button>`:`<button class="btn" data-a="consentf" data-v="1">Stars/sovg‘a amallariga ham rozilik beraman</button>`}</div>`:''}</div>`},
'client:log'(){
  if(!S.me.connection)return noConn();const f=S.filter;
  const L=(S.logs||[]).filter(l=>f=='all'||(f=='err'?l.status=='error':l.actor==f));
  return `<div class="card"><div class="row"><div class="h2" style="margin:0">📜 Tarix</div><button class="btn sm2 ghost" data-a="reloadpage">🔄</button></div>
  <div class="chips">${[['all','Hammasi'],['ai','AI'],['admin','Admin'],['user','Men'],['err','Xato']].map(x=>`<button data-a="filter" data-v="${x[0]}" class="${f==x[0]?'on':''}">${x[1]}</button>`).join('')}</div>
  <div style="margin-top:8px">${logRows(L)}</div></div>`},

/* ───── ADMIN sahifalari ───── */
'admin:acc'(){
  const A=S.acc;if(!A)return '';const t=A.totals,st=A.stats;
  return `<div class="grid"><div class="stat"><b>${A.accounts.length}</b><span class="mut sm">Faol akkaunt</span></div><div class="stat"><b>${(t.total-t.consented)||0}</b><span class="mut sm">Rozilik kutilmoqda</span></div>
  <div class="stat"><b>${st.ai_24h}</b><span class="mut sm">AI javob (24s)</span></div><div class="stat"><b class="${st.err_24h?'err':''}">${st.err_24h}</b><span class="mut sm">Xato (24s)</span></div></div>
  <div class="card"><div class="h2">👥 Rozilik bergan akkauntlar</div>${A.accounts.length?A.accounts.map(a=>`<div class="row" data-a="pick" data-id="${esc(a.connection_id)}" style="cursor:pointer"><div><div class="b">${esc(a.owner_name)}</div><div class="mut sm">${Object.values(a.rights).filter(Boolean).length} huquq · AI 24s: ${a.stats.ai_24h} · chat: ${a.stats.chats}</div></div><span class="chip ${a.connection_id===S.sel?'ok':'mut'}">${a.connection_id===S.sel?'Tanlangan':'Tanlash'}</span></div>`).join(''):'<div class="mut">Hozircha rozilik bergan akkaunt yo‘q.</div>'}</div>`},
'admin:msg'(){return accPage(a=>`<div class="card"><div class="h2">✉️ Xabar yuborish</div>
  <select id="chat" data-c="gchat">${a.chats.map(c=>`<option value="${c.chat_id}" ${String(c.chat_id)==S.gchat?'selected':''}>${esc(c.name)} (${c.chat_id})</option>`).join('')}<option value="">— ID qo‘lda —</option></select>
  <input id="chatid" placeholder="chat_id (qo‘lda)" inputmode="numeric" data-c="gchatid"><textarea id="msg" rows="3" placeholder="Xabar matni"></textarea>${rb(a,['can_reply'],'Yuborish','send')}</div>
  <div class="card"><div class="h2">🛠 Mavjud xabar bilan</div><input id="mid" placeholder="message_id" inputmode="numeric"><div class="chips" id="midchips">${midChips(a)}</div>
  ${rb(a,['can_reply'],'✏️ Tahrirlash (yuqoridagi matn bilan)','edit')}${rb(a,['can_read_messages'],'👁 O‘qildi deb belgilash','read')}
  <input id="dids" placeholder="O‘chirish: message_id’lar (vergul bilan)">${rb(a,['can_delete_sent_messages','can_delete_all_messages'],'🗑 O‘chirish','delete',{cls:'red'})}</div>`)},
'admin:prof'(){return accPage(a=>`<div class="card"><div class="h2">🪪 Ism va Bio</div><input id="fn" placeholder="Ism"><input id="ln" placeholder="Familiya">${rb(a,['can_edit_name'],'Ismni o‘zgartirish','name')}
  <input id="bio" maxlength="70" placeholder="Bio (70 belgigacha)">${rb(a,['can_edit_bio'],'Bio’ni o‘zgartirish','bio')}
  <input id="un" placeholder="username (bo‘sh = o‘chirish)">${rb(a,['can_edit_username'],'Username’ni o‘zgartirish','username')}</div>
  <div class="card"><div class="h2">🖼 Profil rasmi</div><input type="file" id="pfile" accept="image/jpeg"><label class="l">${sw('pub',false)} Ommaviy (public) rasm</label>
  ${rb(a,['can_edit_profile_photo'],'Rasmni qo‘yish (JPG)','photo_set')}${rb(a,['can_edit_profile_photo'],'Rasmni o‘chirish','photo_remove',{cls:'red'})}</div>`)},
'admin:story'(){return accPage(a=>`<div class="card"><div class="h2">📸 Story</div><input type="file" id="sfile" accept="image/jpeg,image/png"><input id="cap" maxlength="200" placeholder="Izoh (ixtiyoriy)">
  <select id="per"><option value="86400">24 soat</option><option value="43200">12 soat</option><option value="21600">6 soat</option><option value="172800">48 soat</option></select>${rb(a,['can_manage_stories'],'Story joylash','story_post')}
  <input id="sid" placeholder="story_id (almashtirish/o‘chirish)" inputmode="numeric">${rb(a,['can_manage_stories'],'Story’ni almashtirish (yuqoridagi rasm bilan)','story_edit')}${rb(a,['can_manage_stories'],'Story’ni o‘chirish','story_delete',{cls:'red'})}</div>`)},
'admin:gift'(){return accPage(a=>`<div class="card"><div class="h2">⭐ Stars va sovg‘alar</div>${rb(a,['can_view_gifts_and_stars'],'⭐ Stars balansi','balance')}${rb(a,['can_view_gifts_and_stars'],'🎁 Sovg‘alar ro‘yxati','gifts')}<div id="giftlist"></div>
  <input id="gid" placeholder="owned_gift_id (ro‘yxatdan bosing)"><input id="gstars" placeholder="star_count (ixtiyoriy)" inputmode="numeric"><input id="gto" placeholder="Qabul qiluvchi chat_id (o‘tkazish uchun)" inputmode="numeric">
  <label class="l">${sw('keep',false)} Asl ma’lumotni saqlash (yangilashda)</label>
  ${rb(a,['can_convert_gifts_to_stars'],'⭐ Stars’ga aylantirish','convert_gift',{fund:1,cls:'red'})}${rb(a,['can_transfer_and_upgrade_gifts'],'⬆️ Yangilash','upgrade_gift',{fund:1})}${rb(a,['can_transfer_and_upgrade_gifts'],'➡️ Sovg‘ani o‘tkazish','transfer_gift',{fund:1,cls:'red'})}
  <input id="tstars" placeholder="Stars soni (1–10000)" inputmode="numeric">${rb(a,['can_transfer_stars'],'⭐ Stars o‘tkazish','transfer_stars',{fund:1,cls:'red'})}</div>
  <div class="card"><div class="h2">⚙️ Sovg‘a sozlamalari</div>
  <label class="l">${sw('g_btn',true)} Sovg‘a tugmasini ko‘rsatish</label><label class="l">${sw('g_un',true)} Cheksiz</label><label class="l">${sw('g_li',true)} Limitli</label><label class="l">${sw('g_uq',true)} Unikal</label><label class="l">${sw('g_pr',true)} Premium obuna</label>
  ${rb(a,['can_change_gift_settings'],'Sozlamani saqlash','gift_settings')}</div>`)},
'admin:alog'(){return `<div class="card"><div class="row"><div class="h2" style="margin:0">📜 Audit Log (hamma)</div><button class="btn sm2 ghost" data-a="reloadpage">🔄</button></div><div style="margin-top:8px">${logRows(S.alogs)}</div></div>`}
};
function accPage(fn){
  const A=S.acc;if(!A||!A.accounts.length)return '<div class="card">Rozilik bergan va ulangan akkaunt yo‘q.</div>';
  const a=CUR()||A.accounts[0];
  return `<div class="sel"><select id="sel" data-c="sel">${A.accounts.map(x=>`<option value="${esc(x.connection_id)}" ${x.connection_id===a.connection_id?'selected':''}>${esc(x.owner_name)}</option>`).join('')}</select></div>`+fn(a)+`<div class="card"><div class="mut sm">Natija:</div><pre id="out">—</pre></div>`;
}
function rb(a,rights,label,act,o){o=o||{};let ok=rights.some(x=>a.rights[x]),why='Ruxsat berilmagan';if(ok&&o.fund&&!a.is_consented_funds){ok=false;why='Alohida rozilik yo‘q'}
  return `<button class="btn ${o.cls||''}" data-a="run" data-act="${act}" ${ok?'':'disabled'}>${ok?label:'🔒 '+why}</button>`}
function midChips(a){const cid=val('chatid')||val('chat')||S.gchat||(a.chats[0]&&String(a.chats[0].chat_id))||'';
  return a.msgs.filter(m=>String(m.chat_id)==cid).slice(0,12).map(m=>`<button data-a="fillmid" data-v="${m.message_id}">${m.direction=='in'?'⬅':'➡'} ${m.message_id}</button>`).join('')||'<span class="mut sm">Xabar ID’lari shu yerda chiqadi</span>'}

/* ───── Admin amallari ───── */
function readFile(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)})}
async function img(id){const f=$('#'+id).files[0];if(!f)throw new Error('Rasm tanlang');return readFile(f)}
const chatId=()=>val('chatid')||val('chat');
const P={send:()=>({chat_id:chatId(),text:val('msg')}),edit:()=>({chat_id:chatId(),message_id:val('mid'),text:val('msg')}),read:()=>({chat_id:chatId(),message_id:val('mid')}),
 delete:()=>({message_ids:val('dids')||val('mid')}),name:()=>({first_name:val('fn'),last_name:val('ln')}),bio:()=>({bio:val('bio')}),username:()=>({username:val('un')}),
 photo_set:async()=>({data:await img('pfile'),is_public:val('pub')}),photo_remove:()=>({is_public:val('pub')}),
 story_post:async()=>({data:await img('sfile'),caption:val('cap'),active_period:+val('per')}),story_edit:async()=>({story_id:val('sid'),data:await img('sfile'),caption:val('cap')}),story_delete:()=>({story_id:val('sid')}),
 balance:()=>({}),gifts:()=>({}),convert_gift:()=>({owned_gift_id:val('gid')}),upgrade_gift:()=>({owned_gift_id:val('gid'),star_count:val('gstars'),keep_original_details:val('keep')}),
 transfer_gift:()=>({owned_gift_id:val('gid'),new_owner_chat_id:val('gto'),star_count:val('gstars')}),transfer_stars:()=>({star_count:val('tstars')}),
 gift_settings:()=>({show_gift_button:val('g_btn'),types:{unlimited_gifts:val('g_un'),limited_gifts:val('g_li'),unique_gifts:val('g_uq'),premium_subscription:val('g_pr')}})};
const DANGER=['convert_gift','upgrade_gift','transfer_gift','transfer_stars','delete','photo_remove','story_delete'];
function showGifts(r){const g=(r&&r.gifts)||[];$('#giftlist').innerHTML=g.map(x=>{const n=(x.gift&&(x.gift.name||x.gift.id))||'';
 return `<div class="log" style="cursor:pointer" data-a="fillgift" data-id="${esc(x.owned_gift_id)}">🎁 ${esc(x.type)} ${esc(n)} <span class="mut">${esc(x.owned_gift_id)}</span></div>`}).join('')||'<div class="mut sm">Sovg‘a yo‘q</div>'}
let busy=false;
async function run(a,btn){
  if(busy)return;let p;try{p=await P[a]()}catch(e){return toast(e.message,1)}
  if(DANGER.includes(a)&&!await confirmBox('Rostdan ham bajarilsinmi? ('+a+')'))return;
  busy=true;if(btn){btn.disabled=true}
  try{const d=await api('/api/admin/act',{connection_id:S.sel,action:a,params:p});
    const o=$('#out');if(o)o.textContent=JSON.stringify(d.result,null,1).slice(0,2500);
    if(a=='gifts')showGifts(d.result);toast('Bajarildi ✅')}
  catch(e){toast(e.message,1)}finally{busy=false;if(btn)btn.disabled=false}
}

/* ───── Hodisalar (delegatsiya) ───── */
const ACT={
 mode:b=>go(b.dataset.v=='admin'?'acc':'home',b.dataset.v),go:b=>go(b.dataset.v),reload:async()=>{try{S.me=await api('/api/me');go('home')}catch(e){toast(e.message,1)}},
 reloadpage:()=>go(S.page),filter:b=>{S.filter=b.dataset.v;render()},
 pick:b=>{S.sel=b.dataset.id;render();toast('Tanlandi')},
 consent:async b=>{try{await api('/api/consent',{value:+b.dataset.v});S.me=await api('/api/me');await load();render();toast('Saqlandi')}catch(e){toast(e.message,1)}},
 consentf:async b=>{try{await api('/api/consent_funds',{value:+b.dataset.v});S.me=await api('/api/me');render();toast('Saqlandi')}catch(e){toast(e.message,1)}},
 save:async()=>{try{await api('/api/settings',{ai_enabled:val('ai'),custom_prompt:$('#cp').value,handoff_min:val('ho')});S.me=await api('/api/me');render();toast('Saqlandi ✅')}catch(e){toast(e.message,1)}},
 aitest:async()=>{const t=val('tt');if(!t)return;$('#tr').innerHTML=`<div class="bubble me">${esc(t)}</div><div class="bubble">⏳ …</div>`;
  try{const d=await api('/api/ai/test',{text:t,custom_prompt:$('#cp').value});$('#tr').innerHTML=`<div class="bubble me">${esc(t)}</div><div class="bubble">${esc(d.reply)}</div>`}catch(e){$('#tr').innerHTML=`<div class="bubble err">${esc(e.message)}</div>`}},
 resume:async b=>{try{await api('/api/chat_set',{chat_id:+b.dataset.id,resume:true});go('chats')}catch(e){toast(e.message,1)}},
 run:b=>run(b.dataset.act,b),fillmid:b=>{$('#mid').value=b.dataset.v},fillgift:b=>{$('#gid').value=b.dataset.id;toast('ID qo‘yildi')}
};
const CH={
 aiq:async t=>{try{await api('/api/settings',{ai_enabled:t.checked});S.me.connection.ai_enabled=t.checked;render();toast(t.checked?'AI yoqildi':'AI o‘chirildi')}catch(e){t.checked=!t.checked;toast(e.message,1)}},
 chat:async t=>{try{await api('/api/chat_set',{chat_id:+t.dataset.id,ai_off:!t.checked})}catch(e){t.checked=!t.checked;toast(e.message,1)}},
 sel:t=>{S.sel=t.value;render()},gchat:t=>{S.gchat=t.value;const a=CUR();if(a)$('#midchips').innerHTML=midChips(a)},gchatid:()=>{const a=CUR();if(a)$('#midchips').innerHTML=midChips(a)}
};
document.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(b&&!b.disabled&&ACT[b.dataset.a])ACT[b.dataset.a](b)});
document.addEventListener('change',e=>{const t=e.target.closest('[data-c]');if(t&&CH[t.dataset.c])CH[t.dataset.c](t)});
document.addEventListener('input',e=>{if(e.target.id=='cp'){const c=$('#cnt');if(c)c.textContent=e.target.value.length+'/2000'}else if(e.target.dataset.c=='gchatid')CH.gchatid(e.target)});
setInterval(async()=>{if(document.hidden||S.mode!='client'||!S.me||!S.me.connection||busy)return;const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))return;
  if(['home','chats','log'].includes(S.page)){try{await load();render()}catch(e){}}},20000);
(async()=>{
  if(!tg||!tg.initData){$('#app').innerHTML='<div class="card"><div class="h2">Telegram ichida oching</div>Bu panel faqat Telegram bot ichidagi <b>«Panel»</b> tugmasi yoki /start dagi tugma orqali ochiladi.</div>';return}
  try{S.me=await api('/api/me');await go('home','client')}catch(e){$('#app').innerHTML='<div class="card err">'+esc(e.message)+'</div>'}
})();
</script></body></html>"""


# ───────────────────────── CLI ─────────────────────────
def run():
    if not BOT_TOKEN:
        sys.exit("BOT_TOKEN topilmadi (.env faylni tekshiring)")
    if not GROQ_API_KEY or not ADMIN_ID:
        print("Ogohlantirish: GROQ_API_KEY yoki ADMIN_ID .env da yo'q", file=sys.stderr)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"Server: http://127.0.0.1:{PORT}")
    atexit.register(stop_tunnel)
    if not PUBLIC_URL_ENV:
        if start_tunnel():
            set_public(TUN["url"])
            threading.Thread(target=tunnel_supervisor, daemon=True).start()
    if PUBLIC_URL:
        apply_public()
    elif MODE == "webhook":
        sys.exit("Webhook rejimi uchun HTTPS manzil kerak (cloudflared yoki PUBLIC_URL)")
    if MODE == "webhook":
        print("Bot: webhook rejimi")
        while True:
            time.sleep(3600)
    poll_loop()


def main():
    if not BOT_TOKEN:
        sys.exit("BOT_TOKEN topilmadi (.env faylni tekshiring)")
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    if cmd == "setwebhook":
        if not PUBLIC_URL:
            sys.exit("PUBLIC_URL kerak")
        print(tg("setWebhook", {"url": PUBLIC_URL + "/webhook", "secret_token": WEBHOOK_SECRET,
                                "allowed_updates": ALLOWED_UPDATES, "drop_pending_updates": True}))
    elif cmd == "info":
        print(json.dumps(tg("getWebhookInfo"), indent=2, ensure_ascii=False))
    else:
        try:
            run()
        except KeyboardInterrupt:
            print("\nTo'xtatildi")


if __name__ == "__main__":
    main()
