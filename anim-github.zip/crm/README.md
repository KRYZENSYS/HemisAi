1) pkg update -y && pkg install -y python cloudflared unzip
2) unzip crm.zip && cd crm
3) nano .env   (BOT_TOKEN, GROQ_API_KEY, ADMIN_ID ni to'ldiring)
4) chmod +x start.sh && ./start.sh
5) Telegram -> Sozlamalar -> Business -> Chatbots -> botni qo'shing, botga /start yozing, "Panel" tugmasini oching.
Holatni tekshirish: botga /status yozing.
