#!/data/data/com.termux/files/usr/bin/bash
# Botni doim ishlatib turadi: to'xtasa 3 soniyadan keyin qayta ishga tushadi.
cd "$(dirname "$0")"
termux-wake-lock 2>/dev/null
while true; do
  pkill cloudflared 2>/dev/null
  python main.py
  echo "⚠️ To'xtadi. 3 soniyadan keyin qayta ishga tushadi (chiqish: Ctrl+C)"
  sleep 3
done
