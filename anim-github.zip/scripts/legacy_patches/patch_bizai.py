#!/usr/bin/env python3
"""hemis3.py ga Telegram Business AI (bizai.py) ni ulaydi. Zaxira: hemis3.py.bak5. Ikkinchi marta ishga tushirsa, hech narsa qilmaydi.
Talab: aiogram >= 3.10 (pip install -U aiogram). Boshqaruv: /bizai yoki Admin Panel -> «💼 Telegram Business AI» (callback "bz:menu")."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import bizai as _bizai" in src:
    sys.exit("Allaqachon ulangan.")
EDITS = [
    ('        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n',
     '        [InlineKeyboardButton(text="💼 Telegram Business AI", callback_data="bz:menu")],\n'
     '        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n'),
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import bizai as _bizai\n    _bizai.setup(globals())\nexcept Exception:\n'
     '    logging.exception("Telegram Business AI yuklanmadi (bot usiz ishlaydi)")\n    _bizai = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    ("    dp.callback_query.outer_middleware(GuardMiddleware())\n",
     "    dp.callback_query.outer_middleware(GuardMiddleware())\n    if _bizai:\n        _bizai.start()\n"),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak5")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ Telegram Business AI ulandi. Zaxira:", PATH + ".bak5")
