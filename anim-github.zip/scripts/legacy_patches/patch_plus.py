#!/usr/bin/env python3
"""hemis3.py ga Plus moduli (plus.py) ni ulaydi. Zaxira: hemis3.py.bak6. Ikkinchi marta ishga tushirsa, hech narsa qilmaydi.
Boshqaruv: /plus yoki «✨ Plus» tugmasi; admin uchun /plus -> «Plus boshqaruvi»."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import plus as _plus" in src:
    sys.exit("Allaqachon ulangan.")
EDITS = [
    # tugma nomi
    ('B_HUB = "🎓 Student Hub"\n', 'B_HUB = "🎓 Student Hub"\nB_PLUS = "✨ Plus"\n'),
    ("    B_LOGOUT, B_ADMIN, B_HUB, B_PREMIUM,\n]", "    B_LOGOUT, B_ADMIN, B_HUB, B_PREMIUM, B_PLUS,\n]"),
    # asosiy menyu
    ("        [KeyboardButton(text=B_HUB), KeyboardButton(text=B_PREMIUM)],\n",
     "        [KeyboardButton(text=B_HUB), KeyboardButton(text=B_PREMIUM)],\n        [KeyboardButton(text=B_PLUS)],\n"),
    # admin paneli tugmasi
    ('        [InlineKeyboardButton(text="💎 Student Hub", callback_data="hub:adm")],\n',
     '        [InlineKeyboardButton(text="💎 Student Hub", callback_data="hub:adm")],\n'
     '        [InlineKeyboardButton(text="✨ Plus boshqaruvi", callback_data="px:adm")],\n'),
    # plus ni ulash: bizai'dan keyin, umumiy matn handleridan OLDIN
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import plus as _plus\n    _plus.setup(globals())\nexcept Exception:\n'
     '    logging.exception("Plus moduli yuklanmadi (bot usiz ishlaydi)")\n    _plus = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    # main(): ishga tushirish
    ("    if _hub:\n        _hub.start()\n", "    if _hub:\n        _hub.start()\n    if _plus:\n        _plus.start()\n"),
    # buyruqlar
    ('        BotCommand(command="premium", description="Premium va kreditlar"),\n',
     '        BotCommand(command="premium", description="Premium va kreditlar"),\n'
     '        BotCommand(command="plus", description="Plus: kartalar, AI Studio, guruh, o\'yin"),\n'
     '        BotCommand(command="promo", description="Promokod kiritish"),\n'),
    # yordam matni
    ('    "🔔 <b>Bildirishnomalar:</b>',
     '    "✨ <b>Plus:</b> takrorlash kartalari, pomodoro, kalkulyator, kalendar (.ics), AI Studio, guruh paneli, e\'lonlar, XP/reyting, duel (/plus)\\n"\n'
     '    "🔔 <b>Bildirishnomalar:</b>'),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}\nFayl boshqa versiya bo'lishi mumkin. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak6")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ Plus ulandi. Zaxira:", PATH + ".bak6")
