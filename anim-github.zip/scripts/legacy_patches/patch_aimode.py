#!/usr/bin/env python3
"""hemis3.py ga AI avto-javob (aimode.py) ni ulaydi. Zaxira: hemis3.py.bak4. Ikkinchi marta ishga tushirsa, hech narsa qilmaydi.
Callback prefiksi "am:", buyruq /aimode (hemis3.py dagi "ai:" va /ai bot ichidagi Gemini yordamchiga tegishli)."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import aimode as _aimode" in src:
    sys.exit("Allaqachon ulangan.")
EDITS = [
    ('        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n',
     '        [InlineKeyboardButton(text="🤖 AI avto-javob", callback_data="am:menu")],\n'
     '        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n'),
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import aimode as _aimode\n    _aimode.setup(globals())\nexcept Exception:\n'
     '    logging.exception("AI avto-javob yuklanmadi (bot usiz ishlaydi)")\n    _aimode = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    ("    dp.callback_query.outer_middleware(GuardMiddleware())\n",
     "    dp.callback_query.outer_middleware(GuardMiddleware())\n    if _aimode:\n        _aimode.start()\n"),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak4")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ AI avto-javob ulandi. Zaxira:", PATH + ".bak4")
