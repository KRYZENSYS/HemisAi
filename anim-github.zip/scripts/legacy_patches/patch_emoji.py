#!/usr/bin/env python3
"""hemis3.py ga Bot emoji (emojify.py) ni ulaydi. Zaxira: hemis3.py.bak3."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import emojify as _emoji" in src:
    sys.exit("Allaqachon ulangan.")
EDITS = [
    ('        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n',
     '        [InlineKeyboardButton(text="🎭 Bot emoji", callback_data="em:menu")],\n'
     '        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n'),
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import emojify as _emoji\n    _emoji.setup(globals())\nexcept Exception:\n'
     '    logging.exception("Bot emoji yuklanmadi (bot usiz ishlaydi)")\n    _emoji = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    ("    dp.callback_query.outer_middleware(GuardMiddleware())\n",
     "    dp.callback_query.outer_middleware(GuardMiddleware())\n    if _emoji:\n        _emoji.start()\n"),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak3")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ Bot emoji ulandi. Zaxira:", PATH + ".bak3")
