#!/usr/bin/env python3
"""hemis3.py ga Student Hub ni ulaydi (zaxira nusxa: hemis3.py.bak). Ikkinchi marta ishga tushirsa, hech narsa qilmaydi."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import hub as _hub" in src:
    sys.exit("Allaqachon ulangan.")

EDITS = [
    # tugma nomlari
    ('B_ADMIN = "⚙️ Admin Panel"\n',
     'B_ADMIN = "⚙️ Admin Panel"\nB_HUB = "🎓 Student Hub"\nB_PREMIUM = "💎 Premium"\n'),
    ("    B_LOGOUT, B_ADMIN,\n]", "    B_LOGOUT, B_ADMIN, B_HUB, B_PREMIUM,\n]"),
    # asosiy menyu
    ("        [KeyboardButton(text=B_HELP), KeyboardButton(text=B_LOGOUT)],\n",
     "        [KeyboardButton(text=B_HUB), KeyboardButton(text=B_PREMIUM)],\n"
     "        [KeyboardButton(text=B_HELP), KeyboardButton(text=B_LOGOUT)],\n"),
    # admin panel tugmasi
    ('        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n',
     '        [InlineKeyboardButton(text="💎 Student Hub", callback_data="hub:adm")],\n'
     '        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n'),
    # yordam matni
    ('    "🔔 <b>Bildirishnomalar:</b>',
     '    "🎓 <b>Student Hub:</b> referat, kurs ishi, taqdimot, hujjat, savol-javob, tarjima (/hub); 💎 /premium; 👥 /referal\\n"\n'
     '    "🔔 <b>Bildirishnomalar:</b>'),
    # limit tugaganda taklif
    ('tugadi. Ertaga yangilanadi.")', 'tugadi. Ertaga yangilanadi.\\n💎 Ko\'proq so\'rov uchun: /premium")'),
    # hub ni ulash: umumiy matn handleridan OLDIN
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import hub as _hub\n    _hub.setup(globals())\nexcept Exception:\n'
     '    logging.exception("Student Hub yuklanmadi (bot hub\'siz ishlaydi)")\n    _hub = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    # main(): middleware'dan keyin
    ("    dp.callback_query.outer_middleware(GuardMiddleware())\n",
     "    dp.callback_query.outer_middleware(GuardMiddleware())\n    if _hub:\n        _hub.start()\n"),
    # buyruqlar
    ('        BotCommand(command="guruhdosh", description="Guruhdoshlar (sinov)"),\n',
     '        BotCommand(command="guruhdosh", description="Guruhdoshlar (sinov)"),\n'
     '        BotCommand(command="hub", description="Student Hub: referat, taqdimot, hujjat"),\n'
     '        BotCommand(command="premium", description="Premium va kreditlar"),\n'
     '        BotCommand(command="referal", description="Do\'st taklif qilish (bepul kredit)"),\n'),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}\nFayl boshqa versiya bo'lishi mumkin. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ Ulandi. Zaxira:", PATH + ".bak")
