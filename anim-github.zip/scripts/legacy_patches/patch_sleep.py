#!/usr/bin/env python3
"""hemis3.py ga Uyqu rejimi (sleepmode.py) ni ulaydi. Zaxira: hemis3.py.bak2. Ikkinchi marta ishga tushirsa, hech narsa qilmaydi."""
import shutil
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "hemis3.py"
src = open(PATH, encoding="utf-8").read()
if "import sleepmode as _sleep" in src:
    sys.exit("Allaqachon ulangan.")
EDITS = [
    ('        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n',
     '        [InlineKeyboardButton(text="😴 Uyqu rejimi", callback_data="sl:menu")],\n'
     '        [InlineKeyboardButton(text="🤖 AI boshqaruvi", callback_data="ai:admin")],\n'),
    ('@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text(',
     'try:\n    import sleepmode as _sleep\n    _sleep.setup(globals())\nexcept Exception:\n'
     '    logging.exception("Uyqu rejimi yuklanmadi (bot usiz ishlaydi)")\n    _sleep = None\n\n\n'
     '@dp.message(F.text, ~F.text.startswith("/"))\nasync def ai_text('),
    ("    dp.callback_query.outer_middleware(GuardMiddleware())\n",
     "    dp.callback_query.outer_middleware(GuardMiddleware())\n    if _sleep:\n        _sleep.start()\n"),
]
for old, new in EDITS:
    n = src.count(old)
    if n != 1:
        sys.exit(f"Moslik {n} ta (1 bo'lishi kerak): {old[:60]!r}. Hech narsa o'zgartirilmadi.")
    src = src.replace(old, new)
shutil.copy(PATH, PATH + ".bak2")
open(PATH, "w", encoding="utf-8").write(src)
print("✅ Uyqu rejimi ulandi. Zaxira:", PATH + ".bak2")
