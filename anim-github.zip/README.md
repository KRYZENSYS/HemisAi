# HEMIS Student Hub — Telegram bot

HEMIS (talabalar axborot tizimi) uchun Telegram bot: baho/NB kuzatuvi, jadval, **Student Hub** (premium, kreditlar, referal), **Plus** moduli (takrorlash kartalari, GPA, kalendar, o'yinlar, jamoa), **Uyqu rejimi**, **AI avto-javob** va Gemini asosidagi AI yordamchi.

Stek: Python 3.12, aiogram 3, aiohttp, SQLite, Telethon, reportlab.

## Tezkor start

```bash
git clone <repo-url> && cd <repo>
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env        # BOT_TOKEN, ADMIN_ID, ENCRYPTION_KEY ni to'ldiring
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"   # ENCRYPTION_KEY uchun

python hemis3.py
```

### Docker

```bash
cp .env.example .env
docker compose up -d --build
```

Ma'lumotlar `botdata` volume'da (`/data`) saqlanadi.

### Termux (telefonda, Cloudflare Tunnel bilan)

```bash
bash hemis.sh setup   # bir marta
bash hemis.sh         # har safar
```

### systemd

`deploy/hemis-bot.service` — namuna unit fayl (yo'llarni o'zingizga moslang).

## Sozlamalar

Barcha sozlamalar `.env` orqali beriladi — to'liq ro'yxat va izohlar `.env.example` da.
**`.env` va `*.db` fayllarini hech qachon commit qilmang** (`.gitignore` ularni chetlab o'tadi).

## Testlar

```bash
pip install -r requirements-dev.txt
python -m pytest -q          # yoki: python -m unittest discover -s tests
```

CI: `.github/workflows/ci.yml` (har push/PR da compile + testlar).

## Tuzilma

| Fayl | Vazifasi |
|---|---|
| `hemis3.py` | Asosiy bot (kirish nuqtasi) |
| `hub.py`, `hubdocs.py` | Student Hub, hujjatlar |
| `plus.py`, `plus_core.py` | Plus moduli va sof mantiq |
| `sleepmode.py`, `aimode.py`, `bizai.py`, `emojify.py` | Uyqu rejimi, AI avto-javob, Business AI, bot emoji |
| `archive_parser.py` | Telegram eksport JSON parseri |
| `crm/` | Alohida mini-CRM bot (o'z `README.md` va `.env.example` si bor) |
| `docs/` | Modullar bo'yicha qo'llanmalar (`HUB.txt`, `PLUS.txt`) va audit hisoboti |
| `scripts/legacy_patches/` | Eski `hemis3.py` ga modullarni ulaydigan bir martalik patch skriptlari |

## Xavfsizlik

- Token va kalitlar faqat `.env` da; kodda hardcode qilinmagan.
- HEMIS tokenlari va sessiyalar `ENCRYPTION_KEY` bilan shifrlangan holda bazada saqlanadi (kalit o'zgarsa, qayta kirish kerak).
- Telethon userbot Telegram qoidalariga zid ishlatilmasin (spam, ommaviy yozish yo'q).
