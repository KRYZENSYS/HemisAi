# -*- coding: utf-8 -*-
"""
plus.py - "Plus" moduli (hemis3.py ga ulanadi, hub.py kabi: setup(globals()) / start()).

Qo'shadi: O'qish (takrorlash kartalari SM-2, pomodoro, ball va GPA kalkulyatori, kalendar + .ics, imtihon rejasi,
materiallar kutubxonasi), AI Studio (rejimlar, hujjat bilan suhbat, OCR, IELTS speaking...), Jamoa (guruh paneli,
e'lonlar taxtasi, anonim savol, fan sharhlari, konsultatsiya navbati), O'yin (XP, streak, nishon, reyting,
kunlik topshiriq, duel), Promokod va kredit sovg'a, ochiq API, admin dashboard, rollar, audit log,
avtomatik zaxira, token shifrlash migratsiyasi, sog'liq nazorati, ma'lumot eksport/o'chirish.
"""
import asyncio
import datetime as dt
import io
import json
import logging
import os
import random
import re
import secrets
import sqlite3
import time
from contextlib import closing

from aiogram import BaseMiddleware, F, types
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, InlineKeyboardButton, InlineKeyboardMarkup

import plus_core as pc

NEEDED = [
    "dp", "bot", "ADMIN_ID", "is_admin", "esc", "e", "now", "dig", "nm", "first", "unwrap", "parse_date", "fmt_date",
    "fetch", "fetch_all", "fetch_one", "run", "insert", "safe_send", "get_user_token", "claim", "get_all_user_ids",
    "get_main_keyboard", "interrupted", "sem_params", "subj_name", "exam_date_of", "db", "edit", "B_PLUS", "DB_NAME",
    "set_blocked", "ai_dialog", "ai_media_parts", "ai_slot", "ai_count", "AIGate", "GeminiError",
    "ai_err_text", "ai_available", "gemini_generate", "ai_text_models", "R", "jres", "WebErr", "TZ", "WEB_APP_URL",
]
G = {}
NS = {}

CFG_DEFAULTS = {"backup_keep": "7", "weekly_backup": "1", "alert_errors": "5", "xp_daily": "5", "board_days": "30"}
BACKUP_DIR = os.getenv("PX_BACKUP_DIR", "backups")
MAX_STATE_TEXT = 3000

ROLES = {"moderator": "🛡 Moderator", "sardor": "👑 Sardor", "teacher": "👨‍🏫 O'qituvchi"}
BOARD_KINDS = {
    "market": ("🛒 Bozor (kitob/konspekt)", "Nima sotasiz/almashtirasiz?"),
    "lost": ("🔍 Yo'qolgan buyum", "Nima yo'qotdingiz?"),
    "found": ("🎁 Topilgan buyum", "Nima topdingiz?"),
    "event": ("🎉 Tadbir", "Tadbir nomi?"),
}
QUESTS = {
    "cards": (5, 10, "🃏 5 ta karta takrorla"),
    "pomo": (1, 10, "🍅 1 ta pomodoro tugat"),
    "ai": (1, 5, "🤖 AI Studio'dan 1 marta foydalan"),
}

# AI Studio rejimlari: kalit -> (tugma, tizim ko'rsatmasi, kiritish bo'yicha yo'l-yo'riq, media qabul qiladimi)
AI_TOOLS = {
    "simple": ("🧒 Oddiy tushuntir", "Mavzuni juda oddiy tilda, kundalik misollar bilan tushuntir. Murakkab atamalarni izohla.",
               "Qaysi mavzuni tushuntiray? (matn yoki rasm)", True),
    "exam": ("📝 Imtihon uslubida", "Mavzuni imtihonga tayyorlanish uchun: asosiy tushunchalar, formulalar/qoidalar, 5 ta ehtimoliy "
             "imtihon savoli va ularning qisqa javoblari.", "Imtihon mavzusini yozing.", True),
    "summary": ("🗒 Konspekt xulosa", "Berilgan materialdan o'zbek tilida ixcham konspekt tuz: sarlavhalar, 7-12 ta asosiy fikr, "
                "muhim atama va raqamlar.", "Matn, rasm yoki PDF yuboring.", True),
    "ocr": ("🔤 Rasm → matn (OCR)", "Rasmdagi/hujjatdagi matnni aynan ko'chirib yoz (o'zgartirmasdan, tuzatmasdan). "
            "Jadval bo'lsa, jadval ko'rinishida.", "Doska/daftar/hujjat rasmini yuboring.", True),
    "mindmap": ("🧭 Mind-map (daraxt)", "Mavzuni mind-map sifatida matnli daraxt ko'rinishida chiz (├─ va └─ belgilari bilan), "
                "3 darajagacha.", "Mavzu yoki matn yuboring.", True),
    "code": ("💻 Kod yordamchi", "Dasturlash yordamchisi: kodni tushuntir, xatoni top va tuzatilgan variantni yoz. Yechimni qisqa izohla.",
             "Kod yoki xato matnini yuboring.", True),
    "ielts": ("🎤 IELTS speaking", "IELTS Speaking examiner sifatida ovozli/matnli javobni baholab ber: Fluency, Vocabulary, Grammar, "
              "Pronunciation bo'yicha taxminiy band va 3 ta aniq tavsiya. Javob o'zbek tilida, misollar inglizcha.",
              "Savolga ingliz tilida ovozli xabar (yoki matn) bilan javob bering.", True),
    "defense": ("🎙 Mudofaa nutqi", "Kurs ishi/BMI mudofaasi uchun 3 daqiqalik nutq matni yoz va komissiya bergan 8 ta ehtimoliy "
                "savolga qisqa javob tayyorla. Yo'q ma'lumotni to'qima, [to'ldiring] deb belgila.",
                "Ish mavzusi va qisqa mazmunini yozing.", True),
    "originality": ("🔎 Originallik maslahati", "Matnni ko'rib chiq: shablon/umumiy iboralar, takrorlar va manbasiz da'volarni ajrat, matnni "
                    "o'z so'zlari bilan qayta yozish bo'yicha aniq tavsiya ber. Muhim: bu rasmiy antiplagiat emas, faqat uslubiy maslahat; "
                    "birovning matnini yashirishga yordam berma.", "Tekshirish uchun matnni yuboring.", False),
    "cardsgen": ("🃏 AI → kartalar", None, "Mavzu yoki matn yuboring: AI savol-javob kartalari tuzadi.", True),
    "doc": ("📄 Hujjat bilan suhbat", None, "PDF/matn/rasm yuboring, keyin shu hujjat bo'yicha savol bering. Tugatish: /cancel", True),
}


class PxStates(StatesGroup):
    card_add = State()
    calc_in = State()
    gpa_in = State()
    plan_in = State()
    ai_in = State()
    docchat = State()
    promo = State()
    gift = State()
    grp_name = State()
    grp_join = State()
    grp_post = State()
    grp_poll = State()
    brd_title = State()
    brd_body = State()
    brd_extra = State()
    relay = State()
    anon = State()
    rev_subj = State()
    rev_comment = State()
    slot_note = State()
    mat_subj = State()
    mat_title = State()
    mat_file = State()
    duel_topic = State()
    duel_join = State()
    adm_role = State()
    adm_promo = State()
    adm_reply = State()
    mat_search = State()
    brd_search = State()


# ======================================================================
# Yordamchilar
# ======================================================================
def B(text, data=None, url=None):
    if url:
        return InlineKeyboardButton(text=text, url=url)
    return InlineKeyboardButton(text=text, callback_data=data)


def KB(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


BACK = [B("⬅️ Plus menyu", "px:menu")]


def today_s():
    return G["now"]().strftime("%Y-%m-%d")


def cfg(key):
    r = G["fetch_one"]("SELECT value FROM px_cfg WHERE key=?", (key,))
    return r["value"] if r else CFG_DEFAULTS.get(key, "")


def cfg_int(key, d=0):
    try:
        return int(cfg(key))
    except (TypeError, ValueError):
        return d


def set_cfg(key, val):
    G["run"]("INSERT INTO px_cfg (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(val)))


def role_of(uid):
    r = G["fetch_one"]("SELECT role FROM px_roles WHERE user_id=?", (uid,))
    return r["role"] if r else None


def is_mod(uid):
    return G["is_admin"](uid) or role_of(uid) == "moderator"


def can_group(uid):
    return G["is_admin"](uid) or role_of(uid) in ("sardor", "moderator")


def is_teacher(uid):
    return G["is_admin"](uid) or role_of(uid) == "teacher"


def logged_in(uid):
    return bool(G["get_user_token"](uid)) or G["is_admin"](uid)


def uname(uid):
    r = G["fetch_one"]("SELECT full_name FROM users WHERE user_id=?", (uid,))
    return (r["full_name"] if r and r["full_name"] else None) or "Talaba"


def short_name(uid):
    p = uname(uid).split()
    return " ".join([p[0]] + [x[0] + "." for x in p[1:2]]) if p else "Talaba"


def audit(actor, action, detail=""):
    try:
        G["run"]("INSERT INTO px_audit (ts, actor, action, detail) VALUES (?, ?, ?, ?)",
                 (G["now"]().isoformat(timespec="seconds"), actor, action, str(detail)[:500]))
    except Exception:
        logging.exception("audit yozilmadi")


async def reply(ev, text, kb=None):
    """Callback bo'lsa xabarni tahrirlaydi, bo'lmasa yangi xabar yuboradi."""
    if isinstance(ev, types.CallbackQuery):
        await G["edit"](ev, text, kb)
    else:
        await ev.answer(text[:4000], reply_markup=kb)


async def need_login(ev):
    uid = ev.from_user.id
    if logged_in(uid):
        return True
    txt = "Avval HEMIS ga kiring: /start"
    if isinstance(ev, types.CallbackQuery):
        await ev.answer(txt, show_alert=True)
    else:
        await ev.answer(txt)
    return False


def spawn(coro):
    t = asyncio.create_task(coro)
    TASKS.add(t)
    t.add_done_callback(TASKS.discard)
    return t


TASKS = set()
POMO = {}
DOC_MEM = {}   # uid -> (vaqt, [parts])
CHK = {}
API_HITS = {}
ERR_LOG = []
LAST_ALERT = [0.0]


# ======================================================================
# Jadvallar
# ======================================================================
def init_tables():
    with closing(G["db"]()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS px_cfg (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS px_xp (user_id INTEGER PRIMARY KEY, xp INTEGER DEFAULT 0, streak INTEGER DEFAULT 0,
            best_streak INTEGER DEFAULT 0, last_day TEXT, pomodoros INTEGER DEFAULT 0, cards_done INTEGER DEFAULT 0,
            name TEXT, hidden INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS px_xplog (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, ts TEXT, amount INTEGER, src TEXT);
        CREATE INDEX IF NOT EXISTS px_xplog_ts ON px_xplog (ts);
        CREATE TABLE IF NOT EXISTS px_quest (user_id INTEGER, day TEXT, key TEXT, n INTEGER DEFAULT 0, done INTEGER DEFAULT 0,
            PRIMARY KEY (user_id, day, key));
        CREATE TABLE IF NOT EXISTS px_cards (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, front TEXT NOT NULL,
            back TEXT NOT NULL, ease REAL DEFAULT 2.5, interval INTEGER DEFAULT 0, reps INTEGER DEFAULT 0, due TEXT, created TEXT);
        CREATE INDEX IF NOT EXISTS px_cards_due ON px_cards (user_id, due);
        CREATE TABLE IF NOT EXISTS px_plan (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, day TEXT, text TEXT, done INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS px_roles (user_id INTEGER PRIMARY KEY, role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS px_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, actor INTEGER, action TEXT, detail TEXT);
        CREATE TABLE IF NOT EXISTS px_promo (code TEXT PRIMARY KEY, kind TEXT, value INTEGER, max_uses INTEGER DEFAULT 0,
            used INTEGER DEFAULT 0, expires TEXT, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS px_promo_use (code TEXT, user_id INTEGER, ts TEXT, PRIMARY KEY (code, user_id));
        CREATE TABLE IF NOT EXISTS px_groups (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, owner INTEGER, created TEXT);
        CREATE TABLE IF NOT EXISTS px_gmem (group_id INTEGER, user_id INTEGER, PRIMARY KEY (group_id, user_id));
        CREATE TABLE IF NOT EXISTS px_polls (id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER, kind TEXT, question TEXT,
            options TEXT, created TEXT, closed INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS px_votes (poll_id INTEGER, user_id INTEGER, choice INTEGER, PRIMARY KEY (poll_id, user_id));
        CREATE TABLE IF NOT EXISTS px_board (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, title TEXT, body TEXT, extra TEXT,
            owner INTEGER, status TEXT DEFAULT 'pending', created TEXT, expires TEXT);
        CREATE TABLE IF NOT EXISTS px_rsvp (board_id INTEGER, user_id INTEGER, PRIMARY KEY (board_id, user_id));
        CREATE TABLE IF NOT EXISTS px_anon (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, text TEXT, answer TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS px_reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, rating INTEGER, comment TEXT,
            user_id INTEGER, created TEXT, UNIQUE (subject, user_id));
        CREATE TABLE IF NOT EXISTS px_slots (id INTEGER PRIMARY KEY AUTOINCREMENT, teacher INTEGER, at TEXT, student INTEGER, note TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS px_mat (id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, title TEXT, file_id TEXT, ftype TEXT,
            owner INTEGER, likes INTEGER DEFAULT 0, status TEXT DEFAULT 'pending', created TEXT);
        CREATE TABLE IF NOT EXISTS px_matlike (mat_id INTEGER, user_id INTEGER, PRIMARY KEY (mat_id, user_id));
        CREATE TABLE IF NOT EXISTS px_duels (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, topic TEXT, qjson TEXT,
            p1 INTEGER, p2 INTEGER, s1 INTEGER DEFAULT 0, s2 INTEGER DEFAULT 0, d1 INTEGER DEFAULT 0, d2 INTEGER DEFAULT 0, created TEXT);
        CREATE TABLE IF NOT EXISTS px_apikeys (user_id INTEGER PRIMARY KEY, key_hash TEXT, created TEXT);
        """)
        conn.commit()


# ======================================================================
# XP, streak, topshiriqlar
# ======================================================================
def ensure_xp(uid, name=""):
    G["run"]("INSERT OR IGNORE INTO px_xp (user_id, name) VALUES (?, ?)", (uid, name or None))


def xp_stats(uid):
    ensure_xp(uid)
    r = G["fetch_one"]("SELECT * FROM px_xp WHERE user_id=?", (uid,))
    return dict(r)


def add_xp(uid, n, src):
    ensure_xp(uid)
    G["run"]("UPDATE px_xp SET xp = xp + ? WHERE user_id=?", (int(n), uid))
    G["run"]("INSERT INTO px_xplog (user_id, ts, amount, src) VALUES (?, ?, ?, ?)",
             (uid, G["now"]().isoformat(timespec="seconds"), int(n), src))


def checkin(uid, name=""):
    day = today_s()
    if CHK.get(uid) == day:
        return None
    CHK[uid] = day
    if len(CHK) > 20000:
        CHK.clear()
    ensure_xp(uid, name)
    s = xp_stats(uid)
    streak, new = pc.next_streak(s["last_day"], day, s["streak"])
    if not new:
        return None
    G["run"]("UPDATE px_xp SET streak=?, best_streak=MAX(best_streak, ?), last_day=?, name=COALESCE(?, name) WHERE user_id=?",
             (streak, streak, day, name or None, uid))
    add_xp(uid, cfg_int("xp_daily", 5) + min(streak, 10), "checkin")
    return streak


def quest_inc(uid, key, inc=1):
    """Topshiriq jarayonini oshiradi; bajarilsa mukofot matnini qaytaradi."""
    target, reward, title = QUESTS[key]
    day = today_s()
    G["run"]("INSERT OR IGNORE INTO px_quest (user_id, day, key) VALUES (?, ?, ?)", (uid, day, key))
    G["run"]("UPDATE px_quest SET n = n + ? WHERE user_id=? AND day=? AND key=? AND done=0", (inc, uid, day, key))
    r = G["fetch_one"]("SELECT n, done FROM px_quest WHERE user_id=? AND day=? AND key=?", (uid, day, key))
    if r and not r["done"] and r["n"] >= target:
        if G["run"]("UPDATE px_quest SET done=1 WHERE user_id=? AND day=? AND key=? AND done=0", (uid, day, key)):
            add_xp(uid, reward, "quest:" + key)
            return f"🎯 Topshiriq bajarildi: {title} (+{reward} XP)"
    return None


async def notify_quest(uid, key, inc=1):
    try:
        msg = quest_inc(uid, key, inc)
        if msg:
            await G["safe_send"](uid, msg)
    except Exception:
        logging.exception("quest")


class PlusMiddleware(BaseMiddleware):
    """Kunlik check-in (streak/XP). Hech qachon asosiy ishni to'smaydi."""

    async def __call__(self, handler, event, data):
        u = getattr(event, "from_user", None)
        if u and not u.is_bot:
            try:
                if G["get_user_token"](u.id):
                    checkin(u.id, u.full_name or "")
            except Exception:
                logging.exception("checkin")
        return await handler(event, data)


# ======================================================================
# Menyu va callback dispatcher
# ======================================================================
ACTIONS = {}


def act(name):
    def deco(fn):
        ACTIONS[name] = fn
        return fn
    return deco


SECTIONS = {
    "study": ("📚 <b>O'qish</b>", [
        [("🃏 Takrorlash kartalari", "px:cards"), ("🍅 Pomodoro", "px:pomo")],
        [("🧮 Ball kalkulyator", "px:calc"), ("🎓 GPA hisob", "px:gpa")],
        [("🗓 Kalendar / .ics", "px:cal"), ("📆 Imtihon rejasi", "px:plan")],
        [("📚 Materiallar kutubxonasi", "px:mat")],
    ]),
    "team": ("👥 <b>Jamoa</b>", [
        [("🏫 Guruh paneli", "px:grp"), ("📌 E'lonlar taxtasi", "px:brd")],
        [("🕵️ Anonim savol", "px:anon"), ("⭐ Fan sharhlari", "px:rev")],
        [("🕒 Konsultatsiya navbati", "px:slot")],
    ]),
    "game": ("🎮 <b>O'yin</b>", [
        [("👤 Profil / XP", "px:me"), ("🏆 Reyting", "px:top")],
        [("🎯 Kunlik topshiriq", "px:quest"), ("⚔️ Duel", "px:duel")],
    ]),
    "pm": ("💎 <b>Promokod va sovg'a</b>", [
        [("🎟 Promokod kiritish", "px:promo"), ("🎁 Kredit sovg'a qilish", "px:gift")],
    ]),
    "set": ("⚙️ <b>Sozlamalar va maxfiylik</b>", [
        [("📤 Ma'lumotlarimni yuklab olish", "px:export")],
        [("🔑 API kalit", "px:api"), ("👁 Reytingda ko'rinish", "px:vis")],
        [("🗑 Ma'lumotlarimni o'chirish", "px:del")],
    ]),
}


def menu_kb(uid):
    rows = [
        [B("📚 O'qish", "px:s:study"), B("🤖 AI Studio", "px:s:ai")],
        [B("👥 Jamoa", "px:s:team"), B("🎮 O'yin", "px:s:game")],
        [B("💎 Promokod/sovg'a", "px:s:pm"), B("⚙️ Sozlamalar", "px:s:set")],
    ]
    if G["is_admin"](uid) or role_of(uid):
        rows.append([B("🛠 Plus boshqaruvi", "px:adm")])
    return KB(rows)


MENU_TEXT = "✨ <b>Plus</b> — o'qish, AI, jamoa va o'yin vositalari.\nBo'limni tanlang:"


async def cmd_plus(message: types.Message, state: FSMContext):
    await state.clear()
    if not await need_login(message):
        return
    await message.answer(MENU_TEXT, reply_markup=menu_kb(message.from_user.id))


async def cb_plus(call: types.CallbackQuery, state: FSMContext):
    parts = (call.data or "").split(":")
    fn = ACTIONS.get(parts[1] if len(parts) > 1 else "")
    uid = call.from_user.id
    if not fn:
        return await call.answer()
    if not await need_login(call):
        return
    try:
        await fn(call, state, parts[2:])
    except Exception:
        logging.exception("Plus callback xatosi: %s", call.data)
        try:
            await call.answer("⚠️ Xatolik yuz berdi.", show_alert=True)
        except Exception:
            pass
        return
    try:
        await call.answer()
    except Exception:
        pass


@act("menu")
async def a_menu(call, state, a):
    await state.clear()
    await reply(call, MENU_TEXT, menu_kb(call.from_user.id))


@act("s")
async def a_section(call, state, a):
    await state.clear()
    key = a[0] if a else ""
    if key == "ai":
        rows = []
        items = [(k, v[0]) for k, v in AI_TOOLS.items()]
        for i in range(0, len(items), 2):
            rows.append([B(t, f"px:ai:{k}") for k, t in items[i:i + 2]])
        return await reply(call, "🤖 <b>AI Studio</b>\nVositani tanlang:", KB(rows + [BACK]))
    if key not in SECTIONS:
        return
    title, rows = SECTIONS[key]
    await reply(call, title, KB([[B(t, d) for t, d in r] for r in rows] + [BACK]))


# ======================================================================
# Takrorlash kartalari (SM-2)
# ======================================================================
MAX_CARDS = 500


def cards_summary(uid):
    r = G["fetch_one"]("SELECT COUNT(*) n, COALESCE(SUM(due <= ?), 0) due FROM px_cards WHERE user_id=?", (today_s(), uid))
    return r["n"], int(r["due"] or 0)


@act("cards")
async def a_cards(call, state, a):
    await state.clear()
    n, due = cards_summary(call.from_user.id)
    rows = []
    if due:
        rows.append([B(f"▶️ Takrorlash ({due})", "px:cr")])
    rows.append([B("➕ Karta qo'shish", "px:ca")])
    if n:
        rows.append([B("🗑 Hammasini o'chirish", "px:cdel")])
    rows.append(BACK)
    await reply(call, f"🃏 <b>Kartalar</b>\nJami: <b>{n}</b> · Bugun takrorlash kerak: <b>{due}</b>\n\n"
                      "Oraliqli takrorlash (SM-2): bilganingiz kamroq, bilmaganingiz ko'proq ko'rsatiladi.", KB(rows))


@act("ca")
async def a_card_add(call, state, a):
    await state.set_state(PxStates.card_add)
    await reply(call, "➕ Kartalarni yuboring — har qatorga bittadan:\n<code>savol | javob</code>\n\n"
                      "Masalan:\n<code>Om qonuni | I = U / R\nFaraday qonuni | EYuK = -dΦ/dt</code>\n\nBekor qilish: /cancel")


async def h_card_add(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    pairs = pc.parse_cards(message.text or "")
    if not pairs:
        return await message.answer("Format topilmadi. Har qatorda: <code>savol | javob</code>")
    n, _ = cards_summary(uid)
    room = MAX_CARDS - n
    if room <= 0:
        await state.clear()
        return await message.answer(f"Kartalar limiti ({MAX_CARDS}) to'ldi. Ba'zilarini o'chiring.")
    pairs = pairs[:room]
    ts = G["now"]().isoformat(timespec="seconds")
    with closing(G["db"]()) as conn:
        conn.executemany("INSERT INTO px_cards (user_id, front, back, due, created) VALUES (?, ?, ?, ?, ?)",
                         [(uid, q, a_, today_s(), ts) for q, a_ in pairs])
        conn.commit()
    await state.clear()
    await message.answer(f"✅ {len(pairs)} ta karta qo'shildi.", reply_markup=KB([[B("▶️ Takrorlash", "px:cr")], BACK]))


def next_card(uid):
    return G["fetch_one"]("SELECT * FROM px_cards WHERE user_id=? AND due <= ? ORDER BY due, id LIMIT 1", (uid, today_s()))


@act("cr")
async def a_card_review(call, state, a):
    uid = call.from_user.id
    c = next_card(uid)
    if not c:
        return await reply(call, "🎉 Bugungi kartalar tugadi!", KB([[B("🃏 Kartalar", "px:cards")], BACK]))
    _, due = cards_summary(uid)
    await reply(call, f"🃏 <i>({due} ta qoldi)</i>\n\n❓ <b>{G['esc'](c['front'])}</b>",
                KB([[B("👁 Javobni ko'rish", f"px:cs:{c['id']}")]]))


@act("cs")
async def a_card_show(call, state, a):
    c = G["fetch_one"]("SELECT * FROM px_cards WHERE id=? AND user_id=?", (int(a[0]), call.from_user.id))
    if not c:
        return
    await reply(call, f"❓ {G['esc'](c['front'])}\n\n💡 <b>{G['esc'](c['back'])}</b>", KB([[
        B("🔁 Bilmadim", f"px:cg:{c['id']}:again"), B("😕 Qiyin", f"px:cg:{c['id']}:hard")],
        [B("👍 Bildim", f"px:cg:{c['id']}:good"), B("⚡ Oson", f"px:cg:{c['id']}:easy")]]))


@act("cg")
async def a_card_grade(call, state, a):
    uid = call.from_user.id
    c = G["fetch_one"]("SELECT * FROM px_cards WHERE id=? AND user_id=?", (int(a[0]), uid))
    q = pc.QUALITY.get(a[1] if len(a) > 1 else "")
    if not c or q is None:
        return
    ease, interval, reps = pc.sm2(c["ease"], c["interval"], c["reps"], q)
    due = (G["now"]().date() + dt.timedelta(days=interval)).isoformat()
    if q < 3:
        due = today_s()  # bilmagan karta shu kunning oxirida yana chiqadi
    G["run"]("UPDATE px_cards SET ease=?, interval=?, reps=?, due=? WHERE id=?", (ease, interval, reps, due, c["id"]))
    ensure_xp(uid)
    G["run"]("UPDATE px_xp SET cards_done = cards_done + 1 WHERE user_id=?", (uid,))
    add_xp(uid, 1, "card")
    spawn(notify_quest(uid, "cards"))
    await a_card_review(call, state, [])


@act("cdel")
async def a_card_del(call, state, a):
    await reply(call, "⚠️ Barcha kartalaringiz o'chiriladi. Davom etasizmi?",
                KB([[B("✅ Ha, o'chir", "px:cdel2"), B("❌ Yo'q", "px:cards")]]))


@act("cdel2")
async def a_card_del2(call, state, a):
    G["run"]("DELETE FROM px_cards WHERE user_id=?", (call.from_user.id,))
    await a_cards(call, state, [])


# ======================================================================
# Pomodoro
# ======================================================================
@act("pomo")
async def a_pomo(call, state, a):
    uid = call.from_user.id
    run = POMO.get(uid)
    if run:
        left = max(0, int((run["end"] - time.time()) / 60) + 1)
        return await reply(call, f"🍅 Ishlayapti: <b>{run['phase']}</b>, taxminan {left} daqiqa qoldi.",
                           KB([[B("⏹ To'xtatish", "px:pomostop")], BACK]))
    await reply(call, "🍅 <b>Pomodoro</b> — fokus va dam. Tugagach, xabar yuboraman (+10 XP).",
                KB([[B("25 + 5", "px:pm:25:5"), B("45 + 10", "px:pm:45:10")],
                    [B("15 + 3", "px:pm:15:3"), B("50 + 10", "px:pm:50:10")], BACK]))


async def pomo_run(uid, w, b):
    try:
        POMO[uid] = {"phase": "fokus", "end": time.time() + w * 60}
        await asyncio.sleep(w * 60)
        ensure_xp(uid)
        G["run"]("UPDATE px_xp SET pomodoros = pomodoros + 1 WHERE user_id=?", (uid,))
        add_xp(uid, 10, "pomo")
        await G["safe_send"](uid, f"🍅 {w} daqiqalik fokus tugadi! +10 XP\n☕ {b} daqiqa dam oling.")
        await notify_quest(uid, "pomo")
        POMO[uid] = {"phase": "dam olish", "end": time.time() + b * 60}
        await asyncio.sleep(b * 60)
        await G["safe_send"](uid, "⏰ Dam olish tugadi. Yana bir pomodoro? /plus → O'qish → Pomodoro")
    except asyncio.CancelledError:
        raise
    finally:
        POMO.pop(uid, None)


@act("pm")
async def a_pomo_start(call, state, a):
    uid = call.from_user.id
    if uid in POMO:
        return await a_pomo(call, state, [])
    try:
        w, b = int(a[0]), int(a[1])
    except (IndexError, ValueError):
        return
    if w not in (15, 25, 45, 50) or not (1 <= b <= 15):
        return
    t = spawn(pomo_run(uid, w, b))
    POMO_TASKS[uid] = t
    await reply(call, f"🍅 Boshladik: <b>{w} daqiqa</b> fokus. Telefonni chetga qo'ying!", KB([[B("⏹ To'xtatish", "px:pomostop")]]))


POMO_TASKS = {}


@act("pomostop")
async def a_pomo_stop(call, state, a):
    t = POMO_TASKS.pop(call.from_user.id, None)
    if t:
        t.cancel()
    POMO.pop(call.from_user.id, None)
    await reply(call, "⏹ To'xtatildi.", KB([[B("🍅 Pomodoro", "px:pomo")], BACK]))


# ======================================================================
# Ball va GPA kalkulyatori
# ======================================================================
@act("calc")
async def a_calc(call, state, a):
    await state.set_state(PxStates.calc_in)
    await reply(call, "🧮 <b>Ball kalkulyator</b>\nYozing: <code>to'plagan  shu paytgacha_maks  maqsad_baho</code>\n\n"
                      "Masalan: <code>40 50 5</code> — 50 balldan 40 ta oldim, 5 baho kerak.\n"
                      "Umumiy maksimum 100 deb olinadi (boshqacha bo'lsa 4-son: <code>40 50 5 100</code>).\n"
                      "Baholash: 5 ≥ 86, 4 ≥ 71, 3 ≥ 55. Bekor qilish: /cancel")


async def h_calc(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    nums = re.findall(r"\d+(?:[.,]\d+)?", message.text or "")
    try:
        vals = [float(x.replace(",", ".")) for x in nums]
        if len(vals) not in (3, 4):
            raise ValueError("3 ta son kerak")
        r = pc.need_points(vals[0], vals[1], int(vals[2]), vals[3] if len(vals) == 4 else 100.0)
    except ValueError as ex:
        return await message.answer(f"⚠️ {G['esc'](str(ex))}\nMasalan: <code>40 50 5</code>")
    await state.clear()
    g = int(vals[2])
    if r["status"] == "already":
        txt = f"✅ {g} baho uchun kerakli {r['target']:g} ball allaqachon to'plangan."
    elif r["status"] == "impossible":
        txt = (f"😕 {g} baho uchun {r['target']:g} ball kerak, lekin qolgan {r['remaining']:g} ballning hammasini olsangiz ham "
               f"yetmaydi. Pastroq bahoni sinab ko'ring.")
    else:
        pct = f" (qolgan ballning <b>{r['percent']}%</b>)" if r["percent"] is not None else ""
        txt = f"🎯 {g} baho uchun yana <b>{r['need']:g}</b> ball kerak{pct}. Qolgan imkoniyat: {r['remaining']:g} ball."
    await message.answer(txt, reply_markup=KB([[B("🔁 Yana", "px:calc")], BACK]))


@act("gpa")
async def a_gpa(call, state, a):
    await state.set_state(PxStates.gpa_in)
    await reply(call, "🎓 <b>GPA hisob</b>\nHar fan: <code>baho x kredit</code>, masalan:\n<code>5x4 4x3 5x2</code>\n\n"
                      "Maqsadli GPA uchun 2-qatorga: <code>maqsad 4.5 yangi 20</code> (yangi semestr 20 kredit).\nBekor qilish: /cancel")


async def h_gpa(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    lines = (message.text or "").strip().splitlines()
    try:
        pairs = pc.parse_gpa(lines[0] if lines else "")
    except ValueError as ex:
        return await message.answer(f"⚠️ {G['esc'](str(ex))}")
    cr = sum(c for _, c in pairs)
    txt = f"🎓 GPA: <b>{pc.gpa_of(pairs)}</b> ({cr:g} kredit)"
    m = re.search(r"maqsad\s+(\d(?:[.,]\d+)?)\s+yangi\s+(\d+(?:[.,]\d+)?)", " ".join(lines[1:]).lower())
    if m:
        tgt, newc = float(m.group(1).replace(",", ".")), float(m.group(2).replace(",", "."))
        if 0 < tgt <= 5 and 0 < newc <= 60:
            need = pc.gpa_needed(pairs, newc, tgt)
            if need > 5:
                txt += f"\n😕 Umumiy {tgt:g} GPA uchun yangi semestrda o'rtacha {need} kerak — bu 5 dan yuqori, imkonsiz."
            elif need < 0:
                txt += f"\n✅ {tgt:g} GPA allaqachon ta'minlangan (kamida 0 baho bilan ham)."
            else:
                txt += f"\n🎯 Umumiy {tgt:g} GPA uchun yangi {newc:g} kreditda o'rtacha <b>{need}</b> baho kerak."
    await state.clear()
    await message.answer(txt, reply_markup=KB([[B("🔁 Yana", "px:gpa")], BACK]))


# ======================================================================
# Kalendar, .ics va imtihon rejasi
# ======================================================================
async def collect_events(uid, days=30):
    today = G["now"]().date()
    end = today + dt.timedelta(days=days)
    evs = []
    try:
        data, st = await G["fetch"](uid, "education/exam-table", G["sem_params"](uid), ttl=300)
        if st == "ok":
            for it in G["unwrap"](data):
                d = G["exam_date_of"](it)
                if d and today <= d <= end:
                    tm = G["dig"](it, "lessonPair", "start_time") or it.get("start_time")
                    evs.append({"title": f"Imtihon: {G['subj_name'](it)}", "date": d, "time": tm, "minutes": 90, "kind": "🧪",
                                "desc": f"Xona: {G['nm'](it, 'auditorium', '—')}, o'qituvchi: {G['nm'](it, 'employee', '—')}"})
    except Exception:
        logging.exception("kalendar: imtihonlar")
    try:
        data, st = await G["fetch"](uid, "education/task-list", G["sem_params"](uid), ttl=180)
        if st == "ok":
            for it in G["unwrap"](data):
                d = G["parse_date"](G["first"](it, ["deadline", "end_date", "finish_date"]))
                if d and today <= d <= end:
                    evs.append({"title": f"Vazifa: {G['first'](it, ['name', 'title']) or 'Vazifa'}", "date": d, "time": None,
                                "kind": "✅", "desc": G["nm"](it, "subject", "") or ""})
    except Exception:
        logging.exception("kalendar: vazifalar")
    for r in G["fetch_all"]("SELECT text, remind_at FROM reminders WHERE user_id=? AND sent=0", (uid,)):
        try:
            t = dt.datetime.fromisoformat(r["remind_at"])
        except ValueError:
            continue
        if today <= t.date() <= end:
            evs.append({"title": f"Eslatma: {r['text'][:80]}", "date": t.date(), "time": t.strftime("%H:%M"), "minutes": 15, "kind": "🔔"})
    for r in G["fetch_all"]("SELECT day, text FROM px_plan WHERE user_id=? AND done=0", (uid,)):
        try:
            d = dt.date.fromisoformat(r["day"])
        except ValueError:
            continue
        if today <= d <= end:
            evs.append({"title": f"O'qish: {r['text'][:80]}", "date": d, "time": None, "kind": "📆"})
    for r in G["fetch_all"]("SELECT at, teacher, note FROM px_slots WHERE student=?", (uid,)):
        try:
            t = dt.datetime.fromisoformat(r["at"])
        except ValueError:
            continue
        if today <= t.date() <= end:
            evs.append({"title": f"Konsultatsiya: {short_name(r['teacher'])}", "date": t.date(), "time": t.strftime("%H:%M"),
                        "minutes": 30, "kind": "🕒", "desc": r["note"] or ""})
    evs.sort(key=lambda x: (x["date"], x.get("time") or ""))
    return evs


@act("cal")
async def a_cal(call, state, a):
    await state.clear()
    await call.answer("Yuklanmoqda...")
    uid = call.from_user.id
    evs = await collect_events(uid)
    today = G["now"]().date()
    if not evs:
        txt = "🗓 Kelgusi 30 kunda imtihon, vazifa yoki eslatma topilmadi."
    else:
        lines = ["🗓 <b>Kelgusi 30 kun</b>\n"]
        for ev in evs[:40]:
            left = (ev["date"] - today).days
            when = "bugun" if left == 0 else ("ertaga" if left == 1 else f"{left} kun")
            lines.append(f"{ev['kind']} <b>{G['fmt_date'](ev['date'])}</b>{(' ' + ev['time']) if ev.get('time') else ''} ({when})\n   {G['esc'](ev['title'])}")
        txt = "\n".join(lines)
    await reply(call, txt[:4000], KB([[B("📥 Kalendarga (.ics)", "px:ics")], BACK]))


@act("ics")
async def a_ics(call, state, a):
    uid = call.from_user.id
    evs = await collect_events(uid, 90)
    if not evs:
        return await call.answer("Eksport qilinadigan hodisa yo'q.", show_alert=True)
    data = pc.build_ics(evs).encode("utf-8")
    await call.message.answer_document(BufferedInputFile(data, filename="hemis_kalendar.ics"),
                                       caption="📥 Google Calendar / Apple Calendar'ga import qiling (Fayl → Import).")


@act("plan")
async def a_plan(call, state, a):
    uid = call.from_user.id
    rows = G["fetch_all"]("SELECT day, text, done FROM px_plan WHERE user_id=? AND day >= ? ORDER BY day, id", (uid, today_s()))
    if rows:
        lines = ["📆 <b>Rejangiz</b>\n"]
        for r in rows[:30]:
            lines.append(f"{'✅' if r['done'] else '▫️'} {r['day'][5:]} — {G['esc'](r['text'])}")
        kb = KB([[B("🆕 Yangi reja", "px:plan2"), B("🗑 O'chirish", "px:pdel")], BACK])
        return await reply(call, "\n".join(lines)[:4000], kb)
    await a_plan2(call, state, a)


@act("plan2")
async def a_plan2(call, state, a):
    await state.set_state(PxStates.plan_in)
    await reply(call, "📆 <b>Imtihon rejasi</b>\n1-qatorga imtihon sanasi (<code>15.12.2026</code> yoki <code>15.12</code>), "
                      "keyingi qatorlarga mavzular (har qatorda bittadan yoki vergul bilan).\n\n"
                      "Har kuni ertalab 07:30 da kunlik vazifani yuboraman. Bekor qilish: /cancel")


async def h_plan(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    lines = [l.strip() for l in (message.text or "").splitlines() if l.strip()]
    if len(lines) < 2:
        return await message.answer("1-qatorda sana, keyin kamida bitta mavzu bo'lsin.")
    today = G["now"]().date()
    exam = pc.parse_any_date(lines[0], today)
    if not exam:
        return await message.answer("Sana tushunarsiz. Masalan: <code>15.12.2026</code>")
    topics = [t for l in lines[1:] for t in re.split(r"[;,]", l) if t.strip()][:60]
    try:
        plan = pc.study_plan(today, exam, topics)
    except ValueError as ex:
        return await message.answer(f"⚠️ {G['esc'](str(ex))}")
    G["run"]("DELETE FROM px_plan WHERE user_id=?", (uid,))
    with closing(G["db"]()) as conn:
        conn.executemany("INSERT INTO px_plan (user_id, day, text) VALUES (?, ?, ?)",
                         [(uid, d.isoformat(), "; ".join(ts)[:300]) for d, ts in plan])
        conn.commit()
    await state.clear()
    out = ["✅ Reja tayyor:\n"] + [f"▫️ {d.strftime('%d.%m')} — {G['esc']('; '.join(ts))}" for d, ts in plan]
    await message.answer("\n".join(out)[:4000], reply_markup=KB([BACK]))


@act("pdel")
async def a_plan_del(call, state, a):
    G["run"]("DELETE FROM px_plan WHERE user_id=?", (call.from_user.id,))
    await reply(call, "🗑 Reja o'chirildi.", KB([BACK]))


@act("pd")
async def a_plan_done(call, state, a):
    uid = call.from_user.id
    if G["run"]("UPDATE px_plan SET done=1 WHERE user_id=? AND day=? AND done=0", (uid, a[0] if a else "")):
        add_xp(uid, 5, "plan")
        await call.answer("Barakalla! +5 XP", show_alert=False)


# ======================================================================
# AI Studio
# ======================================================================
def _text_of(data):
    cands = data.get("candidates") or []
    if not cands:
        return ""
    parts = G["dig"](cands[0], "content", "parts", default=[]) or []
    return "".join(p.get("text", "") for p in parts if isinstance(p, dict) and not p.get("thought")).strip()


def _json_of(text):
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", (text or "").strip(), flags=re.S).strip()
    i, j = t.find("["), t.rfind("]")
    if i != -1 and j > i:
        try:
            return json.loads(t[i:j + 1])
        except ValueError:
            return None
    return None


async def llm_cards(uid, topic, parts, n=12):
    prompt = (f"Quyidagi mavzu/material bo'yicha {n} ta qisqa o'quv kartasi tuz (o'zbek tilida). "
              "Faqat JSON massiv qaytar: [{\"front\": \"savol\", \"back\": \"qisqa javob\"}]. "
              "Savol aniq, javob 200 belgigacha. Material bo'lmagan ma'lumotni to'qima.\n\nMavzu/material: " + topic[:3000])
    body = {"contents": [{"role": "user", "parts": list(parts or []) + [{"text": prompt}]}],
            "generationConfig": {"responseMimeType": "application/json", "maxOutputTokens": 4096}}
    async with G["ai_slot"](uid):
        data, _m = await G["gemini_generate"](body, G["ai_text_models"]())
        G["ai_count"](uid, int(G["dig"](data, "usageMetadata", "totalTokenCount", default=0) or 0))
    arr = _json_of(_text_of(data)) or []
    out = []
    for it in arr:
        if isinstance(it, dict) and str(it.get("front", "")).strip() and str(it.get("back", "")).strip():
            out.append((str(it["front"]).strip()[:400], str(it["back"]).strip()[:800]))
    return out[:n]


@act("ai")
async def a_ai(call, state, a):
    key = a[0] if a else ""
    tool = AI_TOOLS.get(key)
    if not tool:
        return
    if not G["ai_available"]():
        return await reply(call, "🤖 AI hozircha o'chirilgan.", KB([BACK]))
    await state.set_state(PxStates.ai_in)
    await state.update_data(tool=key)
    await reply(call, f"{tool[0]}\n\n{G['esc'](tool[2])}\n\nBekor qilish: /cancel")


async def h_ai_in(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    key = (await state.get_data()).get("tool")
    tool = AI_TOOLS.get(key)
    if not tool:
        await state.clear()
        return
    parts, kind, err = [], None, None
    if tool[3]:
        parts, kind, err = await G["ai_media_parts"](message)
    if err:
        return await message.answer(err)
    text = (message.text or message.caption or "").strip()
    if not text and not parts:
        return await message.answer("Matn yoki fayl yuboring.")
    if key == "doc":
        if not parts and len(text) < 200:
            return await message.answer("Hujjat sifatida PDF/rasm yuboring yoki uzunroq matn joylang.")
        DOC_MEM[uid] = (time.time(), parts or [{"text": "[Hujjat matni]\n" + text[:60000]}])
        await state.set_state(PxStates.docchat)
        return await message.answer("📄 Hujjat qabul qilindi. Endi savol bering (30 daqiqa amal qiladi). Tugatish: /cancel")
    if key == "cardsgen":
        await state.clear()
        status = await message.answer("🃏 Kartalar tuzilmoqda...")
        try:
            pairs = await llm_cards(uid, text or "Berilgan material", parts)
        except G["AIGate"] as g:
            return await status.edit_text(str(g))
        except G["GeminiError"] as ex:
            return await status.edit_text(G["ai_err_text"](ex))
        except Exception:
            logging.exception("cardsgen")
            return await status.edit_text("⚠️ Kartalar tuzishda xatolik.")
        n, _ = cards_summary(uid)
        pairs = pairs[:max(0, MAX_CARDS - n)]
        if not pairs:
            return await status.edit_text("Karta tuzib bo'lmadi yoki limit to'lgan.")
        ts = G["now"]().isoformat(timespec="seconds")
        with closing(G["db"]()) as conn:
            conn.executemany("INSERT INTO px_cards (user_id, front, back, due, created) VALUES (?, ?, ?, ?, ?)",
                             [(uid, q, a_, today_s(), ts) for q, a_ in pairs])
            conn.commit()
        spawn(notify_quest(uid, "ai"))
        return await status.edit_text(f"✅ {len(pairs)} ta karta qo'shildi.", reply_markup=KB([[B("▶️ Takrorlash", "px:cr")], BACK]))
    await state.clear()
    prompt = f"{tool[1]}\n\nFoydalanuvchi kiritgani:\n{text}" if text else tool[1]
    await G["ai_dialog"](message, prompt, parts, kind, history=False)
    spawn(notify_quest(uid, "ai"))


async def h_docchat(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    mem = DOC_MEM.get(uid)
    if not mem or time.time() - mem[0] > 1800:
        DOC_MEM.pop(uid, None)
        await state.clear()
        return await message.answer("⏳ Hujjat muddati tugadi. Qayta yuklang: /plus → AI Studio.")
    q = (message.text or "").strip()
    if not q:
        return await message.answer("Savolni matn ko'rinishida yozing.")
    prompt = ("Faqat yuqoridagi hujjatga tayanib javob ber. Hujjatda javob bo'lmasa, «hujjatda bunday ma'lumot yo'q» de, to'qima. "
              "Imkon bo'lsa sahifa/bo'lim nomini ayt.\n\nSavol: " + q)
    await G["ai_dialog"](message, prompt, mem[1], "fayl", history=False)
    spawn(notify_quest(uid, "ai"))


# ======================================================================
# Materiallar kutubxonasi
# ======================================================================
@act("mat")
async def a_mat(call, state, a):
    await state.clear()
    await reply(call, "📚 <b>Materiallar kutubxonasi</b>\nTalabalar yuklagan konspekt, ma'ruza va test banklari.\n"
                      "Yuklangan fayl moderator tasdig'idan keyin ko'rinadi.",
                KB([[B("🔍 Qidirish", "px:ms"), B("🔝 Eng yaxshilar", "px:mt")], [B("➕ Material yuklash", "px:mu")], BACK]))


@act("ms")
async def a_mat_search(call, state, a):
    await state.set_state(PxStates.mat_search)
    await reply(call, "🔍 Fan yoki mavzu nomini yozing (masalan: <code>fizika</code>). Bekor qilish: /cancel")


def mat_list_kb(rows):
    kb = [[B(f"📄 {r['subject'][:18]} · {r['title'][:24]} · 👍{r['likes']}", f"px:mg:{r['id']}")] for r in rows]
    return KB(kb + [[B("⬅️ Materiallar", "px:mat")]])


async def h_mat_search(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    q = f"%{(message.text or '').strip()[:40]}%"
    rows = G["fetch_all"]("SELECT * FROM px_mat WHERE status='approved' AND (subject LIKE ? OR title LIKE ?) ORDER BY likes DESC, id DESC LIMIT 10", (q, q))
    await state.clear()
    if not rows:
        return await message.answer("Hech narsa topilmadi.", reply_markup=KB([[B("➕ Yuklash", "px:mu")], BACK]))
    await message.answer(f"🔍 {len(rows)} ta natija:", reply_markup=mat_list_kb(rows))


@act("mt")
async def a_mat_top(call, state, a):
    rows = G["fetch_all"]("SELECT * FROM px_mat WHERE status='approved' ORDER BY likes DESC, id DESC LIMIT 10")
    if not rows:
        return await reply(call, "Hozircha materiallar yo'q. Birinchi bo'ling!", KB([[B("➕ Yuklash", "px:mu")], BACK]))
    await reply(call, "🔝 Eng yaxshi materiallar:", mat_list_kb(rows))


@act("mg")
async def a_mat_get(call, state, a):
    r = G["fetch_one"]("SELECT * FROM px_mat WHERE id=? AND status='approved'", (int(a[0]),))
    if not r:
        return await call.answer("Topilmadi.", show_alert=True)
    cap = f"📄 <b>{G['esc'](r['title'])}</b>\n📖 {G['esc'](r['subject'])} · 👍 {r['likes']}"
    kb = KB([[B("👍 Foydali", f"px:ml:{r['id']}")]])
    if r["ftype"] == "photo":
        await call.message.answer_photo(r["file_id"], caption=cap, reply_markup=kb)
    else:
        await call.message.answer_document(r["file_id"], caption=cap, reply_markup=kb)


@act("ml")
async def a_mat_like(call, state, a):
    mid, uid = int(a[0]), call.from_user.id
    if G["run"]("INSERT OR IGNORE INTO px_matlike (mat_id, user_id) VALUES (?, ?)", (mid, uid)):
        G["run"]("UPDATE px_mat SET likes = likes + 1 WHERE id=?", (mid,))
        await call.answer("👍 Rahmat!")
    else:
        await call.answer("Siz allaqachon baholagansiz.", show_alert=True)


@act("mu")
async def a_mat_up(call, state, a):
    await state.set_state(PxStates.mat_subj)
    await reply(call, "➕ Qaysi fan? (masalan: Fizika). Bekor qilish: /cancel")


async def h_mat_subj(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t:
        return
    await state.update_data(subj=t[:60])
    await state.set_state(PxStates.mat_title)
    await message.answer("Material nomi? (masalan: «Faraday qonunlari konspekti»)")


async def h_mat_title(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t:
        return
    await state.update_data(title=t[:100])
    await state.set_state(PxStates.mat_file)
    await message.answer("Endi faylni yuboring (PDF, Word, rasm...). Faqat o'zingiz yaratgan yoki tarqatishga ruxsat berilgan materiallarni yuklang.")


async def h_mat_file(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    if message.document:
        fid, ftype = message.document.file_id, "document"
    elif message.photo:
        fid, ftype = message.photo[-1].file_id, "photo"
    else:
        return await message.answer("Fayl yoki rasm yuboring.")
    d = await state.get_data()
    status = "approved" if is_mod(uid) else "pending"
    mid = G["insert"]("INSERT INTO px_mat (subject, title, file_id, ftype, owner, status, created) VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (d.get("subj"), d.get("title"), fid, ftype, uid, status, G["now"]().isoformat(timespec="seconds")))
    await state.clear()
    if status == "approved":
        add_xp(uid, 5, "material")
        return await message.answer("✅ Material kutubxonaga qo'shildi.", reply_markup=KB([BACK]))
    await message.answer("✅ Yuborildi. Moderator tasdiqlagach ko'rinadi.", reply_markup=KB([BACK]))
    await notify_mods(f"📚 Yangi material #{mid}: {G['esc'](d.get('title'))} ({G['esc'](d.get('subj'))})",
                      KB([[B("✅ Tasdiqlash", f"px:mod:mat:{mid}:ok"), B("❌ Rad", f"px:mod:mat:{mid}:no")]]))


async def notify_mods(text, kb=None):
    ids = {G["ADMIN_ID"]} if G["ADMIN_ID"] else set()
    ids |= {r["user_id"] for r in G["fetch_all"]("SELECT user_id FROM px_roles WHERE role='moderator'")}
    for i in ids:
        await G["safe_send"](i, text, kb)


# ======================================================================
# O'yin: profil, reyting, topshiriq, duel
# ======================================================================
def week_start():
    d = G["now"]().date()
    return (d - dt.timedelta(days=d.weekday())).isoformat()


@act("me")
async def a_me(call, state, a):
    uid = call.from_user.id
    s = xp_stats(uid)
    rank = G["fetch_one"]("SELECT COUNT(*) + 1 n FROM px_xp WHERE xp > ?", (s["xp"],))["n"]
    wk = G["fetch_one"]("SELECT COALESCE(SUM(amount),0) n FROM px_xplog WHERE user_id=? AND ts >= ?", (uid, week_start()))["n"]
    lv = pc.level_of(s["xp"])
    bd = pc.badges_of(s)
    txt = (f"👤 <b>{G['esc'](short_name(uid))}</b>\n\n⭐ Daraja <b>{lv}</b>  {pc.level_bar(s['xp'])}\n"
           f"✨ XP: <b>{s['xp']}</b> (keyingi darajagacha {pc.xp_for_level(lv + 1) - s['xp']})\n"
           f"🔥 Streak: <b>{s['streak']}</b> kun (eng yaxshi: {s['best_streak']})\n"
           f"🍅 Pomodoro: {s['pomodoros']} · 🃏 Karta: {s['cards_done']}\n"
           f"📈 Haftalik XP: {wk} · 🏆 O'rin: #{rank}\n\n"
           f"🎖 Nishonlar: " + (" ".join(f"{e}" for e, _ in bd) if bd else "hali yo'q"))
    if bd:
        txt += "\n" + "\n".join(f"  {e} {n}" for e, n in bd)
    await reply(call, txt, KB([[B("🏆 Reyting", "px:top"), B("🎯 Topshiriq", "px:quest")], BACK]))


@act("top")
async def a_top(call, state, a):
    weekly = bool(a and a[0] == "w")
    if weekly:
        rows = G["fetch_all"]("""SELECT l.user_id, SUM(l.amount) xp, x.name FROM px_xplog l JOIN px_xp x ON x.user_id = l.user_id
                                 WHERE l.ts >= ? AND x.hidden = 0 GROUP BY l.user_id ORDER BY xp DESC LIMIT 10""", (week_start(),))
    else:
        rows = G["fetch_all"]("SELECT user_id, xp, name FROM px_xp WHERE hidden=0 AND xp > 0 ORDER BY xp DESC LIMIT 10")
    medals = ["🥇", "🥈", "🥉"]
    lines = [f"🏆 <b>{'Haftalik' if weekly else 'Umumiy'} reyting</b>\n"]
    for i, r in enumerate(rows):
        p = (r["name"] or uname(r["user_id"])).split()
        nm_ = " ".join([p[0]] + [x[0] + "." for x in p[1:2]]) if p else "Talaba"
        lines.append(f"{medals[i] if i < 3 else str(i + 1) + '.'} {G['esc'](nm_)} — {r['xp']} XP")
    if not rows:
        lines.append("Hozircha bo'sh.")
    sw = B("📅 Umumiy", "px:top") if weekly else B("📅 Haftalik", "px:top:w")
    await reply(call, "\n".join(lines), KB([[sw], BACK]))


@act("quest")
async def a_quest(call, state, a):
    uid, day = call.from_user.id, today_s()
    got = {r["key"]: r for r in G["fetch_all"]("SELECT key, n, done FROM px_quest WHERE user_id=? AND day=?", (uid, day))}
    lines = ["🎯 <b>Bugungi topshiriqlar</b>\n"]
    for k, (target, reward, title) in QUESTS.items():
        r = got.get(k)
        n = min(r["n"], target) if r else 0
        lines.append(f"{'✅' if r and r['done'] else '▫️'} {title} — {n}/{target} (+{reward} XP)")
    await reply(call, "\n".join(lines), KB([BACK]))


def new_code(n=5):
    return "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(n))


@act("duel")
async def a_duel(call, state, a):
    await state.clear()
    await reply(call, "⚔️ <b>Viktorina duel</b>\nMavzu bo'yicha 5 ta savol; do'stingiz kod bilan qo'shiladi va ikkalangiz bir xil savollarga "
                      "javob berasiz. Ko'p to'g'ri javob bergan g'olib (+20 XP).",
                KB([[B("🆕 Duel ochish", "px:dn"), B("🔑 Kod bilan qo'shilish", "px:dj")], BACK]))


@act("dn")
async def a_duel_new(call, state, a):
    if not G["ai_available"]():
        return await reply(call, "🤖 AI o'chirilgan, duel ochib bo'lmaydi.", KB([BACK]))
    await state.set_state(PxStates.duel_topic)
    await reply(call, "Duel mavzusini yozing (masalan: <code>Faraday qonunlari</code>). Bekor qilish: /cancel")


async def h_duel_topic(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    topic = (message.text or "").strip()[:200]
    if not topic:
        return
    await state.clear()
    status = await message.answer("🧠 Savollar tuzilmoqda...")
    try:
        async with G["ai_slot"](uid):
            items, tokens = await NS["ai_quiz"](topic, None, 5)  # hemis3 da setup'dan keyin aniqlanadi
            G["ai_count"](uid, tokens)
    except G["AIGate"] as g:
        return await status.edit_text(str(g))
    except G["GeminiError"] as ex:
        return await status.edit_text(G["ai_err_text"](ex))
    except Exception:
        logging.exception("duel")
        return await status.edit_text("⚠️ Savollar tuzishda xatolik.")
    code = new_code()
    did = G["insert"]("INSERT INTO px_duels (code, topic, qjson, p1, created) VALUES (?, ?, ?, ?, ?)",
                      (code, topic, json.dumps(items, ensure_ascii=False), uid, G["now"]().isoformat(timespec="seconds")))
    await status.edit_text(f"⚔️ Duel tayyor!\nMavzu: <b>{G['esc'](topic)}</b>\nKod: <code>{code}</code> — do'stingizga yuboring "
                           f"(u /plus → O'yin → Duel → Kod bilan qo'shilish).",
                           reply_markup=KB([[B("▶️ Boshlash", f"px:dq:{did}")]]))


@act("dj")
async def a_duel_join(call, state, a):
    await state.set_state(PxStates.duel_join)
    await reply(call, "Duel kodini yozing (5 belgi). Bekor qilish: /cancel")


async def h_duel_join(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    code = pc.norm_code(message.text or "")
    d = G["fetch_one"]("SELECT * FROM px_duels WHERE code=?", (code,))
    if not d:
        return await message.answer("Bunday duel topilmadi. Kodni tekshiring.")
    if d["p1"] == uid:
        return await message.answer("Bu sizning duelingiz. Kodni do'stingizga yuboring.")
    if d["p2"] and d["p2"] != uid:
        return await message.answer("Bu duelda ikki o'yinchi allaqachon bor.")
    G["run"]("UPDATE px_duels SET p2=? WHERE id=? AND (p2 IS NULL OR p2=?)", (uid, d["id"], uid))
    await state.clear()
    await message.answer(f"⚔️ Duelga qo'shildingiz. Mavzu: <b>{G['esc'](d['topic'])}</b>", reply_markup=KB([[B("▶️ Boshlash", f"px:dq:{d['id']}")]]))
    await G["safe_send"](d["p1"], f"⚔️ {G['esc'](short_name(uid))} duelingizga qo'shildi!")


def duel_me(d, uid):
    return 1 if d["p1"] == uid else (2 if d["p2"] == uid else 0)


@act("dq")
async def a_duel_question(call, state, a):
    uid = call.from_user.id
    d = G["fetch_one"]("SELECT * FROM px_duels WHERE id=?", (int(a[0]),))
    me = duel_me(d, uid) if d else 0
    if not me:
        return await call.answer("Siz bu duel ishtirokchisi emassiz.", show_alert=True)
    items = json.loads(d["qjson"])
    idx = d["d1"] if me == 1 else d["d2"]
    if idx >= len(items):
        return await reply(call, "Siz allaqachon tugatgansiz. Natija ikkala o'yinchi tugatgach keladi.", KB([BACK]))
    it = items[idx]
    letters = "ABCDEFGHIJ"
    opts = "\n".join(f"<b>{letters[i]})</b> {G['esc'](o)}" for i, o in enumerate(it["options"]))
    btns = [B(letters[i], f"px:da:{d['id']}:{idx}:{i}") for i in range(len(it["options"]))]
    await reply(call, f"⚔️ <b>{G['esc'](d['topic'])}</b> — {idx + 1}/{len(items)}\n\n❓ {G['esc'](it['question'])}\n\n{opts}", KB([btns]))


@act("da")
async def a_duel_answer(call, state, a):
    uid = call.from_user.id
    did, qi, oi = int(a[0]), int(a[1]), int(a[2])
    d = G["fetch_one"]("SELECT * FROM px_duels WHERE id=?", (did,))
    me = duel_me(d, uid) if d else 0
    if not me:
        return
    items = json.loads(d["qjson"])
    cur = d["d1"] if me == 1 else d["d2"]
    if qi != cur or qi >= len(items):
        return await call.answer("Bu savolga allaqachon javob berilgan.")
    it = items[qi]
    ok = oi == it["correct"]
    dcol, scol = ("d1", "s1") if me == 1 else ("d2", "s2")
    G["run"](f"UPDATE px_duels SET {dcol}={dcol}+1, {scol}={scol}+? WHERE id=? AND {dcol}=?", (1 if ok else 0, did, qi))
    d = G["fetch_one"]("SELECT * FROM px_duels WHERE id=?", (did,))
    mark = "✅ To'g'ri!" if ok else f"❌ Noto'g'ri. To'g'ri javob: {G['esc'](it['options'][it['correct']])}"
    exp = f"\n💡 {G['esc'](it['explanation'])}" if it.get("explanation") else ""
    nxt = (d["d1"] if me == 1 else d["d2"])
    if nxt < len(items):
        return await reply(call, f"{mark}{exp}", KB([[B("➡️ Keyingisi", f"px:dq:{did}")]]))
    await reply(call, f"{mark}{exp}\n\n🏁 Siz tugatdingiz: <b>{d['s1'] if me == 1 else d['s2']}/{len(items)}</b>", KB([BACK]))
    if d["p2"] and d["d1"] >= len(items) and d["d2"] >= len(items):
        await duel_finish(d, len(items))
    else:
        await G["safe_send"](d["p2"] if me == 1 else d["p1"], "⚔️ Raqibingiz duelni tugatdi. Siz ham tugating!")


async def duel_finish(d, n):
    res = pc.duel_result(d["s1"], d["s2"])
    for me, uid in ((1, d["p1"]), (2, d["p2"])):
        mine, opp = (d["s1"], d["s2"]) if me == 1 else (d["s2"], d["s1"])
        if res == "draw":
            head, xp = "🤝 Durang", 10
        elif (res == "p1") == (me == 1):
            head, xp = "🏆 Siz g'olibsiz!", 20
        else:
            head, xp = "😅 Bu safar yutqazdingiz", 5
        add_xp(uid, xp, "duel")
        await G["safe_send"](uid, f"⚔️ <b>Duel natijasi</b> ({G['esc'](d['topic'])})\n{head}\nSiz: {mine}/{n} · Raqib: {opp}/{n}\n+{xp} XP")


# ======================================================================
# Promokod va kredit sovg'a
# ======================================================================
def hub_mod():
    try:
        import hub
        return hub if hub.G else None
    except Exception:
        return None


def redeem(uid, code):
    """(ok, matn)"""
    code = pc.norm_code(code)
    row = G["fetch_one"]("SELECT * FROM px_promo WHERE code=?", (code,))
    used = bool(G["fetch_one"]("SELECT 1 FROM px_promo_use WHERE code=? AND user_id=?", (code, uid)))
    err = pc.promo_check(row, used, G["now"]().date())
    if err:
        return False, err
    hub = hub_mod()
    if row["kind"] in ("credits", "premium") and not hub:
        return False, "Student Hub o'chiq, bu promokodni hozir ishlatib bo'lmaydi."
    if not G["run"]("INSERT OR IGNORE INTO px_promo_use (code, user_id, ts) VALUES (?, ?, ?)", (code, uid, G["now"]().isoformat(timespec="seconds"))):
        return False, "Siz bu promokoddan foydalanib bo'lgansiz."
    if not G["run"]("UPDATE px_promo SET used = used + 1 WHERE code=? AND (max_uses = 0 OR used < max_uses)", (code,)):
        G["run"]("DELETE FROM px_promo_use WHERE code=? AND user_id=?", (code, uid))
        return False, "Promokod limiti tugagan."
    v = int(row["value"])
    if row["kind"] == "credits":
        hub.add_credits(uid, v)
        return True, f"🎉 Hisobingizga <b>{v}</b> kredit qo'shildi!"
    if row["kind"] == "premium":
        hub.add_premium(uid, v)
        return True, f"🎉 Premium <b>{v} kun</b>ga uzaytirildi!"
    add_xp(uid, v, "promo")
    return True, f"🎉 <b>{v} XP</b> qo'shildi!"


@act("promo")
async def a_promo(call, state, a):
    await state.set_state(PxStates.promo)
    await reply(call, "🎟 Promokodni yozing. Bekor qilish: /cancel")


async def h_promo(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    ok, txt = redeem(message.from_user.id, message.text or "")
    await state.clear()
    await message.answer(txt if ok else "⚠️ " + txt, reply_markup=KB([BACK]))


async def cmd_promo(message: types.Message, state: FSMContext):
    await state.clear()
    if not await need_login(message):
        return
    arg = (message.text or "").split(maxsplit=1)
    if len(arg) < 2:
        await state.set_state(PxStates.promo)
        return await message.answer("🎟 Promokodni yozing:")
    ok, txt = redeem(message.from_user.id, arg[1])
    await message.answer(txt if ok else "⚠️ " + txt)


@act("gift")
async def a_gift(call, state, a):
    if not hub_mod():
        return await reply(call, "Student Hub o'chiq.", KB([BACK]))
    await state.set_state(PxStates.gift)
    await reply(call, "🎁 <b>Kredit sovg'a</b>\nYozing: <code>do'stingiz_ID  son</code> (masalan <code>123456789 3</code>). "
                      "ID ni do'stingiz /referal yoki profilidan bilib oladi. 1–50 kredit. Bekor qilish: /cancel")


async def h_gift(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    m = re.fullmatch(r"\s*(\d{1,15})\s+(\d{1,2})\s*", message.text or "")
    if not m:
        return await message.answer("Format: <code>123456789 3</code>")
    to, n = int(m.group(1)), int(m.group(2))
    hub = hub_mod()
    if to == uid or not (1 <= n <= 50) or not hub:
        return await message.answer("Noto'g'ri qiymat (o'zingizga yubora olmaysiz, 1–50 kredit).")
    if not G["fetch_one"]("SELECT 1 FROM users WHERE user_id=? AND token IS NOT NULL", (to,)):
        return await message.answer("Bu foydalanuvchi botda ro'yxatdan o'tmagan.")
    hub.ensure_user(uid)
    if not G["run"]("UPDATE hub_users SET credits = credits - ? WHERE user_id=? AND credits >= ?", (n, uid, n)):
        return await message.answer("Hisobingizda yetarli kredit yo'q.")
    try:
        hub.add_credits(to, n)
    except Exception:
        hub.add_credits(uid, n)
        logging.exception("sovg'a")
        return await message.answer("⚠️ Xatolik, kredit qaytarildi.")
    await state.clear()
    audit(uid, "gift", f"{uid}->{to}:{n}")
    await message.answer(f"🎁 {n} kredit yuborildi.", reply_markup=KB([BACK]))
    await G["safe_send"](to, f"🎁 {G['esc'](short_name(uid))} sizga <b>{n}</b> kredit sovg'a qildi!")


# ======================================================================
# Guruh paneli (sardor e'lonlari, so'rovnoma, davomat)
# ======================================================================
def group_of(gid):
    return G["fetch_one"]("SELECT * FROM px_groups WHERE id=?", (gid,))


def members(gid):
    return [r["user_id"] for r in G["fetch_all"]("SELECT user_id FROM px_gmem WHERE group_id=?", (gid,))]


def owns(uid, g):
    return bool(g) and (g["owner"] == uid or G["is_admin"](uid))


@act("grp")
async def a_grp(call, state, a):
    await state.clear()
    uid = call.from_user.id
    gs = G["fetch_all"]("SELECT g.* FROM px_groups g JOIN px_gmem m ON m.group_id = g.id WHERE m.user_id=? ORDER BY g.id", (uid,))
    rows = [[B(f"🏫 {g['name'][:30]}", f"px:gv:{g['id']}")] for g in gs[:10]]
    rows.append([B("🔑 Kod bilan qo'shilish", "px:gj")])
    if can_group(uid):
        rows.append([B("➕ Yangi guruh ochish", "px:gn")])
    await reply(call, "🏫 <b>Guruh paneli</b>\nSardor e'lon, so'rovnoma va davomat so'rovi yuboradi." +
                ("" if gs else "\nHali guruhga a'zo emassiz."), KB(rows + [BACK]))


@act("gn")
async def a_grp_new(call, state, a):
    if not can_group(call.from_user.id):
        return await call.answer("Bu amal faqat sardor/moderator uchun.", show_alert=True)
    await state.set_state(PxStates.grp_name)
    await reply(call, "Guruh nomini yozing (masalan: <code>Fizika-21 guruh</code>). Bekor qilish: /cancel")


async def h_grp_name(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    name = (message.text or "").strip()[:60]
    if not name or not can_group(uid):
        return
    code = new_code(6)
    gid = G["insert"]("INSERT INTO px_groups (code, name, owner, created) VALUES (?, ?, ?, ?)",
                      (code, name, uid, G["now"]().isoformat(timespec="seconds")))
    G["run"]("INSERT OR IGNORE INTO px_gmem (group_id, user_id) VALUES (?, ?)", (gid, uid))
    await state.clear()
    audit(uid, "group_new", f"{gid}:{name}")
    await message.answer(f"✅ Guruh ochildi.\nQo'shilish kodi: <code>{code}</code> — guruhdoshlarga yuboring.",
                         reply_markup=KB([[B("🏫 Guruhni ochish", f"px:gv:{gid}")]]))


@act("gj")
async def a_grp_join(call, state, a):
    await state.set_state(PxStates.grp_join)
    await reply(call, "Guruh kodini yozing (6 belgi). Bekor qilish: /cancel")


async def h_grp_join(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    g = G["fetch_one"]("SELECT * FROM px_groups WHERE code=?", (pc.norm_code(message.text or ""),))
    if not g:
        return await message.answer("Bunday guruh topilmadi. Kodni tekshiring.")
    new = G["run"]("INSERT OR IGNORE INTO px_gmem (group_id, user_id) VALUES (?, ?)", (g["id"], uid))
    await state.clear()
    await message.answer(f"✅ «{G['esc'](g['name'])}» guruhiga qo'shildingiz." if new else "Siz allaqachon a'zosiz.",
                         reply_markup=KB([[B("🏫 Guruhlarim", "px:grp")]]))
    if new:
        await G["safe_send"](g["owner"], f"👥 {G['esc'](short_name(uid))} «{G['esc'](g['name'])}» guruhiga qo'shildi.")


@act("gv")
async def a_grp_view(call, state, a):
    await state.clear()
    uid = call.from_user.id
    g = group_of(int(a[0]))
    if not g or uid not in members(g["id"]):
        return await call.answer("Guruh topilmadi.", show_alert=True)
    n = len(members(g["id"]))
    txt = f"🏫 <b>{G['esc'](g['name'])}</b>\n👥 A'zolar: {n}"
    rows = []
    if owns(uid, g):
        txt += f"\n🔑 Kod: <code>{g['code']}</code>"
        rows += [[B("📢 E'lon", f"px:gp:{g['id']}"), B("📊 So'rovnoma", f"px:gq:{g['id']}")],
                 [B("✅ Davomat so'rovi", f"px:ga:{g['id']}"), B("👥 A'zolar", f"px:gm:{g['id']}")],
                 [B("🗑 Guruhni o'chirish", f"px:gx:{g['id']}")]]
    else:
        rows.append([B("🚪 Guruhdan chiqish", f"px:gl:{g['id']}")])
    await reply(call, txt, KB(rows + [[B("⬅️ Guruhlar", "px:grp")]]))


@act("gm")
async def a_grp_members(call, state, a):
    g = group_of(int(a[0]))
    if not owns(call.from_user.id, g):
        return
    names = [short_name(u) for u in members(g["id"])]
    await reply(call, f"👥 <b>{G['esc'](g['name'])}</b> a'zolari ({len(names)}):\n" + "\n".join(f"{i}. {G['esc'](n_)}" for i, n_ in enumerate(names[:80], 1)),
                KB([[B("⬅️ Orqaga", f"px:gv:{g['id']}")]]))


@act("gl")
async def a_grp_leave(call, state, a):
    G["run"]("DELETE FROM px_gmem WHERE group_id=? AND user_id=?", (int(a[0]), call.from_user.id))
    await a_grp(call, state, [])


@act("gx")
async def a_grp_del(call, state, a):
    g = group_of(int(a[0]))
    if not owns(call.from_user.id, g):
        return
    if len(a) < 2:
        return await reply(call, f"⚠️ «{G['esc'](g['name'])}» guruhi o'chiriladi. Davom etasizmi?",
                           KB([[B("✅ Ha", f"px:gx:{g['id']}:y"), B("❌ Yo'q", f"px:gv:{g['id']}")]]))
    for t, c in (("px_votes", "poll_id IN (SELECT id FROM px_polls WHERE group_id=?)"), ("px_polls", "group_id=?"),
                 ("px_gmem", "group_id=?"), ("px_groups", "id=?")):
        G["run"](f"DELETE FROM {t} WHERE {c}", (g["id"],))
    audit(call.from_user.id, "group_del", g["id"])
    await a_grp(call, state, [])


@act("gp")
async def a_grp_post(call, state, a):
    g = group_of(int(a[0]))
    if not owns(call.from_user.id, g):
        return
    await state.set_state(PxStates.grp_post)
    await state.update_data(gid=g["id"])
    await reply(call, "📢 E'lon matnini yozing — barcha a'zolarga yuboriladi. Bekor qilish: /cancel")


async def h_grp_post(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    g = group_of((await state.get_data()).get("gid", 0))
    text = (message.text or "").strip()[:MAX_STATE_TEXT]
    if not g or not owns(uid, g) or not text:
        return
    await state.clear()
    sent = 0
    for m in members(g["id"]):
        if m != uid and await G["safe_send"](m, f"📢 <b>{G['esc'](g['name'])}</b>\n\n{G['esc'](text)}"):
            sent += 1
        await asyncio.sleep(0.05)
    await message.answer(f"✅ {sent} ta a'zoga yuborildi.", reply_markup=KB([[B("🏫 Guruh", f"px:gv:{g['id']}")]]))


@act("gq")
async def a_grp_poll(call, state, a):
    g = group_of(int(a[0]))
    if not owns(call.from_user.id, g):
        return
    await state.set_state(PxStates.grp_poll)
    await state.update_data(gid=g["id"])
    await reply(call, "📊 So'rovnoma: <code>Savol | variant 1 | variant 2 | ...</code>\n"
                      "Masalan: <code>Ertaga dars bo'ladimi? | Ha | Yo'q</code>. Bekor qilish: /cancel")


async def send_poll(g, poll_id, question, options, kind, skip=None):
    rows = [[B(o, f"px:v:{poll_id}:{i}")] for i, o in enumerate(options)]
    head = "✅ Davomat" if kind == "attend" else "📊 So'rovnoma"
    sent = 0
    for m in members(g["id"]):
        if m == skip:
            continue
        if await G["safe_send"](m, f"{head} · <b>{G['esc'](g['name'])}</b>\n\n{G['esc'](question)}", KB(rows)):
            sent += 1
        await asyncio.sleep(0.05)
    return sent


async def h_grp_poll(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    g = group_of((await state.get_data()).get("gid", 0))
    if not g or not owns(uid, g):
        return
    try:
        q, opts = pc.parse_poll(message.text or "")
    except ValueError as ex:
        return await message.answer(f"⚠️ {G['esc'](str(ex))}")
    await state.clear()
    pid = G["insert"]("INSERT INTO px_polls (group_id, kind, question, options, created) VALUES (?, 'poll', ?, ?, ?)",
                      (g["id"], q, json.dumps(opts, ensure_ascii=False), G["now"]().isoformat(timespec="seconds")))
    n = await send_poll(g, pid, q, opts, "poll", skip=None)
    await message.answer(f"✅ {n} ta a'zoga yuborildi.", reply_markup=KB([[B("📈 Natija", f"px:pr:{pid}")], [B("🏫 Guruh", f"px:gv:{g['id']}")]]))


@act("ga")
async def a_grp_attend(call, state, a):
    g = group_of(int(a[0]))
    uid = call.from_user.id
    if not owns(uid, g):
        return
    q = f"Davomat — {G['fmt_date'](G['now']().date())}. Darsda bo'lsangiz tugmani bosing."
    opts = ["✅ Men darsdaman"]
    pid = G["insert"]("INSERT INTO px_polls (group_id, kind, question, options, created) VALUES (?, 'attend', ?, ?, ?)",
                      (g["id"], q, json.dumps(opts, ensure_ascii=False), G["now"]().isoformat(timespec="seconds")))
    n = await send_poll(g, pid, q, opts, "attend", skip=None)
    await reply(call, f"✅ Davomat so'rovi {n} ta a'zoga yuborildi.", KB([[B("📈 Natija", f"px:pr:{pid}")], [B("🏫 Guruh", f"px:gv:{g['id']}")]]))


@act("v")
async def a_vote(call, state, a):
    uid = call.from_user.id
    p = G["fetch_one"]("SELECT * FROM px_polls WHERE id=?", (int(a[0]),))
    if not p or p["closed"] or uid not in members(p["group_id"]):
        return await call.answer("So'rovnoma yopilgan yoki sizga tegishli emas.", show_alert=True)
    i = int(a[1])
    if not (0 <= i < len(json.loads(p["options"]))):
        return
    G["run"]("INSERT INTO px_votes (poll_id, user_id, choice) VALUES (?, ?, ?) ON CONFLICT(poll_id, user_id) DO UPDATE SET choice=excluded.choice",
             (p["id"], uid, i))
    await call.answer("✅ Qabul qilindi")


@act("pr")
async def a_poll_result(call, state, a):
    uid = call.from_user.id
    p = G["fetch_one"]("SELECT * FROM px_polls WHERE id=?", (int(a[0]),))
    g = group_of(p["group_id"]) if p else None
    if not owns(uid, g):
        return
    opts = json.loads(p["options"])
    votes = G["fetch_all"]("SELECT user_id, choice FROM px_votes WHERE poll_id=?", (p["id"],))
    total = len(votes)
    if p["kind"] == "attend":
        present = {v["user_id"] for v in votes}
        absent = [u for u in members(g["id"]) if u not in present]
        txt = (f"✅ <b>Davomat</b> — {G['esc'](g['name'])}\nKeldi: <b>{len(present)}</b> · Javob bermadi: <b>{len(absent)}</b>\n\n"
               "Javob bermaganlar:\n" + ("\n".join(f"• {G['esc'](short_name(u))}" for u in absent[:60]) or "—"))
    else:
        cnt = [0] * len(opts)
        for v in votes:
            cnt[v["choice"]] += 1
        txt = f"📊 <b>{G['esc'](p['question'])}</b>\nJami ovoz: {total}/{len(members(g['id']))}\n\n" + "\n".join(
            f"{G['esc'](o)}\n{pc.bar(cnt[i], total)} {cnt[i]}" for i, o in enumerate(opts))
    await reply(call, txt, KB([[B("🔄 Yangilash", f"px:pr:{p['id']}"), B("🔒 Yopish", f"px:pc:{p['id']}")], [B("⬅️ Guruh", f"px:gv:{g['id']}")]]))


@act("pc")
async def a_poll_close(call, state, a):
    p = G["fetch_one"]("SELECT * FROM px_polls WHERE id=?", (int(a[0]),))
    g = group_of(p["group_id"]) if p else None
    if owns(call.from_user.id, g):
        G["run"]("UPDATE px_polls SET closed=1 WHERE id=?", (p["id"],))
        await call.answer("🔒 Yopildi")


# ======================================================================
# E'lonlar taxtasi (bozor, yo'qolgan/topilgan, tadbir) + moderatsiya
# ======================================================================
@act("brd")
async def a_brd(call, state, a):
    await state.clear()
    rows = [[B(t, f"px:bl:{k}")] for k, (t, _) in BOARD_KINDS.items()]
    rows += [[B("➕ E'lon berish", "px:bn"), B("📋 E'lonlarim", "px:bmy")], [B("🔍 Qidirish", "px:bs")]]
    await reply(call, "📌 <b>E'lonlar taxtasi</b>\nE'lonlar moderator tasdig'idan keyin chiqadi va 30 kun turadi.", KB(rows + [BACK]))


def board_rows(kind=None, q=None, owner=None, only_ok=True):
    sql, p = "SELECT * FROM px_board WHERE 1=1", []
    if only_ok:
        sql += " AND status='approved' AND expires >= ?"
        p.append(G["now"]().isoformat(timespec="seconds"))
    if kind:
        sql += " AND kind=?"
        p.append(kind)
    if owner:
        sql += " AND owner=?"
        p.append(owner)
    if q:
        sql += " AND (title LIKE ? OR body LIKE ?)"
        p += [f"%{q}%", f"%{q}%"]
    return G["fetch_all"](sql + " ORDER BY id DESC LIMIT 12", tuple(p))


def board_list_kb(rows):
    em = {"market": "🛒", "lost": "🔍", "found": "🎁", "event": "🎉"}
    return KB([[B(f"{em.get(r['kind'], '📌')} {r['title'][:40]}" + ("" if r["status"] == "approved" else f" ({r['status']})"), f"px:bv:{r['id']}")] for r in rows]
              + [[B("⬅️ Taxta", "px:brd")]])


@act("bl")
async def a_brd_list(call, state, a):
    kind = a[0] if a and a[0] in BOARD_KINDS else None
    rows = board_rows(kind)
    if not rows:
        return await reply(call, "Hozircha e'lon yo'q.", KB([[B("➕ E'lon berish", "px:bn")], [B("⬅️ Taxta", "px:brd")]]))
    await reply(call, f"{BOARD_KINDS[kind][0] if kind else '📌'} — so'nggi e'lonlar:", board_list_kb(rows))


@act("bmy")
async def a_brd_my(call, state, a):
    rows = board_rows(owner=call.from_user.id, only_ok=False)
    if not rows:
        return await reply(call, "Sizda e'lon yo'q.", KB([[B("➕ E'lon berish", "px:bn")], [B("⬅️ Taxta", "px:brd")]]))
    await reply(call, "📋 Sizning e'lonlaringiz:", board_list_kb(rows))


@act("bs")
async def a_brd_search(call, state, a):
    await state.set_state(PxStates.brd_search)
    await reply(call, "🔍 Qidiruv so'zini yozing. Bekor qilish: /cancel")


async def h_brd_search(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    rows = board_rows(q=(message.text or "").strip()[:40])
    await state.clear()
    if not rows:
        return await message.answer("Hech narsa topilmadi.", reply_markup=KB([[B("⬅️ Taxta", "px:brd")]]))
    await message.answer("🔍 Natijalar:", reply_markup=board_list_kb(rows))


@act("bn")
async def a_brd_new(call, state, a):
    await reply(call, "E'lon turini tanlang:", KB([[B(t, f"px:bk:{k}")] for k, (t, _) in BOARD_KINDS.items()] + [[B("⬅️ Taxta", "px:brd")]]))


@act("bk")
async def a_brd_kind(call, state, a):
    k = a[0] if a else ""
    if k not in BOARD_KINDS:
        return
    await state.set_state(PxStates.brd_title)
    await state.update_data(kind=k)
    await reply(call, f"{BOARD_KINDS[k][0]}\n\n{BOARD_KINDS[k][1]} (qisqa sarlavha). Bekor qilish: /cancel")


async def h_brd_title(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()[:80]
    if not t:
        return
    await state.update_data(title=t)
    await state.set_state(PxStates.brd_body)
    await message.answer("Tafsilot yozing (holati, qayerda, qanday bog'lanish va h.k.).")


async def h_brd_body(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()[:600]
    if not t:
        return
    await state.update_data(body=t)
    await state.set_state(PxStates.brd_extra)
    kind = (await state.get_data()).get("kind")
    hint = {"market": "Narx (masalan: 25 000 so'm yoki «almashaman»)", "event": "Sana, vaqt va joy",
            "lost": "Qayerda va qachon yo'qolgan?", "found": "Qayerda va qachon topilgan?"}.get(kind, "Qo'shimcha")
    await message.answer(hint + ":")


async def h_brd_extra(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    d = await state.get_data()
    extra = (message.text or "").strip()[:120]
    if not extra or not d.get("title"):
        return
    exp = (G["now"]() + dt.timedelta(days=cfg_int("board_days", 30))).isoformat(timespec="seconds")
    status = "approved" if is_mod(uid) else "pending"
    bid = G["insert"]("INSERT INTO px_board (kind, title, body, extra, owner, status, created, expires) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                      (d["kind"], d["title"], d["body"], extra, uid, status, G["now"]().isoformat(timespec="seconds"), exp))
    await state.clear()
    if status == "approved":
        return await message.answer("✅ E'lon joylandi.", reply_markup=KB([[B("📋 E'lonlarim", "px:bmy")], BACK]))
    await message.answer("✅ Yuborildi. Moderator tasdiqlagach taxtada ko'rinadi.", reply_markup=KB([BACK]))
    await notify_mods(f"📌 Yangi e'lon #{bid} ({BOARD_KINDS[d['kind']][0]}):\n<b>{G['esc'](d['title'])}</b>\n{G['esc'](d['body'])}\n{G['esc'](extra)}",
                      KB([[B("✅ Tasdiqlash", f"px:mod:brd:{bid}:ok"), B("❌ Rad", f"px:mod:brd:{bid}:no")]]))


@act("bv")
async def a_brd_view(call, state, a):
    uid = call.from_user.id
    r = G["fetch_one"]("SELECT * FROM px_board WHERE id=?", (int(a[0]),))
    if not r or (r["status"] != "approved" and r["owner"] != uid and not is_mod(uid)):
        return await call.answer("E'lon topilmadi.", show_alert=True)
    label = {"market": "Narx", "event": "Sana/joy", "lost": "Joy/vaqt", "found": "Joy/vaqt"}.get(r["kind"], "Qo'shimcha")
    txt = (f"{BOARD_KINDS[r['kind']][0]}\n<b>{G['esc'](r['title'])}</b>\n\n{G['esc'](r['body'])}\n\n"
           f"{label}: {G['esc'](r['extra'])}\n👤 {G['esc'](short_name(r['owner']))}")
    rows = []
    if r["kind"] == "event":
        n = G["fetch_one"]("SELECT COUNT(*) n FROM px_rsvp WHERE board_id=?", (r["id"],))["n"]
        rows.append([B(f"🙋 Boraman ({n})", f"px:br:{r['id']}")])
    if r["owner"] != uid and r["status"] == "approved":
        rows.append([B("✉️ Egasiga yozish", f"px:bm:{r['id']}")])
    if r["owner"] == uid or is_mod(uid):
        rows.append([B("🗑 O'chirish", f"px:bd:{r['id']}")])
    await reply(call, txt, KB(rows + [[B("⬅️ Taxta", "px:brd")]]))


@act("br")
async def a_brd_rsvp(call, state, a):
    bid, uid = int(a[0]), call.from_user.id
    if G["run"]("INSERT OR IGNORE INTO px_rsvp (board_id, user_id) VALUES (?, ?)", (bid, uid)):
        await call.answer("🙋 Yozildingiz!")
    else:
        G["run"]("DELETE FROM px_rsvp WHERE board_id=? AND user_id=?", (bid, uid))
        await call.answer("Bekor qilindi.")
    await a_brd_view(call, state, [str(bid)])


@act("bd")
async def a_brd_del(call, state, a):
    uid = call.from_user.id
    r = G["fetch_one"]("SELECT * FROM px_board WHERE id=?", (int(a[0]),))
    if r and (r["owner"] == uid or is_mod(uid)):
        G["run"]("DELETE FROM px_board WHERE id=?", (r["id"],))
        G["run"]("DELETE FROM px_rsvp WHERE board_id=?", (r["id"],))
        if r["owner"] != uid:
            audit(uid, "board_del", r["id"])
    await a_brd(call, state, [])


RELAY_LAST = {}


@act("bm")
async def a_relay_start(call, state, a):
    r = G["fetch_one"]("SELECT owner, title FROM px_board WHERE id=? AND status='approved'", (int(a[0]),))
    if not r:
        return
    await state.set_state(PxStates.relay)
    await state.update_data(to=r["owner"], ref=f"E'lon: {r['title'][:40]}", bid=int(a[0]))
    await call.message.answer("✉️ Xabaringizni yozing (ismingiz qisqartirilgan holda ko'rsatiladi). Bekor qilish: /cancel")


@act("rl")
async def a_relay_reply(call, state, a):
    await state.set_state(PxStates.relay)
    await state.update_data(to=int(a[1]), ref=f"E'lon #{a[0]}", bid=int(a[0]))
    await call.message.answer("↩️ Javobingizni yozing. Bekor qilish: /cancel")


async def h_relay(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    d = await state.get_data()
    text = (message.text or "").strip()[:800]
    if not text or not d.get("to"):
        return
    if time.time() - RELAY_LAST.get(uid, 0) < 20:
        return await message.answer("Biroz kuting (20 soniya) va qayta yuboring.")
    RELAY_LAST[uid] = time.time()
    await state.clear()
    ok = await G["safe_send"](d["to"], f"📩 <b>{G['esc'](d['ref'])}</b>\n{G['esc'](short_name(uid))}:\n\n{G['esc'](text)}",
                              KB([[B("↩️ Javob berish", f"px:rl:{d.get('bid', 0)}:{uid}")]]))
    await message.answer("✅ Yuborildi." if ok else "⚠️ Xabar yetkazilmadi.", reply_markup=KB([BACK]))


@act("mod")
async def a_moderate(call, state, a):
    uid = call.from_user.id
    if not is_mod(uid) or len(a) < 3:
        return await call.answer("Ruxsat yo'q.", show_alert=True)
    kind, rid, verdict = a[0], int(a[1]), a[2]
    table = {"mat": "px_mat", "brd": "px_board"}.get(kind)
    if not table:
        return
    r = G["fetch_one"](f"SELECT * FROM {table} WHERE id=?", (rid,))
    if not r:
        return await reply(call, "Topilmadi (o'chirilgan).", KB([[B("🛠 Boshqaruv", "px:adm")]]))
    status = "approved" if verdict == "ok" else "rejected"
    G["run"](f"UPDATE {table} SET status=? WHERE id=?", (status, rid))
    audit(uid, f"moderate_{kind}", f"{rid}:{status}")
    if status == "approved":
        add_xp(r["owner"], 5, "approved")
    await G["safe_send"](r["owner"], ("✅ " if status == "approved" else "❌ ") + f"«{G['esc'](r['title'])}» " + ("tasdiqlandi." if status == "approved" else "rad etildi."))
    await reply(call, f"{'✅ Tasdiqlandi' if status == 'approved' else '❌ Rad etildi'}: #{rid}", KB([[B("🛠 Navbat", "px:mq")]]))


# ======================================================================
# Anonim savol
# ======================================================================
@act("anon")
async def a_anon(call, state, a):
    await state.set_state(PxStates.anon)
    await reply(call, "🕵️ <b>Anonim savol</b>\nSavolingiz ismingizsiz moderator/administratorga boradi, javob shu yerga keladi. "
                      "Kuniga 3 tagacha. Haqorat va tuhmat yozmang. Bekor qilish: /cancel")


async def h_anon(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    text = (message.text or "").strip()[:1000]
    if len(text) < 5:
        return await message.answer("Savol biroz batafsilroq bo'lsin.")
    n = G["fetch_one"]("SELECT COUNT(*) n FROM px_anon WHERE user_id=? AND created >= ?", (uid, today_s()))["n"]
    if n >= 3:
        await state.clear()
        return await message.answer("Bugungi limit (3 ta) tugadi.")
    aid = G["insert"]("INSERT INTO px_anon (user_id, text, created) VALUES (?, ?, ?)", (uid, text, G["now"]().isoformat(timespec="seconds")))
    await state.clear()
    await message.answer("✅ Yuborildi. Javob kelsa, shu yerga xabar beraman.", reply_markup=KB([BACK]))
    await notify_mods(f"🕵️ <b>Anonim savol #{aid}</b>\n\n{G['esc'](text)}", KB([[B("💬 Javob berish", f"px:an:{aid}")]]))


@act("an")
async def a_anon_reply(call, state, a):
    if not is_mod(call.from_user.id):
        return await call.answer("Ruxsat yo'q.", show_alert=True)
    await state.set_state(PxStates.adm_reply)
    await state.update_data(aid=int(a[0]))
    await call.message.answer(f"💬 #{a[0]} savolga javob matnini yozing. Bekor qilish: /cancel")


async def h_adm_reply(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    if not is_mod(uid):
        return
    aid = (await state.get_data()).get("aid")
    r = G["fetch_one"]("SELECT * FROM px_anon WHERE id=?", (aid,))
    text = (message.text or "").strip()[:1500]
    if not r or not text:
        return
    G["run"]("UPDATE px_anon SET answer=? WHERE id=?", (text, aid))
    await state.clear()
    audit(uid, "anon_reply", aid)
    ok = await G["safe_send"](r["user_id"], f"📬 <b>Anonim savolingizga javob</b> (#{aid})\n\n❓ {G['esc'](r['text'])}\n\n💬 {G['esc'](text)}")
    await message.answer("✅ Yuborildi." if ok else "⚠️ Foydalanuvchiga yetkazib bo'lmadi.")


# ======================================================================
# Fan sharhlari (anonim)
# ======================================================================
@act("rev")
async def a_rev(call, state, a):
    await state.clear()
    await reply(call, "⭐ <b>Fan sharhlari</b>\nFanlarga anonim baho va fikr. Shaxsga emas, fan sifatiga (mazmun, qiyinlik, materiallar) baho bering — haqorat yozmang.",
                KB([[B("✍️ Sharh yozish", "px:rw"), B("🔍 Sharhlarni ko'rish", "px:rs")], BACK]))


@act("rw")
async def a_rev_write(call, state, a):
    await state.set_state(PxStates.rev_subj)
    await state.update_data(mode="write")
    await reply(call, "Fan nomini yozing. Bekor qilish: /cancel")


@act("rs")
async def a_rev_view(call, state, a):
    await state.set_state(PxStates.rev_subj)
    await state.update_data(mode="view")
    await reply(call, "Qaysi fan sharhlarini ko'rmoqchisiz? Fan nomini yozing. Bekor qilish: /cancel")


async def h_rev_subj(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    subj = (message.text or "").strip()[:60]
    if not subj:
        return
    mode = (await state.get_data()).get("mode")
    if mode == "write":
        await state.update_data(subj=subj)
        return await message.answer(f"«{G['esc'](subj)}» fanini baholang:",
                                    reply_markup=KB([[B("⭐" * i, f"px:rr:{i}") for i in (1, 2, 3, 4, 5)]]))
    await state.clear()
    rows = G["fetch_all"]("SELECT id, rating, comment FROM px_reviews WHERE subject LIKE ? ORDER BY id DESC", (f"%{subj}%",))
    if not rows:
        return await message.answer("Bu fan bo'yicha sharh yo'q.", reply_markup=KB([[B("✍️ Birinchi bo'ling", "px:rw")], BACK]))
    avg = sum(r["rating"] for r in rows) / len(rows)
    lines = [f"⭐ <b>{G['esc'](subj)}</b>: {avg:.1f}/5 ({len(rows)} ta baho)\n"]
    for r in [x for x in rows if x["comment"]][:5]:
        lines.append(f"{'⭐' * r['rating']} {G['esc'](r['comment'])}")
    kb = [[B(f"🗑 #{r['id']}", f"px:rdel:{r['id']}")] for r in rows[:5]] if is_mod(uid) else []
    await message.answer("\n".join(lines)[:4000], reply_markup=KB(kb + [BACK]))


@act("rr")
async def a_rev_rate(call, state, a):
    d = await state.get_data()
    if not d.get("subj"):
        return
    await state.update_data(rating=int(a[0]))
    await state.set_state(PxStates.rev_comment)
    await reply(call, "Fikringizni yozing (yoki /skip — faqat baho qoldirish).")


async def h_rev_comment(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    d = await state.get_data()
    txt = (message.text or "").strip()
    comment = "" if txt.lower() in ("/skip", "skip") else txt[:300]
    G["run"]("""INSERT INTO px_reviews (subject, rating, comment, user_id, created) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(subject, user_id) DO UPDATE SET rating=excluded.rating, comment=excluded.comment, created=excluded.created""",
             (d["subj"], int(d["rating"]), comment, uid, G["now"]().isoformat(timespec="seconds")))
    await state.clear()
    add_xp(uid, 2, "review")
    await message.answer("✅ Rahmat! Sharhingiz anonim saqlandi.", reply_markup=KB([BACK]))


@act("rdel")
async def a_rev_del(call, state, a):
    if is_mod(call.from_user.id):
        G["run"]("DELETE FROM px_reviews WHERE id=?", (int(a[0]),))
        audit(call.from_user.id, "review_del", a[0])
        await call.answer("🗑 O'chirildi")


# ======================================================================
# Konsultatsiya navbati
# ======================================================================
@act("slot")
async def a_slot(call, state, a):
    await state.clear()
    uid = call.from_user.id
    rows = [[B("📅 Bo'sh vaqtlar", "px:sl"), B("📋 Mening navbatlarim", "px:sm")]]
    if is_teacher(uid):
        rows.append([B("➕ Vaqt qo'shish", "px:sa"), B("🗂 Vaqtlarim", "px:st")])
    await reply(call, "🕒 <b>Konsultatsiya navbati</b>\nO'qituvchi bilan uchrashuvga yoziling.", KB(rows + [BACK]))


@act("sl")
async def a_slot_free(call, state, a):
    rows = G["fetch_all"]("SELECT * FROM px_slots WHERE student IS NULL AND at >= ? ORDER BY at LIMIT 10", (G["now"]().strftime("%Y-%m-%dT%H:%M"),))
    if not rows:
        return await reply(call, "Hozircha bo'sh vaqt yo'q.", KB([[B("⬅️ Orqaga", "px:slot")]]))
    kb = [[B(f"{r['at'][5:10].replace('-', '.')} {r['at'][11:16]} · {short_name(r['teacher'])}", f"px:sb:{r['id']}")] for r in rows]
    await reply(call, "📅 Bo'sh vaqtni tanlang:", KB(kb + [[B("⬅️ Orqaga", "px:slot")]]))


@act("sb")
async def a_slot_book(call, state, a):
    uid = call.from_user.id
    s = G["fetch_one"]("SELECT * FROM px_slots WHERE id=?", (int(a[0]),))
    if not s or s["teacher"] == uid:
        return await call.answer("Bu vaqtni band qilib bo'lmaydi.", show_alert=True)
    if not G["run"]("UPDATE px_slots SET student=? WHERE id=? AND student IS NULL", (uid, s["id"])):
        return await call.answer("Bu vaqt allaqachon band.", show_alert=True)
    await reply(call, f"✅ Yozildingiz: {s['at'][:10]} {s['at'][11:16]}, {G['esc'](short_name(s['teacher']))}.", KB([[B("📋 Navbatlarim", "px:sm")], BACK]))
    await G["safe_send"](s["teacher"], f"🕒 {G['esc'](short_name(uid))} {s['at'][:10]} {s['at'][11:16]} vaqtga yozildi.")


@act("sm")
async def a_slot_mine(call, state, a):
    rows = G["fetch_all"]("SELECT * FROM px_slots WHERE student=? AND at >= ? ORDER BY at", (call.from_user.id, G["now"]().strftime("%Y-%m-%dT%H:%M")))
    if not rows:
        return await reply(call, "Sizda navbat yo'q.", KB([[B("⬅️ Orqaga", "px:slot")]]))
    kb = [[B(f"❌ {r['at'][:10]} {r['at'][11:16]} · {short_name(r['teacher'])}", f"px:sc:{r['id']}")] for r in rows]
    await reply(call, "📋 Navbatlaringiz (bekor qilish uchun bosing):", KB(kb + [[B("⬅️ Orqaga", "px:slot")]]))


@act("sc")
async def a_slot_cancel(call, state, a):
    s = G["fetch_one"]("SELECT * FROM px_slots WHERE id=? AND student=?", (int(a[0]), call.from_user.id))
    if s:
        G["run"]("UPDATE px_slots SET student=NULL WHERE id=?", (s["id"],))
        await G["safe_send"](s["teacher"], f"ℹ️ {G['esc'](short_name(call.from_user.id))} {s['at'][:10]} {s['at'][11:16]} navbatni bekor qildi.")
    await a_slot_mine(call, state, [])


@act("sa")
async def a_slot_add(call, state, a):
    if not is_teacher(call.from_user.id):
        return
    await state.set_state(PxStates.slot_note)
    await reply(call, "➕ Vaqt: <code>sana vaqt izoh</code>\nMasalan: <code>05.11.2026 15:00 Kurs ishi maslahati, 215-xona</code>. Bekor qilish: /cancel")


async def h_slot_note(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    if not is_teacher(uid):
        return
    m = re.match(r"\s*(\S+)\s+(\d{1,2}:\d{2})\s*(.*)", message.text or "", re.S)
    d = pc.parse_any_date(m.group(1), G["now"]().date()) if m else None
    if not m or not d:
        return await message.answer("Format: <code>05.11.2026 15:00 izoh</code>")
    hh, mm = map(int, m.group(2).split(":"))
    if hh > 23 or mm > 59:
        return await message.answer("Vaqt noto'g'ri.")
    at = dt.datetime.combine(d, dt.time(hh, mm))
    if at.replace(tzinfo=G["TZ"]) <= G["now"]():
        return await message.answer("Vaqt o'tib ketgan.")
    G["insert"]("INSERT INTO px_slots (teacher, at, note, created) VALUES (?, ?, ?, ?)",
                (uid, at.strftime("%Y-%m-%dT%H:%M"), m.group(3).strip()[:150], G["now"]().isoformat(timespec="seconds")))
    await state.clear()
    await message.answer("✅ Vaqt qo'shildi.", reply_markup=KB([[B("➕ Yana", "px:sa"), B("🗂 Vaqtlarim", "px:st")]]))


@act("st")
async def a_slot_teacher(call, state, a):
    rows = G["fetch_all"]("SELECT * FROM px_slots WHERE teacher=? AND at >= ? ORDER BY at LIMIT 20", (call.from_user.id, G["now"]().strftime("%Y-%m-%dT%H:%M")))
    if not rows:
        return await reply(call, "Vaqtlar yo'q.", KB([[B("➕ Qo'shish", "px:sa")], [B("⬅️ Orqaga", "px:slot")]]))
    kb = [[B(f"🗑 {r['at'][5:10].replace('-', '.')} {r['at'][11:16]} · " + (short_name(r["student"]) if r["student"] else "bo'sh"), f"px:sx:{r['id']}")] for r in rows]
    await reply(call, "🗂 Vaqtlaringiz (o'chirish uchun bosing):", KB(kb + [[B("⬅️ Orqaga", "px:slot")]]))


@act("sx")
async def a_slot_del(call, state, a):
    s = G["fetch_one"]("SELECT * FROM px_slots WHERE id=? AND teacher=?", (int(a[0]), call.from_user.id))
    if s:
        G["run"]("DELETE FROM px_slots WHERE id=?", (s["id"],))
        if s["student"]:
            await G["safe_send"](s["student"], f"ℹ️ O'qituvchi {s['at'][:10]} {s['at'][11:16]} vaqtni bekor qildi.")
    await a_slot_teacher(call, state, [])


# ======================================================================
# Sozlamalar: eksport, o'chirish, API kalit, reytingda ko'rinish
# ======================================================================
USER_TABLES = [  # (jadval, ustun) - o'chirishda
    ("settings", "user_id"), ("notes", "user_id"), ("reminders", "user_id"), ("snapshots", "user_id"), ("sent_log", "user_id"),
    ("ai_history", "user_id"), ("ai_prefs", "user_id"), ("ai_usage", "user_id"), ("hub_users", "user_id"), ("hub_daily", "user_id"),
    ("hub_ref", "invitee"), ("hub_ref", "inviter"),
    ("px_xp", "user_id"), ("px_xplog", "user_id"), ("px_quest", "user_id"), ("px_cards", "user_id"), ("px_plan", "user_id"),
    ("px_roles", "user_id"), ("px_gmem", "user_id"), ("px_votes", "user_id"), ("px_matlike", "user_id"), ("px_rsvp", "user_id"),
    ("px_apikeys", "user_id"), ("px_anon", "user_id"), ("px_reviews", "user_id"), ("px_board", "owner"), ("px_mat", "owner"),
    ("px_duels", "p1"), ("px_duels", "p2"), ("px_promo_use", "user_id"),
]
EXPORT_TABLES = ["settings", "notes", "reminders", "hub_users", "px_xp", "px_cards", "px_plan", "px_reviews", "px_board", "px_mat"]


def table_exists(conn, name):
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


@act("export")
async def a_export(call, state, a):
    uid = call.from_user.id
    out = {"user_id": uid, "exported": G["now"]().isoformat(timespec="seconds"), "note": "HEMIS tokeni va parol eksportga kiritilmaydi."}
    with closing(G["db"]()) as conn:
        for t in EXPORT_TABLES:
            if not table_exists(conn, t):
                continue
            col = "owner" if t in ("px_board", "px_mat") else "user_id"
            out[t] = [dict(r) for r in conn.execute(f"SELECT * FROM {t} WHERE {col}=?", (uid,)).fetchall()]
    data = json.dumps(out, ensure_ascii=False, indent=2, default=str).encode("utf-8")
    await call.message.answer_document(BufferedInputFile(data, filename=f"mening_malumotlarim_{uid}.json"),
                                       caption="📤 Botdagi ma'lumotlaringiz nusxasi.")


@act("del")
async def a_del(call, state, a):
    await reply(call, "⚠️ <b>Barcha ma'lumotlaringiz o'chiriladi</b>: HEMIS ulanishi, sozlamalar, qaydlar, eslatmalar, kartalar, XP, "
                      "AI tarixi, e'lonlar va h.k. To'lov yozuvlari hisob-kitob uchun saqlanadi. Bu amalni qaytarib bo'lmaydi.",
                KB([[B("🗑 Ha, hammasini o'chir", "px:del2")], [B("❌ Bekor qilish", "px:menu")]]))


@act("del2")
async def a_del2(call, state, a):
    uid = call.from_user.id
    n = 0
    with closing(G["db"]()) as conn:
        for t, c in USER_TABLES:
            if table_exists(conn, t):
                n += conn.execute(f"DELETE FROM {t} WHERE {c}=?", (uid,)).rowcount
        if table_exists(conn, "px_slots"):
            conn.execute("DELETE FROM px_slots WHERE teacher=?", (uid,))
            conn.execute("UPDATE px_slots SET student=NULL WHERE student=?", (uid,))
        conn.execute("DELETE FROM users WHERE user_id=?", (uid,))
        conn.commit()
    CHK.pop(uid, None)
    DOC_MEM.pop(uid, None)
    audit(uid, "delete_me", f"rows={n}")
    await state.clear()
    await reply(call, "🗑 Ma'lumotlaringiz o'chirildi. Qayta foydalanish uchun /start bosing.")


@act("vis")
async def a_vis(call, state, a):
    uid = call.from_user.id
    ensure_xp(uid)
    G["run"]("UPDATE px_xp SET hidden = 1 - hidden WHERE user_id=?", (uid,))
    h = xp_stats(uid)["hidden"]
    await call.answer("Reytingdan yashirildingiz." if h else "Reytingda ko'rinasiz.", show_alert=True)


@act("api")
async def a_api(call, state, a):
    r = G["fetch_one"]("SELECT created FROM px_apikeys WHERE user_id=?", (call.from_user.id,))
    base = (G["WEB_APP_URL"] or "https://SIZNING-DOMEN").rstrip("/")
    txt = ("🔑 <b>Shaxsiy API kalit</b>\nO'z ma'lumotlaringizni (jadval, baho, GPA...) o'z skriptingiz yoki ilovangizda olish uchun.\n\n"
           f"<code>curl -H \"X-API-Key: KALIT\" {base}/open/v1/schedule</code>\n"
           "Mavjud: <code>me, schedule, grades, gpa, exams, attendance, tasks</code>. Chegara: daqiqasiga 30 so'rov. "
           "Kalitni hech kimga bermang — u HEMIS ma'lumotlaringizga kirish beradi.\n\n" +
           (f"Joriy kalit yaratilgan: {r['created'][:10]}" if r else "Kalit hali yaratilmagan."))
    await reply(call, txt, KB([[B("🆕 Yangi kalit", "px:apin")] + ([B("🗑 O'chirish", "px:apid")] if r else []), BACK]))


@act("apin")
async def a_api_new(call, state, a):
    uid = call.from_user.id
    key = pc.new_api_key()
    G["run"]("INSERT INTO px_apikeys (user_id, key_hash, created) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET key_hash=excluded.key_hash, created=excluded.created",
             (uid, pc.hash_key(key), G["now"]().isoformat(timespec="seconds")))
    await call.message.answer(f"🔑 Yangi kalit (faqat bir marta ko'rsatiladi, saqlab qo'ying):\n<code>{key}</code>")


@act("apid")
async def a_api_del(call, state, a):
    G["run"]("DELETE FROM px_apikeys WHERE user_id=?", (call.from_user.id,))
    await a_api(call, state, [])


# ======================================================================
# Admin boshqaruvi
# ======================================================================
def admin_kb(uid):
    rows = [[B("📊 Statistika", "px:ast"), B("🛡 Moderatsiya navbati", "px:mq")]]
    if G["is_admin"](uid):
        url = (G["WEB_APP_URL"] or "") + "/px"
        if url.startswith("https://"):
            rows.append([InlineKeyboardButton(text="📈 Dashboard (Web)", web_app=types.WebAppInfo(url=url))])
        rows += [[B("🎭 Rollar", "px:ar"), B("🎟 Promokod yaratish", "px:ap")],
                 [B("📜 Audit log", "px:al"), B("🩺 Sog'liq", "px:ah")],
                 [B("💾 Zaxira hozir", "px:ab"), B("🔐 Tokenlarni shifrlash", "px:ae")]]
    return KB(rows + [BACK])


@act("adm")
async def a_adm(call, state, a):
    uid = call.from_user.id
    if not (G["is_admin"](uid) or role_of(uid)):
        return await call.answer("Ruxsat yo'q.", show_alert=True)
    await state.clear()
    await reply(call, "🛠 <b>Plus boshqaruvi</b>", admin_kb(uid))


def stats_data():
    f1 = lambda q, p=(): (G["fetch_one"](q, p) or [0])[0] or 0
    day = lambda n: (G["now"]().date() - dt.timedelta(days=n)).isoformat()
    users = f1("SELECT COUNT(*) FROM users WHERE token IS NOT NULL")
    out = {"users": users, "total_rows": f1("SELECT COUNT(*) FROM users"),
           "active7": f1("SELECT COUNT(*) FROM users WHERE last_seen >= ?", (day(7),)),
           "active1": f1("SELECT COUNT(*) FROM users WHERE last_seen >= ?", (day(1),)),
           "xp_users": f1("SELECT COUNT(*) FROM px_xp WHERE xp > 0"), "cards": f1("SELECT COUNT(*) FROM px_cards"),
           "groups": f1("SELECT COUNT(*) FROM px_groups"), "board": f1("SELECT COUNT(*) FROM px_board WHERE status='approved'"),
           "pending": f1("SELECT COUNT(*) FROM px_board WHERE status='pending'") + f1("SELECT COUNT(*) FROM px_mat WHERE status='pending'")}
    with closing(G["db"]()) as conn:
        has_hub = table_exists(conn, "hub_orders")
    if has_hub:
        out["premium"] = f1("SELECT COUNT(*) FROM hub_users WHERE premium_until > ?", (G["now"]().isoformat(),))
        out["revenue"] = f1("SELECT COALESCE(SUM(amount),0) FROM hub_orders WHERE status='paid'")
    series = {"new": [], "ai": [], "rev": [], "xp": []}
    for n in range(29, -1, -1):
        d = day(n)
        series["new"].append([d, f1("SELECT COUNT(*) FROM users WHERE date(created_at)=?", (d,))])
        series["ai"].append([d, f1("SELECT COALESCE(SUM(n),0) FROM ai_usage WHERE day=?", (d,))])
        series["xp"].append([d, f1("SELECT COALESCE(SUM(amount),0) FROM px_xplog WHERE substr(ts,1,10)=?", (d,))])
        series["rev"].append([d, f1("SELECT COALESCE(SUM(amount),0) FROM hub_orders WHERE status='paid' AND substr(paid,1,10)=?", (d,)) if has_hub else 0])
    out["series"] = series
    return out


@act("ast")
async def a_stats(call, state, a):
    if not (G["is_admin"](call.from_user.id) or role_of(call.from_user.id)):
        return
    s = stats_data()
    txt = (f"📊 <b>Statistika</b>\n👥 Kirgan foydalanuvchilar: <b>{s['users']}</b> (jami yozuv {s['total_rows']})\n"
           f"🟢 Faol: 24 soat {s['active1']} · 7 kun {s['active7']}\n✨ XP olganlar: {s['xp_users']} · 🃏 Kartalar: {s['cards']}\n"
           f"🏫 Guruhlar: {s['groups']} · 📌 E'lonlar: {s['board']} · ⏳ Navbatda: {s['pending']}")
    if "premium" in s:
        txt += f"\n💎 Premium: {s['premium']} · 💰 Daromad (to'langan): {s['revenue']:,} so'm".replace(",", " ")
    await reply(call, txt, KB([[B("🔄", "px:ast")], [B("⬅️ Boshqaruv", "px:adm")]]))


@act("mq")
async def a_mod_queue(call, state, a):
    if not is_mod(call.from_user.id):
        return await call.answer("Ruxsat yo'q.", show_alert=True)
    brd = G["fetch_all"]("SELECT id, title FROM px_board WHERE status='pending' ORDER BY id LIMIT 8")
    mat = G["fetch_all"]("SELECT id, title FROM px_mat WHERE status='pending' ORDER BY id LIMIT 8")
    if not brd and not mat:
        return await reply(call, "✅ Navbat bo'sh.", KB([[B("⬅️ Boshqaruv", "px:adm")]]))
    rows = [[B(f"📌 #{r['id']} {r['title'][:30]}", f"px:mv:brd:{r['id']}")] for r in brd]
    rows += [[B(f"📚 #{r['id']} {r['title'][:30]}", f"px:mv:mat:{r['id']}")] for r in mat]
    await reply(call, "🛡 <b>Tasdiq kutayotganlar:</b>", KB(rows + [[B("⬅️ Boshqaruv", "px:adm")]]))


@act("mv")
async def a_mod_view(call, state, a):
    if not is_mod(call.from_user.id):
        return
    kind, rid = a[0], int(a[1])
    table = {"mat": "px_mat", "brd": "px_board"}.get(kind)
    r = G["fetch_one"](f"SELECT * FROM {table} WHERE id=?", (rid,)) if table else None
    if not r:
        return await call.answer("Topilmadi.", show_alert=True)
    body = r["body"] if kind == "brd" else f"Fan: {r['subject']}"
    await reply(call, f"#{rid} <b>{G['esc'](r['title'])}</b>\n{G['esc'](body)}\n👤 {G['esc'](short_name(r['owner']))}",
                KB([[B("✅ Tasdiqlash", f"px:mod:{kind}:{rid}:ok"), B("❌ Rad", f"px:mod:{kind}:{rid}:no")], [B("⬅️ Navbat", "px:mq")]]))


@act("ar")
async def a_roles(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    rows = G["fetch_all"]("SELECT user_id, role FROM px_roles ORDER BY role")
    txt = "🎭 <b>Rollar</b>\n" + ("\n".join(f"• {r['user_id']} — {ROLES.get(r['role'], r['role'])} ({G['esc'](uname(r['user_id']))})" for r in rows) or "Hozircha yo'q.")
    txt += "\n\nO'zgartirish: <code>ID rol</code> (rol: moderator, sardor, teacher, yoki <code>yoq</code> — olib tashlash)."
    await state.set_state(PxStates.adm_role)
    await reply(call, txt, KB([[B("⬅️ Boshqaruv", "px:adm")]]))


async def h_adm_role(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    if not G["is_admin"](uid):
        return
    m = re.fullmatch(r"\s*(\d{1,15})\s+(\w+)\s*", message.text or "")
    if not m:
        return await message.answer("Format: <code>123456789 moderator</code>")
    target, role = int(m.group(1)), m.group(2).lower()
    if role in ("yoq", "yo'q", "none", "off"):
        G["run"]("DELETE FROM px_roles WHERE user_id=?", (target,))
        audit(uid, "role_remove", target)
        await state.clear()
        return await message.answer("✅ Rol olib tashlandi.")
    if role not in ROLES:
        return await message.answer("Rol: moderator, sardor yoki teacher.")
    G["run"]("INSERT INTO px_roles (user_id, role) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET role=excluded.role", (target, role))
    audit(uid, "role_set", f"{target}:{role}")
    await state.clear()
    await message.answer(f"✅ {target} → {ROLES[role]}")
    await G["safe_send"](target, f"🎭 Sizga rol berildi: {ROLES[role]}. /plus orqali yangi imkoniyatlar ochildi.")


@act("ap")
async def a_promo_admin(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    rows = G["fetch_all"]("SELECT * FROM px_promo ORDER BY rowid DESC LIMIT 8")
    txt = "🎟 <b>Promokodlar</b>\n" + ("\n".join(f"• <code>{r['code']}</code> {r['kind']}={r['value']} ({r['used']}/{r['max_uses'] or '∞'}) {r['expires'] or ''}{'' if r['active'] else ' ⛔'}" for r in rows) or "Yo'q.")
    txt += ("\n\nYaratish: <code>KOD tur qiymat limit [muddat_kun]</code>\ntur: credits | premium | xp, limit 0 = cheksiz.\n"
            "Masalan: <code>YANGI25 credits 5 100 30</code>\nO'chirish: <code>del KOD</code>")
    await state.set_state(PxStates.adm_promo)
    await reply(call, txt, KB([[B("⬅️ Boshqaruv", "px:adm")]]))


async def h_adm_promo(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    uid = message.from_user.id
    if not G["is_admin"](uid):
        return
    t = (message.text or "").split()
    if len(t) == 2 and t[0].lower() == "del":
        G["run"]("UPDATE px_promo SET active=0 WHERE code=?", (pc.norm_code(t[1]),))
        audit(uid, "promo_off", t[1])
        await state.clear()
        return await message.answer("✅ O'chirildi.")
    try:
        code, kind, val, lim = pc.norm_code(t[0]), t[1].lower(), int(t[2]), int(t[3])
        days = int(t[4]) if len(t) > 4 else 0
        if not code or kind not in ("credits", "premium", "xp") or not (0 < val <= 1000) or lim < 0:
            raise ValueError
    except (IndexError, ValueError):
        return await message.answer("Format: <code>KOD credits 5 100 30</code>")
    exp = (G["now"]().date() + dt.timedelta(days=days)).isoformat() if days > 0 else None
    G["run"]("INSERT OR REPLACE INTO px_promo (code, kind, value, max_uses, used, expires, active) VALUES (?, ?, ?, ?, COALESCE((SELECT used FROM px_promo WHERE code=?),0), ?, 1)",
             (code, kind, val, lim, code, exp))
    audit(uid, "promo_new", f"{code} {kind} {val} lim={lim} exp={exp}")
    await state.clear()
    await message.answer(f"✅ Promokod <code>{code}</code> tayyor.")


@act("al")
async def a_audit(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    rows = G["fetch_all"]("SELECT ts, actor, action, detail FROM px_audit ORDER BY id DESC LIMIT 25")
    txt = "📜 <b>Audit log</b> (oxirgi 25)\n\n" + ("\n".join(f"{r['ts'][5:16].replace('T', ' ')} · {r['actor']} · {G['esc'](r['action'])} {G['esc'](r['detail'] or '')}" for r in rows) or "Bo'sh.")
    await reply(call, txt, KB([[B("⬅️ Boshqaruv", "px:adm")]]))


@act("ah")
async def a_health(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    h = health_info()
    txt = ("🩺 <b>Sog'liq</b>\n" f"⏱ Ishlash vaqti: {h['uptime']}\n💽 Baza: {h['db_mb']:.1f} MB\n"
           f"💾 Oxirgi zaxira: {h['last_backup'] or 'yo`q'}\n🔐 Shifrlanmagan tokenlar: {h['plain_tokens']}\n"
           f"⚠️ So'nggi 10 daqiqada xatolar: {h['errors10']}\n🍅 Faol pomodoro: {len(POMO)}")
    await reply(call, txt, KB([[B("🔄", "px:ah")], [B("⬅️ Boshqaruv", "px:adm")]]))


@act("ab")
async def a_backup_now(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    path = make_backup()
    audit(call.from_user.id, "backup_now", path)
    await call.message.answer_document(BufferedInputFile(open(path, "rb").read(), filename=os.path.basename(path)), caption="💾 Zaxira nusxa (ichida tokenlar bor — saqlashda ehtiyot bo'ling).")


@act("ae")
async def a_encrypt(call, state, a):
    if not G["is_admin"](call.from_user.id):
        return
    n, err = migrate_tokens()
    audit(call.from_user.id, "encrypt_tokens", f"{n} {err or ''}")
    await call.answer(err or f"✅ {n} ta token shifrlandi.", show_alert=True)


# ======================================================================
# Zaxira, token migratsiyasi, sog'liq, texnik xizmat
# ======================================================================
START_TS = time.time()


def make_backup():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    path = os.path.join(BACKUP_DIR, f"hemis_{G['now']():%Y%m%d}.db")
    src = sqlite3.connect(G["DB_NAME"])
    try:
        dst = sqlite3.connect(path)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    for n in pc.backups_to_delete(os.listdir(BACKUP_DIR), max(1, cfg_int("backup_keep", 7))):
        try:
            os.remove(os.path.join(BACKUP_DIR, n))
        except OSError:
            pass
    return path


def migrate_tokens():
    """Shifrlanmagan tokenlarni ENCRYPTION_KEY bilan shifrlaydi. (soni, xato_matni)"""
    fernet = NS.get("FERNET")
    if not fernet:
        return 0, "ENCRYPTION_KEY o'rnatilmagan (.env)."
    n = 0
    with closing(G["db"]()) as conn:
        rows = conn.execute("SELECT user_id, token FROM users WHERE token IS NOT NULL AND token != '' AND token NOT LIKE 'enc:%'").fetchall()
        for r in rows:
            conn.execute("UPDATE users SET token=? WHERE user_id=?", ("enc:" + fernet.encrypt(r["token"].encode()).decode(), r["user_id"]))
            n += 1
        conn.commit()
    return n, None


def plain_token_count():
    r = G["fetch_one"]("SELECT COUNT(*) n FROM users WHERE token IS NOT NULL AND token != '' AND token NOT LIKE 'enc:%'")
    return r["n"] if r else 0


def last_backup_name():
    try:
        names = sorted(n for n in os.listdir(BACKUP_DIR) if n.startswith("hemis_"))
        return names[-1] if names else None
    except OSError:
        return None


def health_info():
    t = time.time()
    up = int(t - START_TS)
    try:
        mb = os.path.getsize(G["DB_NAME"]) / 1048576
    except OSError:
        mb = 0.0
    return {"uptime": f"{up // 86400}k {up % 86400 // 3600}s {up % 3600 // 60}d", "db_mb": mb, "last_backup": last_backup_name(),
            "plain_tokens": plain_token_count(), "errors10": len([x for x in ERR_LOG if t - x < 600])}


class ErrCounter(logging.Handler):
    def emit(self, record):
        if record.levelno >= logging.ERROR:
            ERR_LOG.append(time.time())
            del ERR_LOG[:-200]


async def maintenance():
    """Har daqiqada: ertalabki reja, kunlik zaxira, xato ogohlantirishi, eskirgan yozuvlarni tozalash."""
    last_clean = ""
    while True:
        try:
            await asyncio.sleep(60)
            n = G["now"]()
            day, hm = n.strftime("%Y-%m-%d"), n.strftime("%H:%M")
            if hm == "07:30":
                await send_morning_plans(day)
            if hm >= "03:10" and G["claim"](0, f"px_backup:{day}"):
                path = await asyncio.to_thread(make_backup)
                if n.weekday() == 6 and cfg("weekly_backup") == "1" and G["ADMIN_ID"]:
                    try:
                        await G["bot"].send_document(G["ADMIN_ID"], BufferedInputFile(open(path, "rb").read(), filename=os.path.basename(path)),
                                                     caption="💾 Haftalik zaxira nusxa. Ichida tokenlar bor — xavfsiz joyda saqlang.")
                    except Exception:
                        logging.warning("haftalik zaxira yuborilmadi", exc_info=True)
            if last_clean != day:
                last_clean = day
                await asyncio.to_thread(cleanup)
            lim = cfg_int("alert_errors", 5)
            t = time.time()
            if lim and len([x for x in ERR_LOG if t - x < 600]) >= lim and t - LAST_ALERT[0] > 3600 and G["ADMIN_ID"]:
                LAST_ALERT[0] = t
                await G["safe_send"](G["ADMIN_ID"], f"⚠️ Bot loglarida so'nggi 10 daqiqada {lim}+ ta xato. Loglarni tekshiring (/plus → Boshqaruv → Sog'liq).")
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("maintenance")


def cleanup():
    now_s = G["now"]().isoformat(timespec="seconds")
    G["run"]("DELETE FROM px_board WHERE expires < ?", (now_s,))
    G["run"]("DELETE FROM px_rsvp WHERE board_id NOT IN (SELECT id FROM px_board)")
    cut = (G["now"]() - dt.timedelta(days=180)).isoformat(timespec="seconds")
    G["run"]("DELETE FROM px_audit WHERE ts < ?", (cut,))
    G["run"]("DELETE FROM px_xplog WHERE ts < ?", ((G["now"]() - dt.timedelta(days=60)).isoformat(timespec="seconds"),))
    G["run"]("DELETE FROM px_slots WHERE at < ? AND student IS NULL", (G["now"]().strftime("%Y-%m-%dT%H:%M"),))
    G["run"]("DELETE FROM px_plan WHERE day < ?", ((G["now"]().date() - dt.timedelta(days=14)).isoformat(),))
    G["run"]("DELETE FROM px_duels WHERE created < ?", (cut,))


async def send_morning_plans(day):
    for r in G["fetch_all"]("SELECT user_id, text FROM px_plan WHERE day=? AND done=0", (day,)):
        if G["claim"](r["user_id"], f"px_plan:{day}"):
            await G["safe_send"](r["user_id"], f"📆 <b>Bugungi o'qish rejasi</b>\n\n{G['esc'](r['text'])}",
                                 KB([[B("✅ Bajardim (+5 XP)", f"px:pd:{day}")]]))
            await asyncio.sleep(0.05)


# ======================================================================
# Web: admin dashboard va ochiq API
# ======================================================================
PX_HTML = r"""<!doctype html><html lang="uz"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Plus dashboard</title><script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:#fff;--fg:#1c1c1e;--card:#f2f2f7;--ac:#2f80ed;--mut:#8e8e93}
@media(prefers-color-scheme:dark){:root{--bg:#111;--fg:#f2f2f7;--card:#1c1c1e;--ac:#5aa2ff;--mut:#9a9aa0}}
body{margin:0;padding:14px;background:var(--tg-theme-bg-color,var(--bg));color:var(--tg-theme-text-color,var(--fg));font:15px/1.4 system-ui,sans-serif}
h1{font-size:18px;margin:0 0 12px}.g{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:14px}
.c{background:var(--tg-theme-secondary-bg-color,var(--card));border-radius:12px;padding:10px 12px}.c b{display:block;font-size:20px}.c span{font-size:12px;color:var(--mut)}
.ch{background:var(--tg-theme-secondary-bg-color,var(--card));border-radius:12px;padding:10px 12px;margin-bottom:10px}.ch h2{font-size:13px;margin:0 0 6px;color:var(--mut);font-weight:600}
svg{width:100%;height:90px;display:block}.e{color:#e5484d;padding:20px;text-align:center}
</style></head><body><h1>📈 Plus dashboard</h1><div id="o">Yuklanmoqda…</div>
<script>
const tg=window.Telegram&&Telegram.WebApp;if(tg){tg.ready();tg.expand()}
function chart(t,a){const m=Math.max(1,...a.map(x=>x[1])),w=300,h=80,b=w/a.length;
let s=`<div class="ch"><h2>${t} · jami ${a.reduce((p,x)=>p+x[1],0)}</h2><svg viewBox="0 0 ${w} ${h+10}" preserveAspectRatio="none">`;
a.forEach((x,i)=>{const v=x[1]/m*h;s+=`<rect x="${i*b+1}" y="${h-v}" width="${b-2}" height="${Math.max(v,0.5)}" rx="1.5" fill="var(--tg-theme-button-color,var(--ac))"><title>${x[0]}: ${x[1]}</title></rect>`});
return s+`</svg></div>`}
const card=(n,l)=>`<div class="c"><b>${n}</b><span>${l}</span></div>`;
fetch('/api/px/stats',{headers:{'X-Init-Data':tg?tg.initData:''}}).then(r=>r.ok?r.json():Promise.reject(r.status)).then(d=>{
let h='<div class="g">'+card(d.users,'Foydalanuvchi')+card(d.active1,'Faol (24 soat)')+card(d.active7,'Faol (7 kun)')+card(d.xp_users,'XP olganlar')
+card(d.cards,'Kartalar')+card(d.groups,'Guruhlar')+card(d.board,'E\u2019lonlar')+card(d.pending,'Tasdiq kutmoqda')
+(d.premium!==undefined?card(d.premium,'Premium')+card((d.revenue||0).toLocaleString('ru-RU')+' so\u2019m','Daromad'):'')+'</div>';
h+=chart('Yangi foydalanuvchilar (30 kun)',d.series.new)+chart('AI so\u2019rovlari',d.series.ai)+chart('Daromad',d.series.rev)+chart('XP faolligi',d.series.xp);
document.getElementById('o').innerHTML=h}).catch(c=>{document.getElementById('o').innerHTML='<div class="e">Ruxsat yo\u2019q yoki xato ('+c+')</div>'});
</script></body></html>"""

OPEN_ENDPOINTS = {"me": "w_me", "schedule": "w_schedule", "grades": "w_grades", "gpa": "w_gpa", "exams": "w_exams",
                  "attendance": "w_attendance", "tasks": "w_tasks"}


def _routes():
    from aiohttp import web
    R, WebErr, jres = G["R"], G["WebErr"], G["jres"]

    @R.get("/px")
    async def px_page(request):
        return web.Response(text=PX_HTML, content_type="text/html")

    @R.get("/api/px/stats")
    async def px_stats(request):
        uid = request["uid"]
        if not (G["is_admin"](uid) or role_of(uid) == "moderator"):
            raise WebErr("forbidden", 403)
        return jres(await asyncio.to_thread(stats_data))

    @R.get("/open/v1/{what}")
    async def open_api(request):
        fn = NS.get(OPEN_ENDPOINTS.get(request.match_info["what"], ""))
        if not fn:
            raise WebErr("not_found", 404)
        key = request.headers.get("X-API-Key", "")
        row = G["fetch_one"]("SELECT user_id FROM px_apikeys WHERE key_hash=?", (pc.hash_key(key),)) if key else None
        if not row:
            raise WebErr("auth", 401)
        uid = row["user_id"]
        if (uid != G["ADMIN_ID"] and NS["is_blocked"](uid)) or not G["get_user_token"](uid):
            raise WebErr("forbidden", 403)
        t = time.monotonic()
        hits = [x for x in API_HITS.get(uid, []) if t - x < 60]
        if len(hits) >= 30:
            raise WebErr("rate", 429)
        hits.append(t)
        API_HITS[uid] = hits
        if len(API_HITS) > 3000:
            API_HITS.clear()
        request["uid"] = uid
        resp = await fn(request)
        resp.headers["Cache-Control"] = "no-store"
        return resp


# ======================================================================
# Ulash
# ======================================================================
def _register():
    dp = G["dp"]
    m, c = dp.message, dp.callback_query
    m.register(cmd_plus, Command("plus"))
    m.register(cmd_plus, F.text == G["B_PLUS"])
    m.register(cmd_promo, Command("promo"))
    S = StateFilter
    for fn, st in (
        (h_card_add, PxStates.card_add), (h_calc, PxStates.calc_in), (h_gpa, PxStates.gpa_in), (h_plan, PxStates.plan_in),
        (h_ai_in, PxStates.ai_in), (h_docchat, PxStates.docchat), (h_promo, PxStates.promo), (h_gift, PxStates.gift),
        (h_grp_name, PxStates.grp_name), (h_grp_join, PxStates.grp_join), (h_grp_post, PxStates.grp_post),
        (h_grp_poll, PxStates.grp_poll), (h_brd_title, PxStates.brd_title), (h_brd_body, PxStates.brd_body),
        (h_brd_extra, PxStates.brd_extra), (h_relay, PxStates.relay), (h_anon, PxStates.anon),
        (h_rev_subj, PxStates.rev_subj), (h_rev_comment, PxStates.rev_comment), (h_slot_note, PxStates.slot_note),
        (h_mat_subj, PxStates.mat_subj), (h_mat_title, PxStates.mat_title), (h_mat_file, PxStates.mat_file),
        (h_duel_topic, PxStates.duel_topic), (h_duel_join, PxStates.duel_join), (h_adm_role, PxStates.adm_role),
        (h_adm_promo, PxStates.adm_promo), (h_adm_reply, PxStates.adm_reply), (h_mat_search, PxStates.mat_search),
        (h_brd_search, PxStates.brd_search),
    ):
        m.register(fn, S(st))
    c.register(cb_plus, F.data.startswith("px:"))


def setup(ns):
    """hemis3.py dan chaqiriladi (hub.setup kabi)."""
    missing = [k for k in NEEDED if k not in ns]
    if missing:
        raise RuntimeError("plus.setup: hemis3.py da topilmadi: " + ", ".join(missing))
    G.update({k: ns[k] for k in NEEDED})
    NS.clear()
    NS.update(ns)
    _register()
    _routes()
    orig_block = ns["set_blocked"]

    def set_blocked_audited(user_id, value):
        r = orig_block(user_id, value)
        audit(G["ADMIN_ID"], "block" if value else "unblock", user_id)
        return r
    ns["set_blocked"] = set_blocked_audited
    logging.info("Plus moduli yuklandi")


def start():
    """main() ichida, middleware'lar qo'shilgandan keyin chaqiriladi."""
    init_tables()
    mw = PlusMiddleware()
    G["dp"].message.outer_middleware(mw)
    G["dp"].callback_query.outer_middleware(mw)
    logging.getLogger().addHandler(ErrCounter())
    try:
        n, err = migrate_tokens()
        if n:
            logging.warning("Plus: %d ta token shifrlandi", n)
            spawn(G["safe_send"](G["ADMIN_ID"], f"🔐 {n} ta eski (shifrlanmagan) token ENCRYPTION_KEY bilan shifrlandi."))
        elif err and plain_token_count():
            logging.warning("Plus: tokenlar shifrlanmagan — %s", err)
    except Exception:
        logging.exception("token migratsiyasi")
    spawn(maintenance())
