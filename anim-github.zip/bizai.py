# -*- coding: utf-8 -*-
"""
bizai.py - "Telegram Business AI": Telegram Premium'dagi Business > Chat-botlar orqali bot SHAXSIY akkauntingizga
yozganlarga sun'iy intellekt bilan javob beradi. Userbot/Telethon KERAK EMAS: bu Telegram'ning rasmiy yo'li
(Bot API business_connection / business_message), akkaunt xavfsiz, login kodi so'ralmaydi.

Ulash: patch_bizai.py ni ishga tushiring (yoki qo'lda: hemis3.py da `import bizai as _bizai;
_bizai.setup(globals())` va main() da `_bizai.start()`). Boshqaruv: Admin Panel -> «💼 Telegram Business AI» yoki /bizai
(callback prefiksi "bz:"). AI provayder/kalit: agar aimode.py ulangan bo'lsa, uning sozlamalari (🤖 AI avto-javob ->
AI provayder) ishlatiladi; bo'lmasa .env dagi GEMINI_API_KEY.
Kerak: aiogram >= 3.10 (pip install -U aiogram).
"""
import asyncio
import collections
import logging
import random
import re
import sys
import time
from contextlib import closing

from aiogram import F, types
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from archive_parser import parse_telegram_export

NEEDED = ["dp", "bot", "ADMIN_ID", "is_admin", "esc", "now", "fetch_one", "fetch_all", "run", "insert",
          "safe_send", "interrupted", "edit", "db"]
G = {}

DEFAULT_SYSTEM = (
    "Sen {owner}ning Telegram'dagi shaxsiy AI yordamchisisan va unga yozganlarga u nomidan javob berasan. "
    "Qisqa, do'stona va aniq yoz. Foydalanuvchi qaysi tilda yozsa, shu tilda javob ber. "
    "Agar kimdir sendan odammisan yoki bot deb jiddiy so'rasa, AI yordamchi ekaningni ayt. "
    "Pul o'tkazish, parol, kod yoki shaxsiy ma'lumot haqida va'da berma va so'rama; bunday masalalarda "
    "{owner} o'zi javob berishini ayt. Bilmagan narsangni o'ylab topma. Bugun: {date}, vaqt: {time}."
)

D = {
    "enabled": "1", "scope": "admin", "system": DEFAULT_SYSTEM,
    "history": "10", "rate": "20", "typing": "1", "delay": "2", "pause": "30",
    "maxchars": "600", "notify": "0", "alerts": "1", "disclose": "0",
}
SCOPES = {"admin": "Faqat mening (admin) akkauntim", "all": "Botni ulagan har kim"}

TASKS = set()
RATE = collections.deque()
LOCKS = set()
PENDING = set()
SENDING = set()
OWN = collections.deque(maxlen=500)
PAUSE = {}
LAST_ERR = {"t": 0.0}
ME = {}


class BzStates(StatesGroup):
    system = State()
    vip_add = State()
    test = State()
    reply = State()
    archive_import = State()


# ======================================================================
# Sozlama va baza
# ======================================================================
def init_tables():
    with closing(G["db"]()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS bz_cfg (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS bz_conn (n INTEGER PRIMARY KEY AUTOINCREMENT, cid TEXT UNIQUE, user_id INTEGER,
                                            name TEXT, username TEXT, can_reply INTEGER DEFAULT 1,
                                            tg_on INTEGER DEFAULT 1, ai_on INTEGER DEFAULT 1, ts REAL);
        CREATE TABLE IF NOT EXISTS bz_hist (id INTEGER PRIMARY KEY AUTOINCREMENT, conn_n INTEGER, chat_id INTEGER,
                                            role TEXT, text TEXT, ts REAL);
        CREATE INDEX IF NOT EXISTS bz_hist_u ON bz_hist (conn_n, chat_id, id);
        CREATE TABLE IF NOT EXISTS bz_inbox (id INTEGER PRIMARY KEY AUTOINCREMENT, conn_n INTEGER, cid TEXT, chat_id INTEGER, user_id INTEGER, name TEXT, text TEXT, ts REAL);
        CREATE INDEX IF NOT EXISTS bz_inbox_ts ON bz_inbox (ts DESC);
        CREATE TABLE IF NOT EXISTS bz_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_title TEXT NOT NULL,
            chat_id TEXT,
            message_id TEXT,
            sender TEXT,
            text TEXT NOT NULL,
            ts REAL,
            imported_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS bz_archive_ts ON bz_archive (ts DESC);
        CREATE INDEX IF NOT EXISTS bz_archive_chat ON bz_archive (chat_title);
        CREATE TABLE IF NOT EXISTS bz_vip (user_id INTEGER PRIMARY KEY, name TEXT, kind TEXT DEFAULT 'vip');
        CREATE TABLE IF NOT EXISTS bz_log (id INTEGER PRIMARY KEY AUTOINCREMENT, conn_n INTEGER, user_id INTEGER,
                                           name TEXT, inbound TEXT, outbound TEXT, ts REAL);
        """)
        conn.commit()


def cfg(k):
    r = G["fetch_one"]("SELECT value FROM bz_cfg WHERE key=?", (k,))
    return r["value"] if r and r["value"] is not None else D.get(k, "")


def cset(k, v):
    G["run"]("INSERT INTO bz_cfg (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


def cflt(k):
    try:
        return float(cfg(k))
    except ValueError:
        return 0.0


def flip(k):
    cset(k, "0" if cfg(k) == "1" else "1")


def esc_(s):
    return G["esc"](str(s))


def notify_admin(text, kb=None):
    return G["safe_send"](G["ADMIN_ID"], text, kb) if kb else G["safe_send"](G["ADMIN_ID"], text)


def spawn(coro):
    t = asyncio.create_task(coro)
    TASKS.add(t)
    t.add_done_callback(TASKS.discard)


def system_prompt(owner):
    n = G["now"]()
    s = cfg("system") or DEFAULT_SYSTEM
    for k, v in (("{owner}", owner or "egam"), ("{date}", f"{n:%d.%m.%Y}"), ("{time}", f"{n:%H:%M}")):
        s = s.replace(k, v)
    return s + f"\nJavobni {int(cflt('maxchars'))} belgidan oshirma. Markdown belgilarini (*, #, `) ishlatma."


# ======================================================================
# AI chaqiruvi: aimode sozlamalari -> bo'lmasa .env dagi Gemini
# ======================================================================
async def _gemini_env(msgs, system):
    import aiohttp
    key, model = G.get("GEMINI_API_KEY") or "", G.get("GEMINI_MODEL") or "gemini-flash-latest"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {"systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": r, "parts": [{"text": t}]} for r, t in msgs],
            "generationConfig": {"temperature": 0.7, "maxOutputTokens": 2048}}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=45)) as s:
        async with s.post(url, json=body, headers={"x-goog-api-key": key}) as r:
            data = await r.json(content_type=None)
            if r.status != 200:
                raise RuntimeError(f"Gemini {r.status}: {str(data)[:160]}")
    cands = data.get("candidates") or []
    parts = ((cands[0].get("content") or {}).get("parts") or []) if cands else []
    text = "".join(x.get("text", "") for x in parts if not x.get("thought")).strip()
    if not text:
        raise RuntimeError("AI bo'sh javob qaytardi")
    return text


async def ai_complete(msgs, system):
    am = sys.modules.get("aimode")
    err = None
    if am is not None and getattr(am, "G", None):
        try:
            return await am.ai_complete(msgs, system)
        except Exception as ex:
            if "kiritilmagan" not in str(ex):  # kalit bor, lekin API xato qildi - yashirmaymiz
                raise
            err = ex
    if G.get("GEMINI_API_KEY"):
        return await _gemini_env(msgs, system)
    raise err or RuntimeError("AI kalit topilmadi: /aimode -> AI provayder yoki .env ga GEMINI_API_KEY qo'shing")


def provider_line():
    am = sys.modules.get("aimode")
    try:
        if am is not None and getattr(am, "G", None):
            p = am.cfg("provider")
            if am.get_key(p):
                return f"{am.PROV[p]} · <code>{esc_(am.cfg(p + '_model') or '—')}</code> ✅"
    except Exception:
        pass
    if G.get("GEMINI_API_KEY"):
        return f"Gemini (.env) · <code>{esc_(G.get('GEMINI_MODEL') or 'gemini-flash-latest')}</code> ✅"
    return "❌ kalit yo'q (/aimode → AI provayder yoki .env: GEMINI_API_KEY)"


# ======================================================================
# Suhbat tarixi, ulanishlar
# ======================================================================
def save_hist(n, chat_id, role, text):
    G["run"]("INSERT INTO bz_hist (conn_n, chat_id, role, text, ts) VALUES (?,?,?,?,?)", (n, chat_id, role, text[:2000], time.time()))


def load_hist(n, chat_id):
    k = max(2, int(cflt("history")) or 10)
    rows = list(reversed(G["fetch_all"]("SELECT role, text FROM bz_hist WHERE conn_n=? AND chat_id=? ORDER BY id DESC LIMIT ?", (n, chat_id, k))))
    out = []
    for r in rows:
        role = "user" if r["role"] == "user" else "model"
        if out and out[-1][0] == role:
            out[-1][1] += "\n" + r["text"]
        else:
            out.append([role, r["text"]])
    while out and out[0][0] != "user":
        out.pop(0)
    return out


def vip_kind(uid):
    r = G["fetch_one"]("SELECT kind FROM bz_vip WHERE user_id=?", (uid,))
    return r["kind"] if r else None


def _can_reply(bc):
    rights = getattr(bc, "rights", None)
    if rights is not None:
        return bool(getattr(rights, "can_reply", False))
    return bool(getattr(bc, "can_reply", True))


def upsert_conn(bc):
    u = bc.user
    name = " ".join(x for x in (getattr(u, "first_name", ""), getattr(u, "last_name", "")) if x) or str(u.id)
    G["run"]("""INSERT INTO bz_conn (cid, user_id, name, username, can_reply, tg_on, ts) VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(cid) DO UPDATE SET user_id=excluded.user_id, name=excluded.name, username=excluded.username,
                can_reply=excluded.can_reply, tg_on=excluded.tg_on, ts=excluded.ts""",
             (bc.id, u.id, name, getattr(u, "username", None) or "", int(_can_reply(bc)), int(bool(bc.is_enabled)), time.time()))
    return G["fetch_one"]("SELECT * FROM bz_conn WHERE cid=?", (bc.id,))


async def get_conn(cid):
    r = G["fetch_one"]("SELECT * FROM bz_conn WHERE cid=?", (cid,))
    if r:
        return r
    try:
        return upsert_conn(await G["bot"].get_business_connection(cid))
    except Exception:
        logging.warning("Business AI: ulanish ma'lumotini olib bo'lmadi")
        return None


def conn_allowed(c):
    return cfg("scope") == "all" or c["user_id"] == G["ADMIN_ID"]


def conn_ready(c):
    return bool(c["tg_on"] and c["can_reply"] and c["ai_on"] and conn_allowed(c))


def dup_guard(c):
    """Boshqa modul shu akkauntga allaqachon javob berayotgan bo'lsa True (ikki marta javob ketmasligi uchun)."""
    try:
        sm = sys.modules.get("sleepmode")
        if sm is not None and getattr(sm, "CLIENT", None) and getattr(sm, "ME", None) \
                and sm.ME.id == c["user_id"] and sm.sleep_state()[0]:
            return True
        am = sys.modules.get("aimode")
        if am is not None and getattr(am, "CLIENT", None) and getattr(am, "ME", None) \
                and am.ME.id == c["user_id"] and am.cfg("enabled") == "1":
            return True
    except Exception:
        pass
    return False


# ======================================================================
# Business updatelari
# ======================================================================
async def on_connection(bc: types.BusinessConnection):
    try:
        c = upsert_conn(bc)
        ok = _can_reply(bc)
        if bc.is_enabled:
            t = (f"💼 <b>Business ulanishi</b>: {esc_(c['name'])}" + (f" (@{esc_(c['username'])})" if c["username"] else "") + "\n"
                 + ("✅ Javob berish ruxsati bor." if ok else "⚠️ Javob berish ruxsati YO'Q — Telegram → Business → Chat-botlar da «Xabarlarga javob berish»ni yoqing."))
            if not conn_allowed(c):
                t += "\n🔒 Bu akkaunt uchun AI o'chiq (faqat admin). /bizai → Sozlamalar → «Kimga» orqali o'zgartiring."
        else:
            t = f"💼 Business ulanishi o'chirildi: {esc_(c['name'])}"
        await notify_admin(t)
    except Exception:
        logging.exception("Business AI: ulanish xabarini qayta ishlashda xato")


async def on_message(message: types.Message):
    try:
        await handle(message)
    except Exception:
        logging.exception("Business AI: xabarni qayta ishlashda xato")


async def handle(message):
    cid = getattr(message, "business_connection_id", None)
    chat = message.chat
    if not cid or chat.type != "private" or cfg("enabled") != "1":
        return
    c = await get_conn(cid)
    if not c or not c["tg_on"] or not c["can_reply"]:
        return
    frm = message.from_user
    text = (message.text or message.caption or "").strip()[:2000] or ("[foydalanuvchi media yubordi]" if _has_media(message) else "")
    if frm and frm.id == c["user_id"]:  # egasi qo'lda yozdi
        if chat.id in SENDING or (chat.id, message.message_id) in OWN:
            return
        if text:
            save_hist(c["n"], chat.id, "model", text)
        pm = int(cflt("pause"))
        if pm > 0:
            PAUSE[(c["n"], chat.id)] = time.time() + pm * 60
        return
    if not frm or frm.is_bot or frm.id in (777000, 42777) or not text:
        return
    uid, name = frm.id, frm.full_name or str(frm.id)
    kind = vip_kind(uid)
    if kind == "ignore":
        return
    save_hist(c["n"], chat.id, "user", text)
    G["insert"]("INSERT INTO bz_inbox (conn_n,cid,chat_id,user_id,name,text,ts) VALUES (?,?,?,?,?,?,?)", (c["n"], c["cid"], chat.id, uid, name, text[:1000], time.time()))
    if cfg("alerts") == "1":
        await notify_admin(f"📩 <b>Yangi Business xabari</b>\n👤 {esc_(name)}\n💬 {esc_(text[:350])}")
    if kind == "vip":
        await notify_admin(f"⭐ <b>VIP</b> yozdi: {esc_(name)}\n{esc_(text[:200])}")
        G["insert"]("INSERT INTO bz_log (conn_n, user_id, name, inbound, outbound, ts) VALUES (?,?,?,?,?,?)", (c["n"], uid, name, text[:300], "", time.time()))
        return
    if not conn_ready(c):
        return
    if dup_guard(c) or PAUSE.get((c["n"], chat.id), 0) > time.time():
        return
    key = (c["n"], chat.id)
    PENDING.add(key)
    if key in LOCKS:
        return
    LOCKS.add(key)
    try:
        for _ in range(3):
            if key not in PENDING:
                break
            t = time.time()
            while RATE and t - RATE[0] > 60:
                RATE.popleft()
            if len(RATE) >= max(1, int(cflt("rate"))):
                PENDING.discard(key)
                break
            RATE.append(t)
            if not await ai_reply(c, chat.id, uid, name, text):
                break
    finally:
        LOCKS.discard(key)


def _has_media(m):
    return any(getattr(m, a, None) for a in ("photo", "video", "voice", "audio", "document", "sticker", "video_note", "animation"))


async def _typing(cid, chat_id, stop):
    while not stop.is_set():
        try:
            await G["bot"].send_chat_action(chat_id, "typing", business_connection_id=cid)
        except Exception:
            pass
        try:
            await asyncio.wait_for(stop.wait(), 4)
        except asyncio.TimeoutError:
            pass


async def ai_reply(c, chat_id, uid, name, last_text):
    key = (c["n"], chat_id)
    delay = cflt("delay")
    stop = asyncio.Event()
    typing = spawn_typing(c["cid"], chat_id, stop) if cfg("typing") == "1" else None
    try:
        if delay > 0:
            await asyncio.sleep(random.uniform(delay * 0.5, delay * 1.5))
        PENDING.discard(key)
        hist = load_hist(c["n"], chat_id)
        if not hist or hist[-1][0] != "user":
            return False
        reply = await ai_complete(hist, system_prompt(c["name"].split(" ")[0]))
    except Exception as ex:
        logging.warning("Business AI: javob olinmadi: %s", ex)
        if time.time() - LAST_ERR["t"] > 120:
            LAST_ERR["t"] = time.time()
            await notify_admin(f"⚠️ <b>Business AI xatosi</b>: {esc_(str(ex)[:250])}")
        return False
    finally:
        stop.set()
        if typing:
            await typing
    reply = ("🤖 " if cfg("disclose") == "1" else "") + reply[:3500]
    SENDING.add(chat_id)
    try:
        msg = await G["bot"].send_message(chat_id=chat_id, text=reply, business_connection_id=c["cid"], parse_mode=None)
        OWN.append((chat_id, msg.message_id))
    except Exception as ex:
        logging.warning("Business AI: yuborib bo'lmadi: %s", ex)
        if time.time() - LAST_ERR["t"] > 120:
            LAST_ERR["t"] = time.time()
            await notify_admin(f"⚠️ <b>Business AI</b>: javob yuborilmadi: {esc_(str(ex)[:250])}\n"
                               "Telegram → Business → Chat-botlar da «Xabarlarga javob berish» va shu suhbat ruxsatini tekshiring.")
        return False
    finally:
        await asyncio.sleep(0.5)
        SENDING.discard(chat_id)
    save_hist(c["n"], chat_id, "model", reply)
    G["insert"]("INSERT INTO bz_log (conn_n, user_id, name, inbound, outbound, ts) VALUES (?,?,?,?,?,?)",
                (c["n"], uid, name, last_text[:300], reply[:300], time.time()))
    if cfg("notify") == "1":
        await notify_admin(f"💼 <b>{esc_(name)}</b>:\n{esc_(last_text[:150])}\n↩️ {esc_(reply[:200])}")
    return True


def spawn_typing(cid, chat_id, stop):
    return asyncio.create_task(_typing(cid, chat_id, stop))


async def bz_loop():
    last_clean = 0.0
    while True:
        try:
            if time.time() - last_clean > 3600:
                last_clean = time.time()
                G["run"]("DELETE FROM bz_hist WHERE ts < ?", (time.time() - 7 * 86400,))
                G["run"]("DELETE FROM bz_log WHERE ts < ?", (time.time() - 14 * 86400,))
                for k in [k for k, v in PAUSE.items() if v < time.time()]:
                    PAUSE.pop(k, None)
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("Business AI tsikli xatosi")
        await asyncio.sleep(60)


# ======================================================================
# Panel (inline tugmalar)
# ======================================================================
def B(text, data):
    return InlineKeyboardButton(text=text, callback_data=data)


def KB(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def onoff(k):
    return "✅" if cfg(k) == "1" else "❌"


def today_stats():
    t0 = G["now"]().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    r = G["fetch_one"]("SELECT COUNT(DISTINCT user_id) u, COALESCE(SUM(outbound<>''),0) r FROM bz_log WHERE ts>=?", (t0,))
    return r["u"], r["r"]


def conn_line(c):
    st = "✅" if conn_ready(c) else "⛔"
    why = ""
    if not c["tg_on"]:
        why = " (Telegram'da o'chirilgan)"
    elif not c["can_reply"]:
        why = " (javob berish ruxsati yo'q)"
    elif not conn_allowed(c):
        why = " (faqat admin rejimi)"
    elif not c["ai_on"]:
        why = " (AI o'chirilgan)"
    return f"{st} {esc_(c['name'])}" + (f" @{esc_(c['username'])}" if c["username"] else "") + why


def v_main():
    hol = "🟢 <b>AI yoqilgan</b>" if cfg("enabled") == "1" else "⛔ <b>AI o'chirilgan</b>"
    u, r = today_stats()
    conns = G["fetch_all"]("SELECT * FROM bz_conn ORDER BY n DESC LIMIT 5")
    cl = "\n".join(conn_line(c) for c in conns) if conns else "Hali ulanish yo'q — «📖 Qanday ulanadi» ni bosing."
    t = (f"💼 <b>Telegram Business AI</b>\n\n{hol}\n🧠 AI: {provider_line()}\n👤 Kimga: <b>{SCOPES[cfg('scope')]}</b>\n"
         f"📊 Bugun: yozganlar <b>{u}</b>, AI javoblari <b>{r}</b>\n\n<b>Ulanishlar:</b>\n{cl}")
    am = sys.modules.get("aimode")
    if am is not None and getattr(am, "CLIENT", None) and am.cfg("enabled") == "1":
        t += "\n\n⚠️ <i>«🤖 AI avto-javob» (userbot) ham yoqilgan: shu akkaunt uchun faqat bittasi javob beradi (userbot).</i>"
    rows = [
        [B(f"AI: {onoff('enabled')}", "bz:sw:enabled"), B("🧪 Sinash", "bz:tst")],
        [B("📖 Qanday ulanadi", "bz:guide"), B("🔗 Ulanishlar", "bz:cn")],
        [B("📝 Prompt (xarakter)", "bz:sys"), B("👥 Filtrlar / VIP", "bz:fl")],
        [B("📥 Xabarlar", "bz:inbox"), B("📊 Hisobot", "bz:rp")],
        [B("📜 Eski suhbatlar arxivi", "bz:archive")],
        [B("⚙️ Sozlamalar", "bz:set")],
        [B("⬅️ Admin panel", "admin_back")],
    ]
    return t, KB(rows)


def v_guide():
    un = ME.get("username") or "bot_username"
    t = ("📖 <b>Telegram Business orqali ulash</b>\n\n"
         "Kerak: <b>sizning akkauntingizda Telegram Premium</b> (Business funksiyalari).\n\n"
         "1) Telegram → <b>Sozlamalar</b> → <b>Telegram Business</b> → <b>Chat-botlar</b>.\n"
         f"2) Botni tanlang: <code>@{esc_(un)}</code>\n"
         "3) <b>«Xabarlarga javob berish»</b> ruxsatini yoqing; qaysi suhbatlarga ruxsat berishni tanlang "
         "(hammasi yoki istisnolar).\n"
         "4) Bot sizga «💼 Business ulanishi» xabarini yuboradi — tayyor.\n\n"
         "<i>Odamlar sizga yozganda AI javob beradi. Siz o'zingiz yozsangiz, shu suhbatda AI pauza qiladi. "
         "Ulanishni istalgan vaqt shu menyuda o'chirib-yoqishingiz mumkin.</i>")
    return t, KB([[B("⬅️ Orqaga", "bz:menu")]])


def v_conns():
    rows_db = G["fetch_all"]("SELECT * FROM bz_conn ORDER BY n DESC LIMIT 20")
    t = "🔗 <b>Ulanishlar</b>\n\n" + ("\n".join(conn_line(c) for c in rows_db) or "Hali yo'q.")
    rows = [[B(f"{'✅' if c['ai_on'] else '❌'} {c['name'][:25]}", f"bz:ct:{c['n']}")] for c in rows_db]
    rows.append([B("⬅️ Orqaga", "bz:menu")])
    return t, KB(rows)


def v_sys():
    t = ("📝 <b>AI prompti (xarakter va qoidalar)</b>\n\n"
         f"<code>{esc_(cfg('system')[:2500])}</code>\n\n"
         "<i>O'zgaruvchilar: {owner} — ism, {date}, {time}.</i>")
    return t, KB([[B("✏️ O'zgartirish", "bz:se"), B("↩️ Standart", "bz:sr")], [B("⬅️ Orqaga", "bz:menu")]])


def v_filters():
    nv = G["fetch_one"]("SELECT COUNT(*) c FROM bz_vip WHERE kind='vip'")["c"]
    ni = G["fetch_one"]("SELECT COUNT(*) c FROM bz_vip WHERE kind='ignore'")["c"]
    t = (f"👥 <b>Filtrlar</b>\n\n⭐ <b>VIP</b> — AI javob bermaydi, lekin yozsa sizga darhol xabar keladi.\n"
         "🔇 <b>Ignor</b> — AI umuman e'tibor bermaydi.\n\n<i>Guruhlar va botlarga AI hech qachon javob bermaydi.</i>")
    return t, KB([[B(f"⭐ VIP ({nv})", "bz:vl:vip"), B(f"🔇 Ignor ({ni})", "bz:vl:ignore")], [B("⬅️ Orqaga", "bz:menu")]])


def v_vips(kind):
    rows_db = G["fetch_all"]("SELECT * FROM bz_vip WHERE kind=? ORDER BY rowid DESC LIMIT 30", (kind,))
    title = "⭐ VIP ro'yxati" if kind == "vip" else "🔇 Ignor ro'yxati"
    t = f"<b>{title}</b>\n" + ("\n".join(f"• {esc_(r['name'])} (<code>{r['user_id']}</code>)" for r in rows_db) or "Bo'sh.")
    rows = [[B(f"🗑 {r['name'][:25]}", f"bz:vd:{r['user_id']}:{kind}")] for r in rows_db]
    rows += [[B("➕ Qo'shish", f"bz:va:{kind}")], [B("⬅️ Orqaga", "bz:fl")]]
    return t, KB(rows)


CYCLES = {
    "rate": ("🚦 Tezlik limiti", [5, 10, 20, 40], "/daq"),
    "history": ("🧵 Kontekst", [4, 10, 20, 30], " xabar"),
    "pause": ("⏸ Qo'lda yozsam AI pauza", [0, 15, 30, 60, 180], " daq"),
    "delay": ("⏱ Javob kechikishi", [0, 2, 5, 10], " s"),
    "maxchars": ("📏 Javob uzunligi", [300, 600, 1000, 2000], " belgi"),
}


def cyc_label(k):
    name, _, unit = CYCLES[k]
    v = cfg(k)
    return f"{name}: o'chiq" if k == "pause" and v in ("0", "0.0") else f"{name}: {v}{unit}"


def v_settings():
    t = ("⚙️ <b>Sozlamalar</b>\n\n<i>«Qo'lda yozsam AI pauza» — siz o'zingiz biror kishiga yozsangiz, "
         "AI shu suhbatda ko'rsatilgan vaqt davomida jim turadi.</i>")
    rows = [
        [B(f"👤 Kimga: {SCOPES[cfg('scope')]}", "bz:scope")],
        [B(f"⌨️ «Yozmoqda…» effekti: {onoff('typing')}", "bz:sw:typing")],
        [B(f"🤖 Javob boshida «🤖» belgisi: {onoff('disclose')}", "bz:sw:disclose")],
        [B(f"🔔 Har javob haqida menga xabar: {onoff('notify')}", "bz:sw:notify")],
        [B(f"📩 Yangi xabar ogohlantirishi: {onoff('alerts')}", "bz:sw:alerts")],
    ] + [[B(cyc_label(k), f"bz:cy:{k}")] for k in CYCLES] + [[B("⬅️ Orqaga", "bz:menu")]]
    return t, KB(rows)


def v_report():
    import datetime as _dt
    u, r = today_stats()
    last = G["fetch_all"]("SELECT name, inbound, outbound, ts FROM bz_log ORDER BY ts DESC LIMIT 8")
    t = f"📊 <b>Hisobot</b>\n\nBugun: <b>{u}</b> kishi yozdi, <b>{r}</b> ta AI javobi.\n\n<b>Oxirgilari:</b>\n"
    for x in last:
        t += (f"• {_dt.datetime.fromtimestamp(x['ts'], G['now']().tzinfo):%d.%m %H:%M} <b>{esc_(x['name'])}</b>: "
              f"{esc_((x['inbound'] or '')[:40])}{' ↩️ ' + esc_(x['outbound'][:40]) if x['outbound'] else ' ⭐'}\n")
    if not last:
        t += "Hali yo'q.\n"
    return t, KB([[B("🧹 Tozalash (log + suhbat xotirasi)", "bz:rc")], [B("⬅️ Orqaga", "bz:menu")]])


SW_VIEW = {"enabled": "menu", "typing": "set", "disclose": "set", "notify": "set", "alerts": "set"}


def v_inbox():
    rows_db = G["fetch_all"]("SELECT id,name,text,ts FROM bz_inbox ORDER BY ts DESC LIMIT 10")
    t = "📥 <b>Business xabarlari</b>\n\nOxirgi ruxsat berilgan chatlardan kelgan xabarlar:"
    rows = []
    for r in rows_db:
        label = (r["name"] + ": " + (r["text"] or "")).replace("\n", " ")[:48]
        rows.append([B(label, f"bz:im:{r['id']}")])
    if not rows_db:
        t += "\nHozircha xabar yo'q."
    rows.append([B("⬅️ Orqaga", "bz:menu")])
    return t, KB(rows)


def v_inbox_item(item_id):
    r = G["fetch_one"]("SELECT * FROM bz_inbox WHERE id=?", (item_id,))
    if not r:
        return "Xabar topilmadi yoki o'chirilgan.", KB([[B("⬅️ Xabarlar", "bz:inbox")]])
    t = (f"📩 <b>{esc_(r['name'])}</b>\n🕒 {G['now']().fromtimestamp(r['ts']).strftime('%d.%m.%Y %H:%M')}\n\n"
         f"{esc_(r['text'] or '[matnsiz xabar]')}")
    return t, KB([[B("↩️ Javob yozish", f"bz:reply:{item_id}")], [B("⬅️ Xabarlar", "bz:inbox")]])


def v_archive():
    total = G["fetch_one"]("SELECT COUNT(*) AS c FROM bz_archive")["c"]
    rows_db = G["fetch_all"]("SELECT id,chat_title,sender,text,ts FROM bz_archive ORDER BY ts DESC, id DESC LIMIT 10")
    t = (f"📜 <b>Eski suhbatlar arxivi</b>\n\nImport qilingan xabarlar: <b>{total}</b>\n"
         "Bu bo‘lim faqat akkaunt egasi eksport qilgan JSON arxivini ko‘rsatadi.\n\n<b>Oxirgi xabarlar:</b>\n")
    rows = []
    for r in rows_db:
        stamp = G["now"]().fromtimestamp(r["ts"]).strftime("%d.%m.%Y %H:%M") if r["ts"] else "sana yo‘q"
        label = (str(r["chat_title"]) + " · " + str(r["text"] or "")).replace("\n", " ")[:42]
        rows.append([B(label, f"bz:aritem:{r['id']}")])
    if not rows_db:
        t += "Hali arxiv import qilinmagan.\n"
    rows += [[B("📤 JSON arxiv import qilish", "bz:arimport")],
             [B("🗑 Arxivni tozalash", "bz:arclear")],
             [B("⬅️ Orqaga", "bz:menu")]]
    return t, KB(rows)


def v_archive_item(item_id):
    r = G["fetch_one"]("SELECT * FROM bz_archive WHERE id=?", (item_id,))
    if not r:
        return "Arxiv xabari topilmadi.", KB([[B("⬅️ Arxiv", "bz:archive")]])
    stamp = G["now"]().fromtimestamp(r["ts"]).strftime("%d.%m.%Y %H:%M") if r["ts"] else "sana yo‘q"
    text = (f"📜 <b>{esc_(r['chat_title'])}</b>\n👤 {esc_(r['sender'] or 'Noma’lum')}\n"
            f"🕒 {stamp}\n\n{esc_((r['text'] or '')[:3500])}")
    return text, KB([[B("⬅️ Arxiv", "bz:archive")]])


async def h_archive_import(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    if not message.from_user or not G["is_admin"](message.from_user.id):
        return
    doc = message.document
    if not doc or not doc.file_name or not doc.file_name.lower().endswith(".json"):
        return await message.answer("Telegram Desktop eksportidagi result.json faylini yuboring. Bekor qilish: /cancel")
    if doc.file_size and doc.file_size > 10 * 1024 * 1024:
        return await message.answer("Fayl 10 MB dan katta. Telegram eksportida faqat kerakli chatlarni tanlab qayta eksport qiling.")
    try:
        f = __import__("io").BytesIO()
        await G["bot"].download(doc, destination=f)
        batch = parse_telegram_export(f.getvalue(), max_bytes=10 * 1024 * 1024, max_messages=10_000)
        if not batch:
            raise ValueError("Eksportda matnli xabar topilmadi")
        with closing(G["db"]()) as conn:
            conn.executemany("INSERT INTO bz_archive (chat_title,chat_id,message_id,sender,text,ts,imported_at) VALUES (?,?,?,?,?,?,?)", batch)
            conn.commit()
        await state.clear()
        await message.answer(f"✅ Arxiv import qilindi: {len(batch)} ta matnli xabar.\nMaxfiylik uchun JSON faylini faqat o‘zingiz ishonadigan joyda saqlang.")
        await send_view(message, v_archive())
    except Exception as ex:
        logging.warning("Business archive import failed: %s", ex)
        await message.answer("❌ JSON faylni o‘qib bo‘lmadi. Telegram Desktop’dan JSON formatida eksport qilingan result.json faylini yuboring.")


def view_for(name):
    return {"menu": v_main, "guide": v_guide, "cn": v_conns, "sys": v_sys, "fl": v_filters,
            "rp": v_report, "set": v_settings, "archive": v_archive}[name]()


async def show(call, view):
    await G["edit"](call, view[0], view[1])


async def prompt(call, text):
    await call.message.answer(text + "\n\nBekor qilish: /cancel")


async def cb_bz(call: types.CallbackQuery, state: FSMContext):
    if not G["is_admin"](call.from_user.id):
        return await call.answer()
    p = call.data.split(":")
    a = p[1] if len(p) > 1 else "menu"
    await state.clear()
    if a in ("menu", "guide", "cn", "sys", "fl", "rp", "set", "inbox", "archive"):
        await call.answer()
        return await show(call, v_inbox() if a == "inbox" else view_for(a))
    if a == "sw" and len(p) > 2 and p[2] in SW_VIEW:
        flip(p[2])
        await call.answer("Saqlandi")
        return await show(call, view_for(SW_VIEW[p[2]]))
    if a == "scope":
        cset("scope", "all" if cfg("scope") == "admin" else "admin")
        await call.answer("Saqlandi")
        return await show(call, v_settings())
    if a == "cy" and len(p) > 2 and p[2] in CYCLES:
        opts = [str(x) for x in CYCLES[p[2]][1]]
        cur = cfg(p[2])
        if cur not in opts and cur.replace(".", "", 1).isdigit() and str(int(float(cur))) in opts:
            cur = str(int(float(cur)))
        cset(p[2], opts[(opts.index(cur) + 1) % len(opts)] if cur in opts else opts[0])
        await call.answer()
        return await show(call, v_settings())
    if a == "ct" and len(p) > 2 and p[2].isdigit():
        G["run"]("UPDATE bz_conn SET ai_on = 1 - ai_on WHERE n=?", (int(p[2]),))
        await call.answer("Saqlandi")
        return await show(call, v_conns())
    if a == "se":
        await call.answer()
        await state.set_state(BzStates.system)
        return await prompt(call, "📝 AI uchun yangi prompt yuboring (maks. 3000 belgi).\nO'zgaruvchilar: {owner} {date} {time}")
    if a == "sr":
        cset("system", DEFAULT_SYSTEM)
        await call.answer("Standart tiklandi")
        return await show(call, v_sys())
    if a == "tst":
        await call.answer()
        await state.set_state(BzStates.test)
        return await prompt(call, "🧪 Istalgan savol yuboring — AI hozirgi sozlamalar bilan javob beradi (hech kimga yuborilmaydi).")
    if a == "vl" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        return await show(call, v_vips(p[2]))
    if a == "va" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        await state.set_state(BzStates.vip_add)
        await state.update_data(kind=p[2])
        return await prompt(call, "Foydalanuvchining <b>ID</b> raqami yoki undan <b>forward</b> qilingan xabarni yuboring:")
    if a == "vd" and len(p) > 3 and p[2].lstrip("-").isdigit():
        G["run"]("DELETE FROM bz_vip WHERE user_id=?", (int(p[2]),))
        await call.answer("O'chirildi")
        return await show(call, v_vips(p[3]))
    if a == "im" and len(p) > 2 and p[2].isdigit():
        await call.answer()
        view = v_inbox_item(int(p[2]))
        return await show(call, view)
    if a == "reply" and len(p) > 2 and p[2].isdigit():
        item = G["fetch_one"]("SELECT * FROM bz_inbox WHERE id=?", (int(p[2]),))
        if not item:
            await call.answer("Xabar topilmadi", show_alert=True)
            return
        conn = G["fetch_one"]("SELECT * FROM bz_conn WHERE n=?", (item["conn_n"],))
        if not conn or not conn["tg_on"] or not conn["can_reply"]:
            await call.answer("Bu ulanishga javob berish ruxsati yo'q", show_alert=True)
            return
        await call.answer()
        await state.set_state(BzStates.reply)
        await state.update_data(inbox_id=int(p[2]))
        return await prompt(call, f"↩️ {esc_(item['name'])} ga yuboriladigan javobni yozing. Bekor qilish: /cancel")
    if a == "arimport":
        await call.answer()
        await state.set_state(BzStates.archive_import)
        return await prompt(call, "📤 Singlingiz roziligi bilan eksport qilingan Telegram Desktop result.json faylini yuboring. Faqat kerakli chatlarni eksport qiling; fayl maxfiy yozishmalarni o‘z ichiga olishi mumkin.")
    if a == "aritem" and len(p) > 2 and p[2].isdigit():
        await call.answer()
        return await show(call, v_archive_item(int(p[2])))
    if a == "arclear":
        await call.answer("Arxivni o‘chirishni tasdiqlang", show_alert=True)
        return await show(call, ("🗑 <b>Arxivni butunlay o‘chirish?</b>\nBu faqat import qilingan arxivni o‘chiradi.", KB([[B("Ha, o‘chirish", "bz:arconfirm"), B("Bekor qilish", "bz:archive")]])))
    if a == "arconfirm":
        G["run"]("DELETE FROM bz_archive")
        await call.answer("Arxiv o‘chirildi")
        return await show(call, v_archive())
    if a == "rc":
        G["run"]("DELETE FROM bz_log")
        G["run"]("DELETE FROM bz_hist")
        await call.answer("Tozalandi")
        return await show(call, v_report())
    await call.answer()


# ======================================================================
# Matnli kiritish (FSM)
# ======================================================================
async def send_view(message, view):
    await message.answer(view[0], reply_markup=view[1])


async def h_system(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t or len(t) > 3000:
        return await message.answer("Matn bo'sh yoki juda uzun (maks. 3000 belgi). Qayta yuboring:")
    cset("system", t)
    await state.clear()
    await send_view(message, v_sys())


async def h_test(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t:
        return await message.answer("Matn yuboring (bekor: /cancel):")
    wait = await message.answer("⏳ AI o'ylayapti…")
    try:
        ans = await ai_complete([["user", t[:2000]]], system_prompt(ME.get("owner") or "egam"))
        await wait.edit_text(f"🤖 <b>AI</b>:\n\n{esc_(ans[:3500])}")
    except Exception as ex:
        await wait.edit_text(f"❌ {esc_(str(ex)[:300])}")
    await state.clear()
    await send_view(message, v_main())


async def h_vip(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    kind = (await state.get_data()).get("kind", "vip")
    uid, name = None, ""
    fo = getattr(message, "forward_origin", None)
    fu = getattr(fo, "sender_user", None) or getattr(message, "forward_from", None)
    if fu:
        uid, name = fu.id, fu.full_name
    else:
        t = (message.text or "").strip()
        if re.fullmatch(r"\d{4,}", t):
            uid, name = int(t), t
    if not uid:
        return await message.answer("ID (raqam) yoki forward qilingan xabar yuboring.")
    G["run"]("INSERT INTO bz_vip (user_id, name, kind) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, kind=excluded.kind",
             (uid, name, kind))
    await state.clear()
    await send_view(message, v_vips(kind))


async def h_reply(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    if not message.from_user or not G["is_admin"](message.from_user.id):
        return
    text = (message.text or "").strip()
    if not text or text.startswith("/") or len(text) > 3500:
        return await message.answer("Oddiy matn yuboring (1–3500 belgi) yoki /cancel.")
    data = await state.get_data()
    item = G["fetch_one"]("SELECT * FROM bz_inbox WHERE id=?", (data.get("inbox_id"),))
    if not item:
        await state.clear()
        return await message.answer("Xabar topilmadi. /bizai orqali qayta oching.")
    conn = G["fetch_one"]("SELECT * FROM bz_conn WHERE n=?", (item["conn_n"],))
    if not conn or not conn["tg_on"] or not conn["can_reply"]:
        await state.clear()
        return await message.answer("Ulanish o'chirilgan yoki javob berish ruxsati yo'q.")
    try:
        await G["bot"].send_message(chat_id=item["chat_id"], text=text, business_connection_id=item["cid"], parse_mode=None)
        G["insert"]("INSERT INTO bz_log (conn_n,user_id,name,inbound,outbound,ts) VALUES (?,?,?,?,?,?)", (item["conn_n"], item["user_id"], item["name"], item["text"][:300], text[:300], time.time()))
        save_hist(item["conn_n"], item["chat_id"], "model", text)
        await state.clear()
        await message.answer("✅ Javob yuborildi.")
        await send_view(message, v_inbox())
    except Exception as ex:
        await state.clear()
        await message.answer(f"❌ Javob yuborilmadi: {esc_(str(ex)[:250])}")


async def cmd_bizai(message: types.Message, state: FSMContext):
    if not G["is_admin"](message.from_user.id):
        return
    await state.clear()
    await send_view(message, v_main())


def setup(ns):
    missing = [k for k in NEEDED if k not in ns]
    if missing:
        raise RuntimeError("bizai.setup: hemis3.py da topilmadi: " + ", ".join(missing))
    G.update({k: ns[k] for k in NEEDED})
    G["GEMINI_API_KEY"], G["GEMINI_MODEL"] = ns.get("GEMINI_API_KEY", ""), ns.get("GEMINI_MODEL", "")
    dp = G["dp"]
    if not (hasattr(dp, "business_message") and hasattr(dp, "business_connection")):
        raise RuntimeError("aiogram eski: Telegram Business uchun  pip install -U aiogram  (3.10+) kerak")
    m = dp.message
    m.register(cmd_bizai, Command("bizai"))
    for st, h in ((BzStates.system, h_system), (BzStates.vip_add, h_vip), (BzStates.test, h_test), (BzStates.reply, h_reply), (BzStates.archive_import, h_archive_import)):
        m.register(h, StateFilter(st))
    dp.callback_query.register(cb_bz, F.data.startswith("bz:"))
    dp.business_connection.register(on_connection)
    dp.business_message.register(on_message)
    logging.info("Telegram Business AI yuklandi")


async def _whoami():
    try:
        me = await G["bot"].get_me()
        ME["username"] = me.username
        row = G["fetch_one"]("SELECT name FROM bz_conn WHERE user_id=? LIMIT 1", (G["ADMIN_ID"],))
        ME["owner"] = (row["name"].split(" ")[0] if row else "")
    except Exception:
        logging.warning("Business AI: bot ma'lumotini olib bo'lmadi")


def start():
    init_tables()
    spawn(_whoami())
    spawn(bz_loop())
