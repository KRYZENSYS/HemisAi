# Kod auditi — HEMIS / Student Hub / Telegram Business AI

## Amalga oshirilgan ishlar

- Python modullari sintaksis bo'yicha tekshirildi.
- `requirements.txt` qo'shildi va o'rnatish skripti shu ro'yxatdan foydalanadigan qilindi.
- `.env.example` qo'shildi; unda haqiqiy token yoki API kalit yo'q.
- Telegram Desktop JSON eksportini tahlil qilish `archive_parser.py` ga ajratildi. Bu modul Telegram kutubxonalariga bog'liq emas.
- Arxiv parseriga fayl hajmi (10 MiB), xabarlar soni (10 000), noto'g'ri JSON, xizmat xabarlari va matnli entity-array testlari qo'shildi.
- ZIP ichiga `__pycache__` va `.pyc` fayllari kiritilmaydi.

## Test natijalari

- `python -m py_compile *.py`: muvaffaqiyatli.
- `python -m unittest discover -s tests -v`: 5 ta test muvaffaqiyatli.
- Telegram API bilan real ulanish bu muhitda bajarilmadi; shuning uchun Business ulanishi, bot huquqlari, AI provayder kaliti va mobil Termux muhiti bo'yicha jonli sinov o'tkazildi deb hisoblamang.

## Ishga tushirishdan oldin

1. `.env.example` faylidan `.env` yarating.
2. `BOT_TOKEN` va `ADMIN_ID` ni to'ldiring.
3. `bash hemis.sh setup` bilan kutubxonalarni o'rnating.
4. `bash hemis.sh` bilan ishga tushiring.
5. Telegram Business ishlashi uchun BotFather'da Business Mode va Telegram sozlamalarida botga xabarlarni ko'rish/javob berish huquqi berilgan bo'lishi kerak.

## Muhim cheklovlar

- Eski yozishmalar Telegram serveridan avtomatik yuklab olinmaydi. Arxiv bo'limi akkaunt egasi eksport qilgan `result.json` faylidagi matnlarni import qiladi.
- Arxivda faqat matnli xabarlar saqlanadi; media fayllarning o'zi import qilinmaydi.
- Bu paketning barcha tashqi API funksiyalarini jonli akkauntda tekshirishning iloji bo'lmadi. Syntax va mahalliy parser testlari muvaffaqiyatli bo'lishi jonli bot to'liq ishlashiga kafolat emas.
- `.env`, bot tokeni, API kalitlari va `hemis_bot.db` maxfiy saqlanishi kerak.
