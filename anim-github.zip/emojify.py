# -*- coding: utf-8 -*-
"""
emojify.py - botdagi BARCHA oddiy emoji'larni https://t.me/addemoji/... paketidagi CUSTOM EMOJI ga almashtiradi.

Qanday ishlaydi: bot yuboradigan har bir xabar/sarlavha (HTML) va inline tugma so'rov darajasida ushlanadi;
oddiy emoji -> <tg-emoji emoji-id="..">; inline tugmadagi birinchi emoji -> icon_custom_emoji_id.
Handlerlarga tegilmaydi. Telegram rad etsa, avtomatik oddiy emoji bilan qayta yuboriladi (xabar yo'qolmaydi).

Shart (Bot API): bot egasida (sizda) Telegram Premium bo'lishi kerak.
Boshqaruv: Admin Panel -> «🎭 Bot emoji».
"""
import asyncio
import json
import logging
import re
import time
from contextlib import closing

from aiogram import F, types
from aiogram.client.default import Default
from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

NEEDED = ["dp", "bot", "ADMIN_ID", "is_admin", "esc", "fetch_one", "fetch_all", "run", "insert", "safe_send",
          "interrupted", "edit", "db"]
G = {}
DEF = {"on": "1", "btn": "1", "replaced": "0", "fails": "0", "streak": "0"}
HAS_BTN_ICON = "icon_custom_emoji_id" in getattr(InlineKeyboardButton, "model_fields", {})
# emoji belgilari: asosiy diapazonlar + FE0F + ZWJ ketma-ketliklar
_E = r"[\U0001F000-\U0001FAFF\u2190-\u21FF\u2300-\u23FF\u2460-\u24FF\u25A0-\u27BF\u2900-\u297F\u2B00-\u2BFF\u3030\u303D\u3297\u3299\u00A9\u00AE\u203C\u2049\u2122\u2139]"
EMOJI_RE = re.compile(rf"{_E}\uFE0F?(?:\u200D{_E}\uFE0F?)*|[#*0-9]\uFE0F?\u20E3")
TAG_RE = re.compile(r"(<[^>]*>)")
SEEN = {}
CACHE = {"map": None}
TASKS = set()
MAX_PER_MSG = 90


class EmStates(StatesGroup):
    pk_link = State()


# ======================================================================
# Baza va sozlamalar
# ======================================================================
def init_tables():
    with closing(G["db"]()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS em_cfg (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS em_pack (id INTEGER PRIMARY KEY AUTOINCREMENT, short_name TEXT UNIQUE, title TEXT, data TEXT, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS em_map (key TEXT PRIMARY KEY, doc_id TEXT, alt TEXT);
        CREATE TABLE IF NOT EXISTS em_seen (key TEXT PRIMARY KEY, n INTEGER DEFAULT 0);
        """)
        conn.commit()
    CACHE["map"] = None


def cfg(k):
    r = G["fetch_one"]("SELECT value FROM em_cfg WHERE key=?", (k,))
    return r["value"] if r and r["value"] is not None else DEF.get(k, "")


def cset(k, v):
    G["run"]("INSERT INTO em_cfg (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


def bump(k, n=1):
    cset(k, int(cfg(k) or 0) + n)


def esc_(s):
    return G["esc"](str(s))


def norm(s):
    return s.replace("\uFE0F", "")


def get_map():
    """normallangan emoji -> custom emoji id (qo'lda xarita > faol paketlar alt'i)."""
    if CACHE["map"] is not None:
        return CACHE["map"]
    mp = {}
    for p in G["fetch_all"]("SELECT data FROM em_pack WHERE active=1 ORDER BY id DESC"):
        try:
            for cid, alt in json.loads(p["data"]):
                mp[norm(alt)] = cid
        except ValueError:
            continue
    for r in G["fetch_all"]("SELECT key, doc_id FROM em_map"):
        mp[r["key"]] = r["doc_id"]
    CACHE["map"] = mp
    return mp


def hexkey(k):
    return "-".join(f"{ord(c):x}" for c in k)


def unhex(h):
    return "".join(chr(int(x, 16)) for x in h.split("-"))


# ======================================================================
# Almashtirish
# ======================================================================
def emojify_html(text):
    """HTML matndagi (teg va <code>/<pre> tashqarisidagi) emoji'larni <tg-emoji> ga aylantiradi."""
    mp = get_map()
    out, depth, n = [], 0, 0
    for seg in TAG_RE.split(text):
        if seg.startswith("<") and seg.endswith(">"):
            low = seg.lower()
            if re.match(r"<(pre|code|tg-emoji)\b", low):
                depth += 1
            elif re.match(r"</(pre|code|tg-emoji)\b", low):
                depth = max(0, depth - 1)
            out.append(seg)
            continue
        if depth or not seg:
            out.append(seg)
            continue

        def sub(m):
            nonlocal n
            tok = m.group(0)
            key = norm(tok)
            cid = mp.get(key)
            if not cid or n >= MAX_PER_MSG:
                SEEN[key] = SEEN.get(key, 0) + 1
                return tok
            n += 1
            return f'<tg-emoji emoji-id="{cid}">{tok}</tg-emoji>'
        out.append(EMOJI_RE.sub(sub, seg))
    return "".join(out), n


def convert_markup(rm):
    """Inline tugma matnidagi BIRINCHI emoji -> icon_custom_emoji_id (agar aiogram qo'llasa)."""
    if not HAS_BTN_ICON or cfg("btn") != "1" or not isinstance(rm, InlineKeyboardMarkup):
        return rm, 0
    mp, cnt, rows = get_map(), 0, []
    for row in rm.inline_keyboard:
        new = []
        for b in row:
            if getattr(b, "icon_custom_emoji_id", None) or not b.text:
                new.append(b)
                continue
            m = EMOJI_RE.match(b.text)
            cid = mp.get(norm(m.group(0))) if m else None
            rest = b.text[m.end():].strip() if m else ""
            if cid and rest:
                new.append(b.model_copy(update={"text": rest, "icon_custom_emoji_id": cid}))
                cnt += 1
            else:
                if m and not cid:
                    SEEN[norm(m.group(0))] = SEEN.get(norm(m.group(0)), 0) + 1
                new.append(b)
        rows.append(new)
    return (InlineKeyboardMarkup(inline_keyboard=rows), cnt) if cnt else (rm, 0)


def transform(bot, method):
    upd, cnt = {}, 0
    if hasattr(method, "parse_mode") and getattr(method, "entities", None) is None and getattr(method, "caption_entities", None) is None:
        pm = method.parse_mode
        eff = getattr(getattr(bot, "default", None), "parse_mode", None) if isinstance(pm, Default) else pm
        if eff is not None and str(getattr(eff, "value", eff)).upper() == "HTML":
            for attr in ("text", "caption"):
                v = getattr(method, attr, None)
                if isinstance(v, str) and v:
                    nv, c = emojify_html(v)
                    if c:
                        upd[attr] = nv
                        cnt += c
    rm = getattr(method, "reply_markup", None)
    if rm is not None:
        nrm, c = convert_markup(rm)
        if c:
            upd["reply_markup"] = nrm
            cnt += c
    return (method.model_copy(update=upd) if upd else method), cnt


class EmojiMiddleware(BaseRequestMiddleware):
    async def __call__(self, make_request, bot, method):
        if cfg("on") != "1" or not get_map():
            return await make_request(bot, method)
        try:
            new, cnt = transform(bot, method)
        except Exception:
            logging.exception("emojify: o'zgartirishda xato")
            return await make_request(bot, method)
        if new is method:
            return await make_request(bot, method)
        try:
            res = await make_request(bot, new)
        except TelegramBadRequest as ex:
            if "not modified" in str(ex).lower():
                raise
            res = await make_request(bot, method)  # oddiy emoji bilan qayta urinish
            streak = int(cfg("streak") or 0) + 1
            cset("streak", streak)
            bump("fails")
            logging.warning("emojify: custom emoji rad etildi (%s). Oddiy matn yuborildi.", ex)
            if streak == 5:
                cset("on", "0")
                spawn(G["safe_send"](G["ADMIN_ID"], "⚠️ <b>Bot emoji</b>: Telegram custom emoji'ni ketma-ket rad etdi, shuning uchun "
                                     "vaqtincha o'chirildi.\nSabab: bot egasida Telegram Premium yo'q yoki paketdagi emoji yaroqsiz.\n"
                                     f"Oxirgi xato: <code>{esc_(str(ex)[:150])}</code>"))
            return res
        if cfg("streak") != "0":
            cset("streak", 0)
        bump("replaced", cnt)
        return res


def spawn(coro):
    t = asyncio.create_task(coro)
    TASKS.add(t)
    t.add_done_callback(TASKS.discard)


async def flush_loop():
    while True:
        await asyncio.sleep(90)
        try:
            flush_now()
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("emojify flush xatosi")


def flush_now():
    for k, n in list(SEEN.items()):
        if len(k) <= 12:
            G["run"]("INSERT INTO em_seen (key, n) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET n = n + excluded.n", (k, n))
    SEEN.clear()


# ======================================================================
# Panel
# ======================================================================
def B(text, data=None, icon=None):
    if icon and HAS_BTN_ICON:
        return InlineKeyboardButton(text=text, callback_data=data, icon_custom_emoji_id=icon)
    return InlineKeyboardButton(text=text, callback_data=data)


def KB(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def onoff(k):
    return "✅" if cfg(k) == "1" else "❌"


def packs():
    return G["fetch_all"]("SELECT * FROM em_pack ORDER BY id")


def unmapped(limit=24):
    flush_now()
    mp = get_map()
    rows = G["fetch_all"]("SELECT key, n FROM em_seen ORDER BY n DESC LIMIT 200")
    return [r for r in rows if r["key"] not in mp and len(r["key"]) <= 5][:limit]


def v_main():
    mp = get_map()
    npk = G["fetch_one"]("SELECT COUNT(*) c FROM em_pack WHERE active=1")["c"]
    nman = G["fetch_one"]("SELECT COUNT(*) c FROM em_map")["c"]
    t = (f"🎭 <b>Bot emoji</b>\n\nHolat: <b>{'yoqilgan' if cfg('on') == '1' else 'o‘chiq'}</b>\n"
         f"Faol paketlar: <b>{npk}</b> · xaritadagi emoji: <b>{len(mp)}</b> (qo'lda: {nman})\n"
         f"Almashtirilgan: <b>{cfg('replaced')}</b> · rad etilgan (oddiy bilan yuborilgan): <b>{cfg('fails')}</b>\n"
         f"Tugma ikonlari: {onoff('btn')}" + ("" if HAS_BTN_ICON else " ⚠️ <i>aiogram eski: <code>pip install -U aiogram</code></i>") +
         "\n\nBotdagi oddiy emoji'lar avtomatik shu paketdagi custom emoji'ga almashadi. "
         "Paketda topilmagan emoji'larni «🔗 Qo'lda xaritalash» orqali bog'lang.\n"
         "<i>Shart: bot egasida (sizda) Telegram Premium bo'lishi kerak. Pastki doimiy menyu tugmalari o'zgarmaydi.</i>")
    rows = [
        [B(f"Bot emoji: {onoff('on')}", "em:sw:on"), B(f"Tugma ikonlari: {onoff('btn')}", "em:sw:btn")],
        [B("🎭 Paketlar", "em:pk"), B("🔗 Qo'lda xaritalash", "em:um")],
        [B("📋 Xaritalar", "em:ml"), B("🧪 Sinash", "em:test")],
        [B("⬅️ Admin panel", "admin_back")],
    ]
    return t, KB(rows)


def v_packs():
    t = ("🎭 <b>Emoji paketlari</b>\n\nPaket qo'shing: <code>https://t.me/addemoji/NOMI</code>\n"
         "Bir nechta paket mumkin; keyin qo'shilgani ustuvor. Oddiy emoji paketdagi <i>mos emoji</i>ga almashadi.")
    rows = []
    for p in packs():
        n = len(json.loads(p["data"] or "[]"))
        rows.append([B(f"{'✅' if p['active'] else '⏸'} {p['title'][:28]} ({n})", f"em:pk:{p['id']}")])
    rows.append([B("➕ Paket qo'shish", "em:pn")])
    rows.append([B("⬅️ Orqaga", "em:menu")])
    return t, KB(rows)


def v_pack(pid):
    p = G["fetch_one"]("SELECT * FROM em_pack WHERE id=?", (pid,))
    if not p:
        return v_packs()
    items = json.loads(p["data"] or "[]")
    prev = "".join(f'<tg-emoji emoji-id="{c}">{a}</tg-emoji>' for c, a in items[:20])
    t = (f"🎭 <b>{esc_(p['title'])}</b>\n<code>t.me/addemoji/{esc_(p['short_name'])}</code>\nEmoji: <b>{len(items)}</b>\n\n{prev}\n\n"
         f"Holat: {'✅ faol' if p['active'] else '⏸ o‘chiq'}")
    rows = [[B("👀 Barchasi", f"em:pv:{pid}:0:v:0")],
            [B("⏸ O'chirish" if p["active"] else "▶️ Yoqish", f"em:pa:{pid}"), B("🗑 O'chirish", f"em:pd:{pid}")],
            [B("⬅️ Paketlar", "em:pk")]]
    return t, KB(rows)


def v_grid(pid, page, mode, hk):
    p = G["fetch_one"]("SELECT * FROM em_pack WHERE id=?", (pid,))
    if not p:
        return v_packs()
    items = json.loads(p["data"] or "[]")
    per = 24
    pages = max(1, (len(items) + per - 1) // per)
    page = max(0, min(page, pages - 1))
    chunk = items[page * per:(page + 1) * per]
    if mode == "m":
        head = f"🔗 <b>{esc_(unhex(hk))}</b> uchun custom emoji tanlang (raqam bo'yicha):\n\n"
    else:
        head = f"🎭 <b>{esc_(p['title'])}</b>\n\n"
    head += " ".join(f'{page * per + i + 1}·<tg-emoji emoji-id="{c}">{a}</tg-emoji>' for i, (c, a) in enumerate(chunk))
    rows = []
    for i in range(0, len(chunk), 6):
        rows.append([B(str(page * per + i + j + 1), f"em:pc:{pid}:{page * per + i + j}:{hk}" if mode == "m" else "em:noop", icon=c)
                     for j, (c, a) in enumerate(chunk[i:i + 6])])
    if pages > 1:
        rows.append([B("◀️", f"em:pv:{pid}:{page - 1}:{mode}:{hk}"), B(f"{page + 1}/{pages}", "em:noop"), B("▶️", f"em:pv:{pid}:{page + 1}:{mode}:{hk}")])
    rows.append([B("⬅️ Orqaga", "em:um" if mode == "m" else f"em:pk:{pid}")])
    return head, KB(rows)


def v_unmapped():
    rows_db = unmapped()
    t = ("🔗 <b>Qo'lda xaritalash</b>\n\nBotda ishlatilgan, lekin paketda mos custom emoji topilmagan emoji'lar (ko'p ishlatilgani birinchi). "
         "Birini bosing va paketdan mos custom emoji tanlang.")
    if not rows_db:
        t += "\n\n✅ Hozircha xaritalanmagan emoji yo'q (yoki bot hali yetarlicha xabar yubormagan)."
    rows, row = [], []
    for r in rows_db:
        row.append(B(f"{r['key']} {r['n']}", f"em:ub:{hexkey(r['key'])}"))
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([B("⬅️ Orqaga", "em:menu")])
    return t, KB(rows)


def v_maps():
    man = G["fetch_all"]("SELECT * FROM em_map ORDER BY rowid DESC LIMIT 40")
    t = "📋 <b>Qo'lda xaritalar</b>\n" + ("\n".join(f'{m["key"]} → <tg-emoji emoji-id="{m["doc_id"]}">{m["alt"] or "⭐"}</tg-emoji>' for m in man) or "\nHali yo'q.")
    rows, row = [], []
    for m in man:
        row.append(B(f"🗑 {m['key']}", f"em:md:{hexkey(m['key'])}"))
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([B("⬅️ Orqaga", "em:menu")])
    return t, KB(rows)


async def show(call, view):
    await G["edit"](call, view[0], view[1])


async def cb_em(call: types.CallbackQuery, state: FSMContext):
    if not G["is_admin"](call.from_user.id):
        return await call.answer()
    await state.clear()
    p = call.data.split(":")
    a = p[1] if len(p) > 1 else "menu"
    arg = p[2] if len(p) > 2 else ""
    if a == "noop":
        return await call.answer()
    if a == "menu":
        await call.answer()
        return await show(call, v_main())
    if a == "sw" and arg in ("on", "btn"):
        cset(arg, "0" if cfg(arg) == "1" else "1")
        if arg == "on":
            cset("streak", 0)
        await call.answer("Saqlandi")
        return await show(call, v_main())
    if a == "pk" and not arg:
        await call.answer()
        return await show(call, v_packs())
    if a == "pk" and arg.isdigit():
        await call.answer()
        return await show(call, v_pack(int(arg)))
    if a == "pn":
        await call.answer()
        await state.set_state(EmStates.pk_link)
        return await call.message.answer("🎭 Emoji paketi havolasini yuboring:\n<code>https://t.me/addemoji/NOMI</code>\n\nBekor: /cancel")
    if a == "pa" and arg.isdigit():
        G["run"]("UPDATE em_pack SET active = 1 - active WHERE id=?", (int(arg),))
        CACHE["map"] = None
        await call.answer("Saqlandi")
        return await show(call, v_pack(int(arg)))
    if a == "pd" and arg.isdigit():
        await call.answer()
        return await show(call, ("🗑 Paket o'chirilsinmi?", KB([[B("✅ Ha", f"em:pdy:{arg}"), B("❌ Yo'q", f"em:pk:{arg}")]])))
    if a == "pdy" and arg.isdigit():
        G["run"]("DELETE FROM em_pack WHERE id=?", (int(arg),))
        CACHE["map"] = None
        await call.answer("O'chirildi")
        return await show(call, v_packs())
    if a == "pv" and len(p) > 5 and arg.isdigit() and p[3].lstrip("-").isdigit():
        await call.answer()
        return await show(call, v_grid(int(arg), int(p[3]), p[4], p[5]))
    if a == "um":
        await call.answer()
        return await show(call, v_unmapped())
    if a == "ub" and arg:
        ps = packs()
        if not ps:
            return await call.answer("Avval paket qo'shing", show_alert=True)
        await call.answer()
        if len(ps) == 1:
            return await show(call, v_grid(ps[0]["id"], 0, "m", arg))
        rows = [[B(f"🎭 {x['title'][:30]}", f"em:pv:{x['id']}:0:m:{arg}")] for x in ps] + [[B("⬅️ Orqaga", "em:um")]]
        return await show(call, (f"{esc_(unhex(arg))} uchun qaysi paketdan?", KB(rows)))
    if a == "pc" and len(p) > 4 and arg.isdigit() and p[3].isdigit():
        pk = G["fetch_one"]("SELECT data FROM em_pack WHERE id=?", (int(arg),))
        items = json.loads(pk["data"]) if pk else []
        if int(p[3]) >= len(items):
            return await call.answer()
        cid, alt = items[int(p[3])]
        G["run"]("INSERT INTO em_map (key, doc_id, alt) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET doc_id=excluded.doc_id, alt=excluded.alt",
                 (unhex(p[4]), cid, alt))
        CACHE["map"] = None
        await call.answer("✅ Bog'landi", show_alert=False)
        return await show(call, v_unmapped())
    if a == "ml":
        await call.answer()
        return await show(call, v_maps())
    if a == "md" and arg:
        G["run"]("DELETE FROM em_map WHERE key=?", (unhex(arg),))
        CACHE["map"] = None
        await call.answer("O'chirildi")
        return await show(call, v_maps())
    if a == "test":
        mp = get_map()
        if not mp:
            return await call.answer("Avval emoji paketi qo'shing", show_alert=True)
        sample = [k for k in ("😴", "✅", "📚", "🔔", "⭐", "💎", "🎓", "📊", "❤", "🔥") if k in mp][:8] or list(mp)[:8]
        before = int(cfg("replaced") or 0)
        fails = int(cfg("fails") or 0)
        msg = await G["bot"].send_message(call.message.chat.id, "🧪 Sinov: " + " ".join(sample),
                                          reply_markup=KB([[B(f"{sample[0]} Tugma", "em:noop")]]))
        ok = int(cfg("replaced") or 0) > before and int(cfg("fails") or 0) == fails
        return await call.answer("✅ Ishladi: yuqoridagi xabarda animatsion emoji ko'rinishi kerak." if ok else
                                 "⚠️ Telegram rad etdi — oddiy emoji yuborildi. Bot egasida Premium borligini tekshiring.", show_alert=True)
    await call.answer()


async def h_pk_link(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    m = re.search(r"(?:t\.me|telegram\.me)/addemoji/([A-Za-z0-9_]+)", message.text or "") or re.fullmatch(r"\s*([A-Za-z0-9_]{3,})\s*", message.text or "")
    if not m:
        return await message.answer("Havola noto'g'ri. Misol: <code>https://t.me/addemoji/NOMI</code>")
    try:
        ss = await G["bot"].get_sticker_set(m.group(1))
    except Exception as ex:
        return await message.answer(f"❌ Paket topilmadi: {esc_(str(ex)[:120])}")
    items = [[s.custom_emoji_id, s.emoji or "⭐"] for s in ss.stickers if getattr(s, "custom_emoji_id", None)]
    if not items:
        return await message.answer("❌ Bu custom emoji paketi emas. <code>/addemoji/</code> havolasini yuboring.")
    await state.clear()
    G["run"]("INSERT INTO em_pack (short_name, title, data, active) VALUES (?,?,?,1) ON CONFLICT(short_name) DO UPDATE SET title=excluded.title, data=excluded.data, active=1",
             (m.group(1), ss.title, json.dumps(items[:500])))
    CACHE["map"] = None
    pid = G["fetch_one"]("SELECT id FROM em_pack WHERE short_name=?", (m.group(1),))["id"]
    mp = get_map()
    await message.answer(f"✅ <b>{esc_(ss.title)}</b> qo'shildi: {len(items)} ta emoji. Endi botdagi mos emoji'lar avtomatik almashadi.")
    t, kb = v_pack(pid)
    await message.answer(t, reply_markup=kb)


async def cmd_emoji(message: types.Message, state: FSMContext):
    if not G["is_admin"](message.from_user.id):
        return
    await state.clear()
    t, kb = v_main()
    await message.answer(t, reply_markup=kb)


def setup(ns):
    missing = [k for k in NEEDED if k not in ns]
    if missing:
        raise RuntimeError("emojify.setup: hemis3.py da topilmadi: " + ", ".join(missing))
    G.update({k: ns[k] for k in NEEDED})
    dp = G["dp"]
    dp.message.register(cmd_emoji, Command("emoji"))
    dp.message.register(h_pk_link, StateFilter(EmStates.pk_link))
    dp.callback_query.register(cb_em, F.data.startswith("em:"))
    init_tables()
    G["bot"].session.middleware(EmojiMiddleware())
    logging.info("Bot emoji (custom emoji) yuklandi")


def start():
    spawn(flush_loop())
