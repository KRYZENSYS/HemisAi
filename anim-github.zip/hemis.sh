#!/data/data/com.termux/files/usr/bin/bash
# HEMIS bot + Web App: Termux + Cloudflare Tunnel (hisobsiz, bepul "quick tunnel")
# Ishlatish:   bash hemis.sh setup   (bir marta)     bash hemis.sh   (har safar)
cd "$(dirname "$0")" || exit 1
PORT="${WEB_PORT:-8080}"

set_env() {  # set_env KEY VALUE  -> .env ichida yangilaydi yoki qo'shadi
  touch .env
  grep -v "^$1=" .env > .env.tmp; echo "$1=$2" >> .env.tmp; mv .env.tmp .env
}

setup() {
  pkg update -y && pkg install -y python cloudflared fontconfig-utils
  if [ -f requirements.txt ]; then
    python -m pip install --upgrade -r requirements.txt || exit 1
  else
    python -m pip install --upgrade aiogram aiohttp cryptography reportlab telethon || exit 1
  fi
  if ! grep -q "^BOT_TOKEN=" .env 2>/dev/null; then
    read -r -p "BOT_TOKEN: " t; set_env BOT_TOKEN "$t"
    read -r -p "ADMIN_ID (Telegram ID raqamingiz): " a; set_env ADMIN_ID "$a"
  fi
  if ! grep -q "^ENCRYPTION_KEY=" .env; then
    set_env ENCRYPTION_KEY "$(python -c 'from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())')"
  fi
  set_env WEB_PORT "$PORT"
  echo "✅ Tayyor. Endi ishga tushiring: bash hemis.sh"
}

run() {
  command -v cloudflared >/dev/null || { echo "Avval: bash hemis.sh setup"; exit 1; }
  command -v termux-wake-lock >/dev/null && termux-wake-lock   # telefon uxlasa ham ishlashi uchun
  pkill -f "cloudflared tunnel" 2>/dev/null
  trap 'pkill -f "cloudflared tunnel"; exit 0' INT TERM EXIT

  while true; do
    : > tunnel.log
    # http2: mobil tarmoqlarda QUIC ba'zan bloklanadi, http2 barqarorroq
    cloudflared tunnel --no-autoupdate --protocol http2 --url "http://localhost:$PORT" > tunnel.log 2>&1 &
    CF=$!
    echo "⏳ Tunnel ochilmoqda..."
    URL=""
    for _ in $(seq 1 45); do
      URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' tunnel.log | head -1)
      [ -n "$URL" ] && break
      sleep 1
    done
    if [ -z "$URL" ]; then
      echo "❌ Tunnel URL olinmadi (internetni tekshiring). 10 soniyadan keyin qayta..."
      kill $CF 2>/dev/null; sleep 10; continue
    fi
    set_env WEB_APP_URL "$URL"
    echo "🌐 Web App manzili: $URL"
    # bot tunnel bilan birga ishlaydi; biri to'xtasa, ikkalasi qayta ishga tushadi
    python hemis3.py &
    BOT=$!
    while kill -0 $CF 2>/dev/null && kill -0 $BOT 2>/dev/null; do sleep 5; done
    echo "⚠️ Jarayon to'xtadi, qayta ishga tushirilmoqda..."
    kill $CF $BOT 2>/dev/null; sleep 5
  done
}

case "${1:-run}" in
  setup) setup ;;
  *) run ;;
esac
