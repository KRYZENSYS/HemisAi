# -*- coding: utf-8 -*-
"""plus_core.py - Plus moduli uchun sof (toza) mantiq: aiogram/DB'siz, shuning uchun testlanadi."""
import datetime as dt
import hashlib
import math
import re
import secrets

# ---------------------------------------------------------------- SM-2 (takrorlash kartalari)
QUALITY = {"again": 1, "hard": 3, "good": 4, "easy": 5}


def sm2(ease: float, interval: int, reps: int, quality: int):
    """SuperMemo-2. (yangi_ease, yangi_interval_kun, yangi_reps) qaytaradi."""
    quality = max(0, min(5, int(quality)))
    if quality < 3:
        return max(1.3, ease - 0.2), 1, 0
    ease = max(1.3, ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)))
    reps += 1
    if reps == 1:
        interval = 1
    elif reps == 2:
        interval = 6
    else:
        interval = max(1, round(interval * ease))
    if quality == 3:
        interval = max(1, round(interval * 0.8))
    return round(ease, 2), interval, reps


def parse_cards(text: str, limit: int = 100):
    """Har qatorda «savol | javob» (yoki « - », «::», tab). [(savol, javob)]"""
    out = []
    for line in (text or "").splitlines():
        line = re.sub(r"^\s*(?:\d+[.)]|[•*-])\s+", "", line).strip()
        if not line:
            continue
        for sep in ("|", "::", "\t", " - ", " — ", " – "):
            if sep in line:
                a, b = line.split(sep, 1)
                a, b = a.strip(), b.strip()
                if a and b:
                    out.append((a[:400], b[:800]))
                break
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------- XP / daraja / nishonlar
def level_of(xp: int) -> int:
    return int(math.sqrt(max(0, xp) / 25)) + 1


def xp_for_level(level: int) -> int:
    return 25 * (max(1, level) - 1) ** 2


def level_bar(xp: int, width: int = 10) -> str:
    lv = level_of(xp)
    lo, hi = xp_for_level(lv), xp_for_level(lv + 1)
    frac = (xp - lo) / max(1, hi - lo)
    n = max(0, min(width, int(frac * width)))
    return "▰" * n + "▱" * (width - n)


BADGES = [
    ("🔥", "3 kunlik streak", lambda s: s["streak"] >= 3),
    ("🔥🔥", "7 kunlik streak", lambda s: s["best_streak"] >= 7),
    ("🌋", "30 kunlik streak", lambda s: s["best_streak"] >= 30),
    ("🍅", "10 ta pomodoro", lambda s: s["pomodoros"] >= 10),
    ("🍅🍅", "50 ta pomodoro", lambda s: s["pomodoros"] >= 50),
    ("🃏", "50 ta karta takrorlandi", lambda s: s["cards_done"] >= 50),
    ("🧠", "200 ta karta takrorlandi", lambda s: s["cards_done"] >= 200),
    ("⭐", "100 XP", lambda s: s["xp"] >= 100),
    ("🌟", "500 XP", lambda s: s["xp"] >= 500),
    ("👑", "1500 XP", lambda s: s["xp"] >= 1500),
]


def badges_of(stats: dict):
    return [(e, n) for e, n, f in BADGES if f(stats)]


def next_streak(last_day, today, streak: int):
    """(yangi_streak, yangi_kunmi). last_day/today: 'YYYY-MM-DD' yoki None."""
    if last_day == today:
        return streak, False
    try:
        gap = (dt.date.fromisoformat(today) - dt.date.fromisoformat(last_day)).days if last_day else None
    except ValueError:
        gap = None
    return (streak + 1 if gap == 1 else 1), True


# ---------------------------------------------------------------- Ball / GPA kalkulyatori
GRADE_MIN = {5: 86, 4: 71, 3: 55}  # 100 ballik tizim (O'zbekiston OTM)


def need_points(have: float, done_max: float, target_grade: int = 5, total_max: float = 100.0):
    """Maqsad bahoga yetish uchun qolgan ballardan nechasini olish kerak.
    qaytaradi dict: status = ok|already|impossible, need, remaining, percent, target."""
    if target_grade not in GRADE_MIN:
        raise ValueError("baho 3, 4 yoki 5 bo'lishi kerak")
    if have < 0 or done_max < 0 or total_max <= 0 or have > done_max or done_max > total_max:
        raise ValueError("ballar noto'g'ri")
    target = GRADE_MIN[target_grade] * total_max / 100.0
    remaining = total_max - done_max
    need = target - have
    res = {"target": target, "remaining": remaining, "need": max(0.0, round(need, 2))}
    if need <= 0:
        res.update(status="already", percent=0.0)
    elif need > remaining + 1e-9:
        res.update(status="impossible", percent=None)
    else:
        res.update(status="ok", percent=round(need / remaining * 100, 1) if remaining else None)
    return res


def parse_gpa(text: str):
    """«5x4 4x3 5*2» yoki «5 (4 kredit)» -> [(baho, kredit)]. Xato bo'lsa ValueError."""
    pairs = []
    for tok in re.split(r"[,\n;]+|\s+", (text or "").strip()):
        if not tok:
            continue
        m = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*[xX*×:/]\s*(\d+(?:[.,]\d+)?)", tok)
        if not m:
            raise ValueError(f"«{tok}» tushunarsiz (to'g'ri: 5x4)")
        g, c = float(m.group(1).replace(",", ".")), float(m.group(2).replace(",", "."))
        if not (0 <= g <= 5) or c <= 0 or c > 30:
            raise ValueError(f"«{tok}»: baho 0–5, kredit 0–30 oralig'ida bo'lsin")
        pairs.append((g, c))
    if not pairs:
        raise ValueError("bo'sh")
    return pairs


def gpa_of(pairs) -> float:
    cr = sum(c for _, c in pairs)
    return round(sum(g * c for g, c in pairs) / cr, 2)


def gpa_needed(pairs, new_credits: float, target: float):
    """Yangi semestrda (new_credits kredit) o'rtacha qancha baho kerak ekan: umumiy GPA = target bo'lishi uchun."""
    cr = sum(c for _, c in pairs)
    cur = sum(g * c for g, c in pairs)
    return round((target * (cr + new_credits) - cur) / new_credits, 2)


# ---------------------------------------------------------------- Sana, reja, ICS
def parse_any_date(s: str, today=None):
    s = (s or "").strip()
    today = today or dt.date.today()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    m = re.fullmatch(r"(\d{1,2})[./-](\d{1,2})", s)
    if m:
        try:
            d = dt.date(today.year, int(m.group(2)), int(m.group(1)))
            return d if d >= today else d.replace(year=today.year + 1)
        except ValueError:
            return None
    return None


def study_plan(today: dt.date, exam: dt.date, topics, review_day: bool = True):
    """Mavzularni bugundan imtihongacha teng taqsimlaydi; oxirgi kun - umumiy takrorlash.
    [(sana, [mavzu,...])] qaytaradi. Imtihon o'tib ketgan bo'lsa ValueError."""
    topics = [t.strip() for t in topics if t and t.strip()]
    days = (exam - today).days
    if days < 1:
        raise ValueError("Imtihon sanasi bugundan keyin bo'lishi kerak")
    if not topics:
        raise ValueError("Mavzular ro'yxati bo'sh")
    study_days = days - 1 if (review_day and days >= 3) else days
    study_days = max(1, study_days)
    plan = {}
    n = len(topics)
    for i, t in enumerate(topics):
        day = today + dt.timedelta(days=min(study_days - 1, i * study_days // n))
        plan.setdefault(day, []).append(t)
    out = sorted(plan.items())
    if review_day and days >= 3:
        out.append((exam - dt.timedelta(days=1), ["♻️ Umumiy takrorlash va tez-tez xato qilgan joylar"]))
    return out


def _ics_esc(s: str) -> str:
    return (s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r", "").replace("\n", "\\n")


def _fold(line: str) -> str:
    raw = line.encode("utf-8")
    if len(raw) <= 74:
        return line
    out, cur = [], b""
    for ch in line:
        b = ch.encode("utf-8")
        if len(cur) + len(b) > 74:
            out.append(cur.decode("utf-8"))
            cur = b" " + b
        else:
            cur += b
    out.append(cur.decode("utf-8"))
    return "\r\n".join(out)


def build_ics(events, prodid: str = "-//HEMIS Student Hub//UZ//", stamp=None) -> str:
    """events: [{'title','date': date, 'time': 'HH:MM' | None, 'minutes': int, 'desc', 'uid'}]"""
    stamp = stamp or dt.datetime.utcnow()
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", f"PRODID:{prodid}", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
             "X-WR-TIMEZONE:Asia/Tashkent"]
    for i, ev in enumerate(events):
        d = ev["date"]
        uid = ev.get("uid") or hashlib.sha1(f"{ev['title']}{d}{ev.get('time')}{i}".encode()).hexdigest()[:20]
        lines += ["BEGIN:VEVENT", f"UID:{uid}@hemis-hub", f"DTSTAMP:{stamp:%Y%m%dT%H%M%SZ}"]
        t = ev.get("time")
        if t and re.fullmatch(r"\d{1,2}:\d{2}", t):
            hh, mm = map(int, t.split(":"))
            start = dt.datetime.combine(d, dt.time(hh, mm))
            end = start + dt.timedelta(minutes=int(ev.get("minutes") or 60))
            lines += [f"DTSTART;TZID=Asia/Tashkent:{start:%Y%m%dT%H%M%S}", f"DTEND;TZID=Asia/Tashkent:{end:%Y%m%dT%H%M%S}"]
        else:
            lines += [f"DTSTART;VALUE=DATE:{d:%Y%m%d}", f"DTEND;VALUE=DATE:{d + dt.timedelta(days=1):%Y%m%d}"]
        lines.append(f"SUMMARY:{_ics_esc(ev['title'])}")
        if ev.get("desc"):
            lines.append(f"DESCRIPTION:{_ics_esc(ev['desc'])}")
        lines += ["BEGIN:VALARM", "TRIGGER:-PT30M", "ACTION:DISPLAY", f"DESCRIPTION:{_ics_esc(ev['title'])}", "END:VALARM", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    return "\r\n".join(_fold(l) for l in lines) + "\r\n"


# ---------------------------------------------------------------- Promokod, API kalit
def norm_code(s: str) -> str:
    return re.sub(r"[^A-Z0-9_-]", "", (s or "").upper())[:24]


def promo_check(row, used_by_user: bool, today: dt.date):
    """None - yaroqli, aks holda xato matni."""
    if not row or not row["active"]:
        return "Bunday promokod topilmadi."
    if row["expires"]:
        try:
            if dt.date.fromisoformat(row["expires"]) < today:
                return "Promokod muddati tugagan."
        except ValueError:
            pass
    if row["max_uses"] and row["used"] >= row["max_uses"]:
        return "Promokod limiti tugagan."
    if used_by_user:
        return "Siz bu promokoddan foydalanib bo'lgansiz."
    return None


def new_api_key() -> str:
    return "hk_" + secrets.token_urlsafe(24)


def hash_key(key: str) -> str:
    return hashlib.sha256((key or "").encode()).hexdigest()


# ---------------------------------------------------------------- Duel, so'rovnoma
def duel_result(s1: int, s2: int) -> str:
    return "draw" if s1 == s2 else ("p1" if s1 > s2 else "p2")


def parse_poll(text: str):
    """«Savol | variant1 | variant2 ...» -> (savol, [variantlar]). Xato: ValueError"""
    parts = [p.strip() for p in (text or "").split("|") if p.strip()]
    if len(parts) < 3:
        raise ValueError("Format: Savol | variant 1 | variant 2 (kamida 2 ta variant)")
    if len(parts) > 9:
        raise ValueError("Eng ko'pi 8 ta variant")
    return parts[0][:200], [p[:60] for p in parts[1:]]


def bar(n: int, total: int, width: int = 10) -> str:
    k = 0 if total <= 0 else round(n / total * width)
    return "█" * k + "░" * (width - k)


# ---------------------------------------------------------------- Zaxira nusxalarini aylantirish
def backups_to_delete(names, keep: int):
    """names: 'hemis_YYYYmmdd.db' ro'yxati; eng yangi `keep` tasi qoladi."""
    good = sorted(n for n in names if re.fullmatch(r"hemis_\d{8}\.db", n))
    return good[:-keep] if keep > 0 and len(good) > keep else ([] if keep > 0 else good)


def mask_secret(v: str) -> str:
    v = v or ""
    return "•" * min(8, len(v)) + (v[-2:] if len(v) > 6 else "")
