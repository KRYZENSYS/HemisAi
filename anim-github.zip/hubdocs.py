# -*- coding: utf-8 -*-
"""hubdocs.py - qo'shimcha kutubxonasiz .docx va .pptx yaratuvchi (faqat standart kutubxona).

Termux'da python-docx / python-pptx (lxml) o'rnatish qiyin, shuning uchun fayllar
OOXML (zip + XML) sifatida to'g'ridan-to'g'ri yoziladi.
"""
import base64
import io
import json
import re
import zipfile
import zlib
from xml.sax.saxutils import escape as _esc

_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")


def xesc(s) -> str:
    return _esc(_BAD.sub("", str(s)), {'"': "&quot;"})


# ======================================================================
# DOCX
# ======================================================================
NS_W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ' \
       'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
FONT = "Times New Roman"


def _runs(text, bold=False, italic=False, size=None, caps=False):
    """'**qalin**' belgilarini qo'llab, <w:r> ketma-ketligini qaytaradi. '\n' -> qator uzilishi."""
    out = []
    parts = re.split(r"(\*\*.+?\*\*)", str(text))
    for part in parts:
        if not part:
            continue
        b = bold
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            part, b = part[2:-2], True
        part = part.replace("*", "") if "**" in part else part
        pr = f'<w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}" w:cs="{FONT}"/>'
        if b:
            pr += "<w:b/>"
        if italic:
            pr += "<w:i/>"
        if caps:
            pr += "<w:caps/>"
        if size:
            pr += f'<w:sz w:val="{int(size * 2)}"/><w:szCs w:val="{int(size * 2)}"/>'
        lines = part.split("\n")
        for i, ln in enumerate(lines):
            if i:
                out.append(f"<w:r><w:rPr>{pr}</w:rPr><w:br/></w:r>")
            if ln:
                out.append(f'<w:r><w:rPr>{pr}</w:rPr><w:t xml:space="preserve">{xesc(ln)}</w:t></w:r>')
    return "".join(out)


class Docx:
    def __init__(self, page_numbers=True, title_page=False):
        self.body = []
        self.page_numbers = page_numbers
        self.title_page = title_page

    # --- past darajadagi blok ---
    def para(self, text="", style=None, jc=None, bold=False, italic=False, size=None, caps=False,
             first=False, before=0, after=0, line=None, page_break=False, keep_next=False, left=None, outline=None):
        ppr = ""
        if style:
            ppr += f'<w:pStyle w:val="{style}"/>'
        if keep_next:
            ppr += "<w:keepNext/>"
        if page_break:
            ppr += "<w:pageBreakBefore/>"
        sp = f'<w:spacing w:before="{int(before)}" w:after="{int(after)}"'
        if line:
            sp += f' w:line="{int(line)}" w:lineRule="auto"'
        ppr += sp + "/>"
        ind = ""
        if first:
            ind += ' w:firstLine="709"'
        if left:
            ind += f' w:left="{int(left)}"'
        if ind:
            ppr += f"<w:ind{ind}/>"
        if jc:
            ppr += f'<w:jc w:val="{jc}"/>'
        if outline is not None:
            ppr += f'<w:outlineLvl w:val="{outline}"/>'
        self.body.append(f"<w:p><w:pPr>{ppr}</w:pPr>{_runs(text, bold, italic, size, caps)}</w:p>")

    def blank(self, n=1, size=14):
        for _ in range(n):
            self.para("", size=size)

    # --- yuqori daraja ---
    def body_text(self, text):
        for chunk in re.split(r"\n\s*\n|\n", str(text).strip()):
            chunk = chunk.strip()
            if chunk:
                self.para(chunk, style="BodyText")

    def heading(self, text, level=1, page_break=False):
        self.para(text, style=f"Heading{level}", page_break=page_break, keep_next=True)

    def bullet(self, text):
        self.para("– " + text, style="BodyText", first=False, left=709)

    def toc(self, entries):
        """Haqiqiy Word mundarija maydoni (kesh bilan). Raqamlarni Word'da yangilash mumkin."""
        self.para("MUNDARIJA", jc="center", bold=True, size=14, after=240, line=360, page_break=True)
        if not entries:
            return
        n = len(entries)
        for i, (lvl, txt) in enumerate(entries):
            runs = ""
            if i == 0:
                runs += ('<w:r><w:fldChar w:fldCharType="begin"/></w:r>'
                         '<w:r><w:instrText xml:space="preserve"> TOC \\o "1-2" \\h \\z \\u </w:instrText></w:r>'
                         '<w:r><w:fldChar w:fldCharType="separate"/></w:r>')
            runs += _runs(txt, size=14)
            if i == n - 1:
                runs += '<w:r><w:fldChar w:fldCharType="end"/></w:r>'
            ind = 0 if lvl == 1 else 454
            self.body.append(
                f'<w:p><w:pPr><w:spacing w:before="0" w:after="60" w:line="360" w:lineRule="auto"/>'
                f'<w:ind w:left="{ind}"/></w:pPr>{runs}</w:p>')

    # --- paketlash ---
    def _styles(self):
        f = f'<w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}" w:cs="{FONT}" w:eastAsia="{FONT}"/>'
        return (
            f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {NS_W}>'
            f'<w:docDefaults><w:rPrDefault><w:rPr>{f}<w:sz w:val="28"/><w:szCs w:val="28"/>'
            '<w:lang w:val="uz-Latn-UZ" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>'
            '<w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
            '<w:style w:type="paragraph" w:styleId="BodyText"><w:name w:val="Body Text"/><w:basedOn w:val="Normal"/><w:qFormat/>'
            '<w:pPr><w:spacing w:before="0" w:after="0" w:line="360" w:lineRule="auto"/><w:ind w:firstLine="709"/><w:jc w:val="both"/></w:pPr></w:style>'
            '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
            '<w:pPr><w:keepNext/><w:spacing w:before="240" w:after="240" w:line="360" w:lineRule="auto"/><w:jc w:val="center"/><w:outlineLvl w:val="0"/></w:pPr>'
            f'<w:rPr>{f}<w:b/><w:caps/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr></w:style>'
            '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
            '<w:pPr><w:keepNext/><w:spacing w:before="200" w:after="120" w:line="360" w:lineRule="auto"/><w:outlineLvl w:val="1"/></w:pPr>'
            f'<w:rPr>{f}<w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr></w:style>'
            '</w:styles>'
        )

    def _footer(self, number=True):
        inner = ""
        if number:
            rp = f'<w:rPr><w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}"/><w:sz w:val="24"/></w:rPr>'
            inner = (f'<w:r>{rp}<w:fldChar w:fldCharType="begin"/></w:r>'
                     f'<w:r>{rp}<w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>'
                     f'<w:r>{rp}<w:fldChar w:fldCharType="separate"/></w:r>'
                     f'<w:r>{rp}<w:t>1</w:t></w:r>'
                     f'<w:r>{rp}<w:fldChar w:fldCharType="end"/></w:r>')
        return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr {NS_W}>'
                f'<w:p><w:pPr><w:jc w:val="center"/></w:pPr>{inner}</w:p></w:ftr>')

    def to_bytes(self) -> bytes:
        sect = ""
        rels = ('<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>')
        ctypes = ('<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
                  '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>')
        files = {}
        if self.page_numbers:
            rels += ('<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>'
                     '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer2.xml"/>')
            ctypes += ('<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
                       '<Override PartName="/word/footer2.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>')
            files["word/footer1.xml"] = self._footer(True)
            files["word/footer2.xml"] = self._footer(False)
            sect += '<w:footerReference w:type="default" r:id="rId2"/>'
            if self.title_page:
                sect += '<w:footerReference w:type="first" r:id="rId3"/>'
        sect += ('<w:pgSz w:w="11906" w:h="16838"/>'
                 '<w:pgMar w:top="1134" w:right="850" w:bottom="1134" w:left="1701" w:header="709" w:footer="709" w:gutter="0"/>')
        if self.title_page and self.page_numbers:
            sect += "<w:titlePg/>"
        doc = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {NS_W}><w:body>'
               + "".join(self.body) + f"<w:sectPr>{sect}</w:sectPr></w:body></w:document>")
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                       '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                       '<Default Extension="xml" ContentType="application/xml"/>' + ctypes + "</Types>")
            z.writestr("_rels/.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                       "</Relationships>")
            z.writestr("word/_rels/document.xml.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rels}</Relationships>')
            z.writestr("word/document.xml", doc)
            z.writestr("word/styles.xml", self._styles())
            for k, v in files.items():
                z.writestr(k, v)
        return buf.getvalue()


def md_blocks(doc: "Docx", text: str):
    """Oddiy belgilash: '# ' sarlavha, '- ' ro'yxat, qolgani abzats."""
    for raw in str(text).splitlines():
        ln = raw.strip()
        if not ln:
            continue
        if ln.startswith("## "):
            doc.heading(ln[3:].strip(), 2)
        elif ln.startswith("# "):
            doc.heading(ln[2:].strip(), 2)
        elif ln[:2] in ("- ", "* ", "• "):
            doc.bullet(ln[2:].strip())
        else:
            doc.para(ln, style="BodyText")


def title_page(doc: "Docx", university, faculty, kind_title, topic, author_line, year):
    doc.para((university or "").upper(), jc="center", bold=True, size=14, line=360)
    if faculty:
        doc.para(faculty, jc="center", size=14, line=360)
    doc.blank(6)
    doc.para(kind_title.upper(), jc="center", bold=True, size=20, after=240)
    doc.para("Mavzu:", jc="center", size=14, after=120)
    doc.para(f"«{topic}»", jc="center", bold=True, size=16, after=0, line=360)
    doc.blank(8)
    doc.para(author_line, jc="right", size=14, line=360)
    doc.para("Qabul qildi: ____________________", jc="right", size=14, line=360, before=120)
    doc.blank(5)
    doc.para(str(year), jc="center", size=14)


# ======================================================================
# PPTX
# ======================================================================
_BASE = json.loads(zlib.decompress(base64.b64decode("eNrtHGlzozj2r1DZj7tuQByG1GymYifu6Z2kO5VkZmuqUrUlQDZ0xLFCpJOZmv++krgEhrTjOL2djPMBg/QO6Z3SQ+SPgyyjKg1RjMqr/u4+xgeHysEPP7Ib5Q6RPEqTf94c6O+0mwMFJX4aRMmKNfxyvZg4rCmnMAkgThPEGh9QfnPw49ENuUl+gIeCosLoJPkhZL0hpdmhquY+a4f5uzRDCetcpiSGlD2SlRoQ+IWRj7EKNM1WYxgljEUCY07803IZ+Ui55lRvDo5qBqeYXRKa8wYfkytfcO3glNDBrc5/8od8jolyBzHrZ9yC9Ms1uqeMD4Y5ZV2sWRN/Nwfq0Q9qg4jpGH4HdyH+atwKKbgFApesvBZZX5ju9KTlAkouA5Cnp6fzU72lKUCg77N56+vQ5sLRZw1dCay8HaA/1yzN7GFIPIx1DHc2m1luF8NoMcx1DEezzWPQxTBbDGtgHrPj+dzuYlgthr2OsZi6ttnDEGAhjpLbdXiu5VZXDdAyxT8NIzgMwWkMo4VTJdsrKSR03BJj+DklCwYiFA5plCj0IUNL6HPIOcSRRyLBBB4iKPdVjX4+0Mh5KrlPooyyxn9lkPuODFYslyDgV8NQxI92UxiaZ4rrlF99g1/hcpDiTzBZ9Sl6bqDfFP7U1BhF1sgoepZujeHnfXzLc7ybwlxaxhgK7aPYlse4TAM+etvW0E3hwsAcRD8m0OuiX0cxypWP6ItymcZcQENMkUeejnUdwqiLdZyscphAjjeIcUrDHsbHB4jhIOwM9WX/K2GhZxj4ffG5N4GrkBQ0GgT+OYx7wOdpimcpGZnnz4JrRzpFshobCCm6sJcQ3g2PY75mHadFxhwoGiY9D1Fv2BeYGQtcoQRRhfemtwgNov4WRT25n0c+SfN0SZXfImUGoxFRXUceHUP8KYqZ7h7gmG30ZHb+qzJL8TCbE3TXh2aeB/EwaYR7In4PCwrjkRnAGHehzyANhwd99UD8nkJyyqxihXCqnAYoz4fxPpGH3vB/ZgFtzETO8UPchyY0uh2GPoNp2oU+SW/nIYyzkTlESdiF/5DfMvOGykVKRwaU9j2NtzBdweQR0/g1QvTpMeOXaBWOGRTvK8iwW6G0798PeAlRUuelTn6Jo2SfbP4vyeaYRCNeu55ixmHXE8s8JUH0+vLKCSySC8Qdcp9W9mlln1a2SivjceLFkkmbP1R5YyNIxY/scpYRxlf0AaOzXOSenM02WLBG8SDQ2o1VFrL7mmUHckWguFdISv8d0fAqhBlnpZdcVnlFfpUrWZrzTV3ZMcJB1A0iJoGy1Wo2+gwD0vM0qDqMTgmgISaeVnmHoWEJyM2ZGtPnM9Ur0M256tYYV+txrqokZeZyChQFIN0G1RCYMUGMglInJZFaaS+vQF2TNRjCAA12yPPVjReUsvXk4exO/Nq6+NV1P8RJ90n5wus5FmALKcWHGXtYsmUif4gzTjUXkQviFa8D+rSa8ibe3JeBO2aBumaNiqDDKCM5PYF5WOGJvqYslkjzAZYpZLPbCanPGJHh6N/HiNS+CaDlEvl0pKV9rPrSgiJyFQZfFA8X5BLy8ZuVJQZRznMKaB55QdQya0PtBYDar9ZKcrXHQZyFsPYSR7aQEkXcN+MRT9JQ1ZF5bD8t4wWmZe2nVa8PfLbINgKx5WSrCQIVbsmMWEpomLKQloWRvyAp36VxIDY+hXlROTQFi9cUYtzoTo6FJa0yeK5CehmtFBLxCEpDgtAFbWa+EVkddFJ0TbKKW80E8qz89dAdwtfC/20uE0YnbKNTJR4B21erOuSX3mrxGhZV5rapTmJoPjXxmtZw4nXd5w9mw2WAzBaMyQBY1sbpPmPbKIVfeFqIiI+lpfV1esmsQ5HWHAo32olTu6/U4fE5OPJ0OdFvvFJztG+26pUVYYwqQtNeUhHWiB6sr6hBXXdzVdppiae1F5+p95mN4YRt4QpctuQZeypvLoiYvJcGD9UtzsuwUgqlThw4uURLJQruW5X3ZVy9TGyXE5clEy6HFtnYCLnCaVNWSwBsRKDBqne1LQGxaR0mgqURlDil/puw20gOJ88SIXiOCLXnilB/QRHS+6+IsJKcOmSY6J4SOK9fljL7VluTPjr4hyKOJOQsV6FzmLPFQi4/7PB8QnaY46CkuoMzCiUFshGFVBRJTlK/4P5bkiGIl+bTJA+jLG/oZRvRywjKGSGB3x3WEZulf4UD/uutyqtkIpo2YiXeqlJwhVDdcQJ5ds2WTfwuuXtPsivmGoLLx7sLwuiWlleXgwQR0VmBqiWiuFF7JFb1LTy8X5JYhLXlUqm8QXloFnXChhS/7vDlHj/8NILjh6cjWGrNUJUGwWdaDnZgiqCd4nVEMVIuMPRRmOKAGZPezrqeT56dpf5triQpm29bJ5FgSqnw3ywUxTjuZpx0DVl2q/KA8hFpmdYUaPX0wdS0DacvNwcA19YaOei6aUhZqSbI19/vURrXC3HCXLla6981jlsDicHl1dDo/YyFyjZkck/lFMKU/M5X1R8Sns1d3TRFuiwfxbh5xuz2er1eiucprrQIE5+RlDfNLGjFxwVNl1E1vnIAayE7E2t9cWHDw2VRBSWTX6540IjpHCOYSOZDj+Y48m8VmiooiKhSRQ6hI0VEPhHFBEtBFiXBBSTwco16JTYhr1pOam1ujxidIRkdV6Rsc2BXNselxfg0OeR5xqczGwOa9hXrMy1gubbx6qzvyeaWcVu4w5JV7cAAuVSF/eUdA1Rrnl3G+jaMr5CfJoGC+WZ2EyZgGybXYUSewMPYhsciLQhbyG/MxNyKSbQc5PECIcFsQ8IJpN00ZOwqJAS8RJL/zv0H4mUTHMBzg4NtWLwm0g8OQDcMKTgYtqUD67Vnps6WQdzfYZ3bWVXzxdURVbTkxiGErYNmo/tYjUesxXs77elG1XS15lcu2csBlffSQIVHLHFQGtwf1mx+fKI51uTUObYnjmNak9mJeTqZz8z5/Fiz3MXc/LN6n8hth1kljWK0iFYFQZ+Kusa2oSvpKpiqutG60RIHL+JIVutIizTlcVV2JXNXrrTktlCq978FJFQcNmj2zE92J0MH5tf9yXGtv5w/NcvB79Wjdm7BdmvBV3y/rHwsYq9nx9au7JjtnBn5MVM2tzBl27KMfWoYMmXyWlLDXF8s7JNjd6JpzmLizExn4gKWJGa2xdb7jjl1ZgspNYiqTsKt6CkZ4aYAmuH+TfzAneQFVa5pMFMTFVdxpxQk4hObzVwbzJ3ZZKabi4l54k4nxwvbmiwswzTnM+d4bpz+KYotunnoEyQKMR+Cuoajm+tVnLg+mvPOT+OqIKRm6RdEsjQSNSFdq0tLVbUaaK47nVq6W3sXG2H9W1aJ21qPj8k5zBRvpdcFT4UZA8/Ht/zeWwHRDkQ7EO38vioOymXCqg00bS2c0bQZTZvZtJlNm9W0WU2b3bTxuCU+vOBC4r/suf6ugmfM6raKXCzwnMGHtKAfgkpPUktVm9HNqekYtulyvzsUbeRD0AS2dRL0Xph0Lu75fv7RrKIwz7iG3tXv8nqW+Xfl3AieJTNyW9XBxHnbukG8/WNmGSWriyLxqVSlzfxZXWr2L/zaWaVXhHW/V3xMk3JLKUcEszztcItI8sT4MPBycO2Q8N/jzxNMB88I8y4EB08K8y4/bz5vGoonXXlnIu6uCT+G5IxHexO4YpJRwuKGeNXVNLWr6G+oHdB5fSRpiB+WGzuz5xXzEBLFZxdxwBhooN4ty/qscuGL6TMZ12cyrs/kK/oUt0DS2ZQpyOrqDDjW1HrtOtONAZ0B53XpDLQ6MySdNbVgWWnAsd+mowHzdSnNaJVmykqrC61vTWnDnqa9LqWZrdIsSWlAs6bm21OapnneG1Ca1SrNlpVm6ab91wmPr0xpdqu0qaw0d6o7e6V9p0qbtkpz1hb8e6V9n0pzWqW5stIcxwZ7pX2nSnPrbbe00c4OUxoi0my7GcZFqdpqpkOVtBaot0t/eTV3CqHOm9gmN6LZS+6Jm1VRbt9LbpsdozHV7b3ottm36Q5wnL3otto9iaXAXnTb7GGmprHPEtvtJNjA92liu/W8bU33aWLDVbW8kFbl94qq9LHB8DcO/yEIr3/p8I637uZzh0v5A4Py1fRmHxdA/xau0OBXCkcdqsqH9lWrcl2+5N/BxxClUMpXtpwwJCvEDefdO7mnAyZkJ3Q1OD6w2/HR8h9SdkbW/5eapeF0dNC1g7FZ7PBbl5Lqm/3WpTnBzvar/BCBgCR3zfeL5emI+ozUrITaf9Gy/kXL2kli/YVPEuvaVw6MqUOns9ThM/Zv/qiq8ehRVfANjqrq+g719ZJn4kcPQhrf5iCkDl7EsPcH7V7yoJ0OdOC6rqM7Gx+0+3RHyn/ryxduc9GUsbRZ2U8LIp8+G07/0jJQWgTsl4FZZ208tAwc+1h4cOX15/8Ai0Idpg==")).decode())
RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_P = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        f'xmlns:r="{RT}" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')
W, H = 12192000, 6858000
THEMES = {
    "blue": ("1F3A5F", "2E75B6", "F4F7FB", "1F2937"),
    "green": ("14532D", "2F9E5B", "F3FAF5", "1F2937"),
    "dark": ("111827", "7C3AED", "F5F3FF", "1F2937"),
}


def _sp(idn, name, x, y, cx, cy, paras, fill=None, anchor="t", insets=(91440, 45720)):
    f = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else "<a:noFill/>"
    body = "".join(paras) or "<a:p><a:endParaRPr lang=\"en-US\"/></a:p>"
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{idn}" name="{name}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>{f}</p:spPr>'
            f'<p:txBody><a:bodyPr wrap="square" lIns="{insets[0]}" rIns="{insets[0]}" tIns="{insets[1]}" bIns="{insets[1]}" anchor="{anchor}"><a:normAutofit/></a:bodyPr>'
            f'<a:lstStyle/>{body}</p:txBody></p:sp>')


def _p(text, sz, color, bold=False, algn="l", bullet=False, after=600):
    ppr = f'<a:pPr algn="{algn}"'
    if bullet:
        ppr += ' marL="342900" indent="-342900"'
    ppr += f'><a:spcAft><a:spcPts val="{after}"/></a:spcAft>'
    ppr += '<a:buFont typeface="Arial"/><a:buChar char="&#8226;"/>' if bullet else "<a:buNone/>"
    ppr += "</a:pPr>"
    b = ' b="1"' if bold else ""
    return (f'<a:p>{ppr}<a:r><a:rPr lang="en-US" sz="{int(sz * 100)}"{b} dirty="0">'
            f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            f'<a:latin typeface="Calibri"/></a:rPr><a:t>{xesc(text)}</a:t></a:r></a:p>')


def _slide(shapes, bg):
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld {NS_P}><p:cSld>'
            f'<p:bg><p:bgPr><a:solidFill><a:srgbClr val="{bg}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
            '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
            '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
            + "".join(shapes) + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')


def build_pptx(title, subtitle, slides, theme="blue", closing="E'tiboringiz uchun rahmat!") -> bytes:
    dark, accent, light, text = THEMES.get(theme, THEMES["blue"])
    xml_slides = []
    # 1) titul
    xml_slides.append(_slide([
        _sp(2, "Accent", 0, H - 260000, W, 260000, [], fill=accent),
        _sp(3, "Title", 900000, 1700000, W - 1800000, 2200000, [_p(title, 40, "FFFFFF", True, "ctr", after=0)], anchor="ctr"),
        _sp(4, "Subtitle", 900000, 4100000, W - 1800000, 1400000, [_p(l, 20, "D1D5DB", False, "ctr", after=200) for l in str(subtitle).split("\n") if l.strip()], anchor="t"),
    ], dark))
    # 2) mazmun
    for i, s in enumerate(slides, 1):
        bullets = [b for b in (s.get("bullets") or []) if str(b).strip()][:6]
        n = max(1, len(bullets))
        sz = 24 if n <= 4 else 22 if n == 5 else 20
        xml_slides.append(_slide([
            _sp(2, "Band", 0, 0, W, 1250000, [_p(s.get("title", ""), 30, "FFFFFF", True, "l", after=0)], fill=dark, anchor="ctr", insets=(600000, 45720)),
            _sp(3, "Accent", 0, 1250000, W, 70000, [], fill=accent),
            _sp(4, "Body", 600000, 1600000, W - 1200000, H - 2300000, [_p(b, sz, text, False, "l", True, 900) for b in bullets], anchor="t"),
            _sp(5, "Num", W - 1400000, H - 600000, 900000, 400000, [_p(str(i + 1), 14, accent, True, "r", after=0)], anchor="ctr"),
        ], light))
    # 3) yakun
    xml_slides.append(_slide([
        _sp(2, "Accent", 0, H - 260000, W, 260000, [], fill=accent),
        _sp(3, "Thanks", 900000, 2400000, W - 1800000, 1800000, [_p(closing, 40, "FFFFFF", True, "ctr", after=0)], anchor="ctr"),
    ], dark))

    n = len(xml_slides)
    pres_rels = [f'<Relationship Id="rId1" Type="{RT}/slideMaster" Target="slideMasters/slideMaster1.xml"/>',
                 f'<Relationship Id="rId2" Type="{RT}/theme" Target="theme/theme1.xml"/>']
    sld_ids = []
    for i in range(n):
        pres_rels.append(f'<Relationship Id="rId{i + 3}" Type="{RT}/slide" Target="slides/slide{i + 1}.xml"/>')
        sld_ids.append(f'<p:sldId id="{256 + i}" r:id="rId{i + 3}"/>')
    presentation = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation {NS_P}>'
                    '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
                    f'<p:sldIdLst>{"".join(sld_ids)}</p:sldIdLst>'
                    f'<p:sldSz cx="{W}" cy="{H}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
          '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
          '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
          '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
          + "".join(f'<Override PartName="/ppt/slides/slide{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' for i in range(n))
          + "</Types>")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   f'<Relationship Id="rId1" Type="{RT}/officeDocument" Target="ppt/presentation.xml"/></Relationships>')
        z.writestr("ppt/presentation.xml", presentation)
        z.writestr("ppt/_rels/presentation.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(pres_rels) + "</Relationships>")
        for path, content in _BASE.items():
            z.writestr(path, content)
        for i, x in enumerate(xml_slides, 1):
            z.writestr(f"ppt/slides/slide{i}.xml", x)
            z.writestr(f"ppt/slides/_rels/slide{i}.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       f'<Relationship Id="rId1" Type="{RT}/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>')
    return buf.getvalue()
