"""Safe, dependency-free parser for Telegram Desktop JSON exports."""
from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any


def _text_value(value: Any) -> str:
    """Flatten Telegram Desktop's string-or-entity-array text representation."""
    if isinstance(value, str):
        return value
    if not isinstance(value, list):
        return ""
    chunks: list[str] = []
    for part in value:
        if isinstance(part, str):
            chunks.append(part)
        elif isinstance(part, dict) and isinstance(part.get("text"), str):
            chunks.append(part["text"])
    return "".join(chunks)


def _timestamp(message: dict[str, Any]) -> float | None:
    raw = message.get("date_unixtime")
    try:
        if raw is not None:
            return float(raw)
        date_text = message.get("date")
        if date_text:
            return datetime.fromisoformat(str(date_text).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError, OverflowError, OSError):
        pass
    return None


def parse_telegram_export(
    data: bytes,
    *,
    max_bytes: int = 10 * 1024 * 1024,
    max_messages: int = 10_000,
) -> list[tuple[str, str, str, str, str, float | None, float]]:
    """Parse a Telegram Desktop result.json export into safe text rows.

    Each row matches bz_archive columns (except the auto-generated id):
    title, chat_id, message_id, sender, text, timestamp, imported_at.
    Non-message/service events and media-only messages are skipped.
    """
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("JSON arxiv bayt ko'rinishida bo'lishi kerak")
    if len(data) > max_bytes:
        raise ValueError(f"Arxiv hajmi {max_bytes} baytdan oshdi")
    if max_messages < 1:
        raise ValueError("max_messages kamida 1 bo'lishi kerak")
    try:
        raw = json.loads(bytes(data).decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Telegram JSON arxivi o'qilmadi") from exc
    if not isinstance(raw, dict):
        raise ValueError("JSON ildizida obyekt bo'lishi kerak")
    chats_node = raw.get("chats")
    chats = chats_node.get("list") if isinstance(chats_node, dict) else None
    if not isinstance(chats, list):
        raise ValueError("Telegram eksportida chats.list topilmadi")

    imported_at = time.time()
    rows: list[tuple[str, str, str, str, str, float | None, float]] = []
    for chat in chats:
        if not isinstance(chat, dict):
            continue
        title = str(chat.get("name") or chat.get("title") or "Nomsiz suhbat")[:250]
        chat_id = str(chat.get("id") or "")[:100]
        messages = chat.get("messages")
        if not isinstance(messages, list):
            continue
        for msg in messages:
            if not isinstance(msg, dict) or msg.get("type") not in (None, "message"):
                continue
            text = _text_value(msg.get("text")).strip()
            if not text:
                continue
            sender = str(msg.get("from") or msg.get("actor") or "")[:250]
            rows.append((title, chat_id, str(msg.get("id") or "")[:100], sender,
                         text[:3500], _timestamp(msg), imported_at))
            if len(rows) >= max_messages:
                return rows
    return rows
