# -*- coding: utf-8 -*-
"""
sleepmode.py - "Uyqu rejimi": Telethon (userbot) orqali SHAXSIY Telegram akkauntingiz uxlayotganda
avtomatik javob beradi. Oddiy emoji o'rniga https://t.me/addemoji/... paketlaridagi CUSTOM EMOJI ishlatiladi.
Hammasi Admin Panel -> «😴 Uyqu rejimi» ichidagi inline tugmalar orqali boshqariladi.

Ulash: hemis3.py da  `import sleepmode; sleepmode.setup(globals())`  va main() da  `sleepmode.start()`  (patch_sleep.py qiladi).
Kerak:  pip install telethon
"""
import asyncio
import collections
import datetime as dt
import json
import logging
import random
import re
import time
from contextlib import closing

from aiogram import F, types
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

try:
    from telethon import TelegramClient, events
    from telethon.errors import (FloodWaitError, PasswordHashInvalidError, PhoneCodeExpiredError,
                                 PhoneCodeInvalidError, PhoneNumberInvalidError, SessionPasswordNeededError)
    from telethon.sessions import StringSession
    from telethon.tl.types import MessageEntityCustomEmoji
    HAS_TELETHON = True
except ImportError:  # modul baribir yuklanadi, panel o'rnatish yo'riqnomasini ko'rsatadi
    HAS_TELETHON = False

NEEDED = ["dp", "bot", "ADMIN_ID", "is_admin", "esc", "now", "fetch_one", "fetch_all", "run", "insert",
          "safe_send", "interrupted", "edit", "enc", "dec", "db"]
G = {}

D = {
    "enabled": "1", "api_id": "", "api_hash": "", "session": "",
    "force": "0", "sleep_until": "0", "awake_until": "0",
    "sched_on": "1", "sched_start": "23:00", "sched_end": "07:00", "sched_days": "1234567",
    "contacts": "all", "cooldown": "0", "typing": "1", "automap": "1", "rate": "20",
    "status_on": "0", "status_doc": "", "status_alt": "😴",
    "bio_on": "0", "bio_text": "😴 Uxlayapman · uyg'onish: {wake}", "old_bio": "",
    "report": "1", "vip_notify": "1", "urgent_on": "1", "urgent": "shoshilinch,zarur,urgent,срочно,важно",
    "session_id": "0",
}
DEFAULT_TPL = "😴 Salom, {name}! Hozir uxlayapman. Uyg'onish vaqti: {wake}. Uyg'onishim bilan albatta javob yozaman. 🙏"
STATE = {"sleeping": None, "wake": None}
LOGIN = {}
CLIENT = None
ME = None
TASKS = set()
RATE = collections.deque()
LOCKS = set()
TOKEN_RE = re.compile(r"⟪(\d+)\|([^⟫]*)⟫")


class SlStates(StatesGroup):
    api_id = State()
    api_hash = State()
    phone = State()
    password = State()
    tpl_text = State()
    pk_link = State()
    vip_add = State()
    urgent = State()
    bio_text = State()


# ======================================================================
# Sozlama va baza
# ======================================================================
def init_tables():
    with closing(G["db"]()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS sl_cfg (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS sl_tpl (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS sl_pack (id INTEGER PRIMARY KEY AUTOINCREMENT, short_name TEXT UNIQUE, title TEXT,
                                            data TEXT, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS sl_vip (user_id INTEGER PRIMARY KEY, name TEXT, kind TEXT DEFAULT 'vip');
        CREATE TABLE IF NOT EXISTS sl_log (id INTEGER PRIMARY KEY AUTOINCREMENT, session TEXT, user_id INTEGER, name TEXT,
                                           text TEXT, ts REAL, replied INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS sl_replied (user_id INTEGER, session TEXT, ts REAL, PRIMARY KEY (user_id, session, ts));
        """)
        conn.commit()
    if not G["fetch_one"]("SELECT 1 FROM sl_tpl LIMIT 1"):
        G["insert"]("INSERT INTO sl_tpl (text, active) VALUES (?, 1)", (DEFAULT_TPL,))


def cfg(k):
    r = G["fetch_one"]("SELECT value FROM sl_cfg WHERE key=?", (k,))
    return r["value"] if r and r["value"] is not None else D.get(k, "")


def cset(k, v):
    G["run"]("INSERT INTO sl_cfg (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


def cflt(k):
    try:
        return float(cfg(k))
    except ValueError:
        return 0.0


def flip(k):
    cset(k, "0" if cfg(k) == "1" else "1")


def esc_(s):
    return G["esc"](str(s))


# ======================================================================
# Vaqt va holat
# ======================================================================
def hm(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def fmt_hm(mins):
    mins %= 1440
    return f"{mins // 60:02d}:{mins % 60:02d}"


def in_window(n):
    if cfg("sched_on") != "1":
        return False
    s, e = hm(cfg("sched_start")), hm(cfg("sched_end"))
    if s == e:
        return False
    ds = set(cfg("sched_days"))
    cur, wd, yd = n.hour * 60 + n.minute, str(n.isoweekday()), str((n - dt.timedelta(days=1)).isoweekday())
    if s < e:
        return wd in ds and s <= cur < e
    return (cur >= s and wd in ds) or (cur < e and yd in ds)


def next_end(n):
    e = hm(cfg("sched_end"))
    d = n.replace(hour=e // 60, minute=e % 60, second=0, microsecond=0)
    return d if d > n else d + dt.timedelta(days=1)


def sleep_state(n=None):
    """(uxlayaptimi, uyg'onish vaqti|None, sabab)"""
    n = n or G["now"]()
    if cfg("enabled") != "1":
        return False, None, "o'chiq"
    t = n.timestamp()
    if cfg("force") == "1":
        return True, None, "qo'lda"
    if cflt("sleep_until") > t:
        return True, dt.datetime.fromtimestamp(cflt("sleep_until"), n.tzinfo), "taymer"
    if cflt("awake_until") > t:
        return False, None, "uyg'ongan"
    if in_window(n):
        return True, next_end(n), "jadval"
    return False, None, ""


def wake_str(w):
    if not w:
        return "tez orada"
    n = G["now"]()
    return f"{w:%H:%M}" if (w - n) < dt.timedelta(hours=20) else f"{w:%d.%m %H:%M}"


def notify_admin(text, kb=None):
    return G["safe_send"](G["ADMIN_ID"], text, kb) if kb else G["safe_send"](G["ADMIN_ID"], text)


def spawn(coro):
    t = asyncio.create_task(coro)
    TASKS.add(t)
    t.add_done_callback(TASKS.discard)


# ======================================================================
# Custom emoji: shablon -> (matn, entity'lar)
# ======================================================================
def len16(s):
    return len(s.encode("utf-16-le")) // 2


def msg_to_tpl(message: types.Message) -> str:
    """Admin yuborgan xabardagi custom emoji'larni ⟪id|alt⟫ belgilariga aylantiradi."""
    text = message.text or ""
    ents = sorted([e for e in (message.entities or []) if e.type == "custom_emoji"], key=lambda x: x.offset)
    if not ents:
        return text
    b, out, pos = text.encode("utf-16-le"), [], 0
    for e in ents:
        out.append(b[pos * 2:e.offset * 2].decode("utf-16-le"))
        out.append(f"⟪{e.custom_emoji_id}|{b[e.offset * 2:(e.offset + e.length) * 2].decode('utf-16-le')}⟫")
        pos = e.offset + e.length
    out.append(b[pos * 2:].decode("utf-16-le"))
    return "".join(out)


def plain(tpl):
    return TOKEN_RE.sub(lambda m: m.group(2) or "⭐", tpl)


def emoji_map():
    """oddiy emoji -> custom emoji id (faol paketlardan, birinchi topilgani)."""
    mp = {}
    for p in G["fetch_all"]("SELECT data FROM sl_pack WHERE active=1 ORDER BY id"):
        try:
            for cid, alt in json.loads(p["data"]):
                mp.setdefault(alt.replace("\ufe0f", ""), int(cid))
        except ValueError:
            continue
    return mp


def render(tpl, variables, use_entities=True, automap=True):
    """Shablonni yakuniy matn va Telethon entity'lariga aylantiradi (UTF-16 offsetlar bilan)."""
    for k, v in variables.items():
        tpl = tpl.replace("{" + k + "}", str(v))
    mp = emoji_map() if (automap and use_entities) else {}
    out, ents, off, pos = [], [], 0, 0

    def add_plain(seg):
        nonlocal off
        i = 0
        while i < len(seg):
            c = seg[i]
            j = i + 1
            if j < len(seg) and seg[j] == "\ufe0f":
                j += 1
            piece = seg[i:j]
            cid = mp.get(c) if mp else None
            if cid and ord(c) > 0x2000:
                ents.append(MessageEntityCustomEmoji(offset=off, length=len16(piece), document_id=cid))
            out.append(piece)
            off += len16(piece)
            i = j

    for m in TOKEN_RE.finditer(tpl):
        add_plain(tpl[pos:m.start()])
        alt = m.group(2) or "⭐"
        if use_entities:
            ents.append(MessageEntityCustomEmoji(offset=off, length=len16(alt), document_id=int(m.group(1))))
        out.append(alt)
        off += len16(alt)
        pos = m.end()
    add_plain(tpl[pos:])
    return "".join(out), ents


def variables_for(name):
    n = G["now"]()
    w = STATE.get("wake") or sleep_state(n)[1]
    return {"name": name or "do'stim", "wake": wake_str(w), "date": f"{n:%d.%m.%Y}", "time": f"{n:%H:%M}"}


# ======================================================================
# Telethon: ulanish, javob berish, status
# ======================================================================
async def connect_saved():
    global CLIENT, ME
    if not HAS_TELETHON or not (cfg("api_id") and cfg("api_hash") and cfg("session")):
        return False
    sess = G["dec"](cfg("session"))
    if not sess:
        logging.error("Uyqu rejimi: sessiyani ochib bo'lmadi (ENCRYPTION_KEY o'zgargan bo'lishi mumkin).")
        return False
    if CLIENT:
        try:
            await CLIENT.disconnect()
        except Exception:
            pass
    c = TelegramClient(StringSession(sess), int(cfg("api_id")), cfg("api_hash"), device_model="HEMIS Sleep", app_version="1.0")
    await c.connect()
    if not await c.is_user_authorized():
        await c.disconnect()
        return False
    c.add_event_handler(on_msg, events.NewMessage(incoming=True))
    CLIENT, ME = c, await c.get_me()
    logging.info("Uyqu rejimi: akkaunt ulandi (%s)", ME.first_name)
    return True


def is_premium_acc():
    return bool(ME and getattr(ME, "premium", False))


def vip_kind(uid):
    r = G["fetch_one"]("SELECT kind FROM sl_vip WHERE user_id=?", (uid,))
    return r["kind"] if r else None


def pick_template():
    rows = G["fetch_all"]("SELECT text FROM sl_tpl WHERE active=1")
    return random.choice(rows)["text"] if rows else DEFAULT_TPL


async def on_msg(event):
    try:
        await handle_msg(event)
    except Exception:
        logging.exception("Uyqu rejimi: xabarni qayta ishlashda xato")


async def handle_msg(event):
    if not event.is_private or event.out:
        return
    sleeping, wake, _ = sleep_state()
    if not sleeping:
        return
    sender = await event.get_sender()
    if (not sender or getattr(sender, "bot", False) or getattr(sender, "is_self", False)
            or getattr(sender, "deleted", False) or sender.id in (777000, 42777)):
        return
    uid = sender.id
    name = " ".join(x for x in (getattr(sender, "first_name", ""), getattr(sender, "last_name", "")) if x) or str(uid)
    kind = vip_kind(uid)
    if kind == "ignore":
        return
    text = (event.raw_text or "")[:300] or ("📎 media" if event.media else "")
    sid = cfg("session_id")
    log_id = G["insert"]("INSERT INTO sl_log (session, user_id, name, text, ts, replied) VALUES (?,?,?,?,?,0)",
                         (sid, uid, name, text, time.time()))
    if kind == "vip":
        if cfg("vip_notify") == "1":
            await notify_admin(f"⭐ <b>VIP</b> yozdi: {esc_(name)}\n{esc_(text[:200])}")
        return
    if cfg("urgent_on") == "1":
        words = [w.strip().lower() for w in cfg("urgent").split(",") if w.strip()]
        if any(w in text.lower() for w in words):
            await notify_admin(f"🚨 <b>Shoshilinch?</b> {esc_(name)} (<code>{uid}</code>):\n{esc_(text[:300])}")
    mode, contact = cfg("contacts"), bool(getattr(sender, "contact", False))
    if (mode == "noncontacts" and contact) or (mode == "contacts" and not contact):
        return
    cd = cflt("cooldown")
    last = G["fetch_one"]("SELECT MAX(ts) t FROM sl_replied WHERE user_id=? AND session=?", (uid, sid))
    if last and last["t"] and (cd <= 0 or time.time() - last["t"] < cd * 60):
        return
    t = time.time()
    while RATE and t - RATE[0] > 60:
        RATE.popleft()
    if len(RATE) >= max(1, int(cflt("rate"))) or uid in LOCKS:
        return
    RATE.append(t)
    LOCKS.add(uid)
    try:
        await send_away(sender, name, wake)
        G["run"]("INSERT OR IGNORE INTO sl_replied (user_id, session, ts) VALUES (?,?,?)", (uid, sid, time.time()))
        G["run"]("UPDATE sl_log SET replied=1 WHERE id=?", (log_id,))
    finally:
        LOCKS.discard(uid)


async def send_away(peer, name, wake=None, tpl=None, automap=None):
    """Javob yuboradi. Premium bo'lmasa yoki xato bo'lsa - oddiy emoji bilan."""
    use = is_premium_acc()
    text, ents = render(tpl or pick_template(), variables_for(name), use, cfg("automap") == "1" if automap is None else automap)
    if cfg("typing") == "1" and peer != "me":
        try:
            async with CLIENT.action(peer, "typing"):
                await asyncio.sleep(random.uniform(1.5, 4.0))
        except Exception:
            pass
    try:
        await CLIENT.send_message(peer, text, formatting_entities=ents or None)
    except Exception as ex:
        if not ents:
            raise
        logging.warning("Custom emoji bilan yuborilmadi (%s), oddiy matn yuboriladi", ex)
        await CLIENT.send_message(peer, text)


async def apply_status(on):
    """Uxlaganda emoji-status va bio'ni o'zgartiradi, uyg'onganda tiklaydi. Xato matnini qaytaradi."""
    if not CLIENT:
        return None
    err = []
    try:
        from telethon.tl.functions.account import UpdateEmojiStatusRequest, UpdateProfileRequest
        from telethon.tl.functions.users import GetFullUserRequest
        from telethon.tl.types import EmojiStatus, EmojiStatusEmpty
    except ImportError:
        return "Telethon versiyasi eski (pip install -U telethon)"
    if cfg("status_on") == "1" and cfg("status_doc"):
        try:
            if not is_premium_acc():
                err.append("emoji-status uchun akkauntda Telegram Premium kerak")
            elif on:
                await CLIENT(UpdateEmojiStatusRequest(EmojiStatus(document_id=int(cfg("status_doc")))))
            else:
                await CLIENT(UpdateEmojiStatusRequest(EmojiStatusEmpty()))
        except Exception as ex:
            err.append(f"emoji-status: {ex}")
    if cfg("bio_on") == "1":
        try:
            if on:
                full = await CLIENT(GetFullUserRequest("me"))
                if cfg("old_bio") == "":
                    cset("old_bio", "\u200b" + (full.full_user.about or ""))
                lim = 140 if is_premium_acc() else 70
                bio = cfg("bio_text").replace("{wake}", wake_str(STATE.get("wake")))
                await CLIENT(UpdateProfileRequest(about=plain(bio)[:lim]))
            else:
                old = cfg("old_bio")
                if old:
                    await CLIENT(UpdateProfileRequest(about=old.lstrip("\u200b")))
                    cset("old_bio", "")
        except Exception as ex:
            err.append(f"bio: {ex}")
    return "; ".join(err) or None


def build_report(sid):
    rows = G["fetch_all"]("SELECT user_id, name, COUNT(*) c, MAX(ts) t, SUM(replied) r FROM sl_log WHERE session=? GROUP BY user_id ORDER BY t DESC", (sid,))
    if not rows:
        return "📭 Siz uxlaganda hech kim yozmadi."
    lines = [f"📬 <b>Uyqu vaqtida yozganlar: {len(rows)} kishi</b>\n"]
    for r in rows[:20]:
        last = G["fetch_one"]("SELECT text FROM sl_log WHERE session=? AND user_id=? ORDER BY ts DESC LIMIT 1", (sid, r["user_id"]))
        who = esc_(r["name"])
        lines.append(f"• <b>{who}</b> — {r['c']} ta{' ↩️' if r['r'] else ''}\n   <i>{esc_((last['text'] if last else '')[:80])}</i>")
    if len(rows) > 20:
        lines.append(f"… va yana {len(rows) - 20} kishi")
    return "\n".join(lines)


async def transition(sleeping, wake, reason):
    if sleeping:
        cset("session_id", str(int(time.time())))
        err = await apply_status(True)
        await notify_admin(f"😴 <b>Uyqu rejimi yoqildi</b> ({reason})\n⏰ Uyg'onish: <b>{wake_str(wake)}</b>"
                           + (f"\n⚠️ {esc_(err)}" if err else "")
                           + ("" if CLIENT else "\n⚠️ Akkaunt ulanmagan — avto-javob ishlamaydi!"))
    else:
        err = await apply_status(False)
        sid = cfg("session_id")
        txt = "⏰ <b>Uyg'ondingiz!</b>"
        if cfg("report") == "1":
            txt += "\n\n" + build_report(sid)
        if err:
            txt += f"\n⚠️ {esc_(err)}"
        await notify_admin(txt[:4000])
        G["run"]("DELETE FROM sl_log WHERE ts < ?", (time.time() - 7 * 86400,))


async def sleep_loop():
    await asyncio.sleep(5)
    first = True
    while True:
        try:
            if HAS_TELETHON and CLIENT is None and cfg("session"):
                await connect_saved()
            sleeping, wake, reason = sleep_state()
            STATE["wake"] = wake
            if first:
                first = False
                STATE["sleeping"] = sleeping
                if sleeping and cfg("session_id") == "0":
                    cset("session_id", str(int(time.time())))
            elif sleeping != STATE["sleeping"]:
                STATE["sleeping"] = sleeping
                await transition(sleeping, wake, reason)
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("Uyqu rejimi tsikli xatosi")
        await asyncio.sleep(15)


async def force_transition():
    """Tugma bosilganda holat darrov yangilansin."""
    sleeping, wake, reason = sleep_state()
    STATE["wake"] = wake
    if sleeping != STATE["sleeping"]:
        STATE["sleeping"] = sleeping
        await transition(sleeping, wake, reason)


# ======================================================================
# Panel (inline tugmalar)
# ======================================================================
def B(text, data=None, url=None):
    return InlineKeyboardButton(text=text, url=url) if url else InlineKeyboardButton(text=text, callback_data=data)


def KB(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def onoff(k):
    return "✅" if cfg(k) == "1" else "❌"


def today_stats():
    t0 = G["now"]().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    r = G["fetch_one"]("SELECT COUNT(*) c, COALESCE(SUM(replied),0) r, COUNT(DISTINCT user_id) u FROM sl_log WHERE ts>=?", (t0,))
    return r["c"], r["r"], r["u"]


def acc_line():
    if not HAS_TELETHON:
        return "⚠️ Telethon o'rnatilmagan (<code>pip install telethon</code>)"
    if CLIENT and ME:
        nm = esc_(" ".join(x for x in (ME.first_name, ME.last_name) if x) or "akkaunt")
        un = f" @{ME.username}" if ME.username else ""
        return f"✅ {nm}{un} · {'⭐ Premium' if is_premium_acc() else 'Premium emas'}"
    return "❌ Ulanmagan" + (" (saqlangan sessiya bor, ulanmoqda…)" if cfg("session") else "")


def sched_line():
    if cfg("sched_on") != "1":
        return "o'chiq"
    names = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"]
    ds = set(cfg("sched_days"))
    d = "har kuni" if len(ds) == 7 else ", ".join(names[int(x) - 1] for x in sorted(ds)) or "kun tanlanmagan"
    return f"{cfg('sched_start')}–{cfg('sched_end')} · {d}"


def v_main():
    sl, wake, reason = sleep_state()
    if cfg("enabled") != "1":
        hol = "⛔ Funksiya o'chirilgan"
    elif sl:
        hol = f"😴 <b>Uxlayapman</b> ({reason}) — uyg'onish: <b>{wake_str(wake)}</b>"
    else:
        hol = "🟢 <b>Uyg'oqman</b>" + (f" ({reason})" if reason else "")
    c, r, u = today_stats()
    ntpl = G["fetch_one"]("SELECT COUNT(*) c FROM sl_tpl WHERE active=1")["c"]
    npk = G["fetch_one"]("SELECT COUNT(*) c FROM sl_pack WHERE active=1")["c"]
    t = (f"😴 <b>Uyqu rejimi</b>\n\n{hol}\n👤 Akkaunt: {acc_line()}\n🕒 Jadval: {sched_line()}\n"
         f"💬 Faol shablonlar: <b>{ntpl}</b> · 🎭 Emoji paketlar: <b>{npk}</b>\n📊 Bugun: yozganlar <b>{u}</b>, javoblar <b>{r}</b>")
    sleeping = sl
    rows = [
        [B("⏰ Uyg'onish" if sleeping else "😴 Uxlashga yotish", "sl:tog")],
        [B("1 soat", "sl:for:1"), B("2 soat", "sl:for:2"), B("4 soat", "sl:for:4"), B("8 soat", "sl:for:8")],
        [B("🕒 Jadval", "sl:sch"), B("💬 Xabarlar", "sl:tpl")],
        [B("🎭 Emoji paketlar", "sl:pk"), B("🌙 Status/Bio", "sl:st")],
        [B("👥 Filtrlar / VIP", "sl:fl"), B("📊 Hisobot", "sl:rp")],
        [B("⚙️ Sozlamalar", "sl:set"), B("🔐 Akkaunt", "sl:acc")],
        [B("⬅️ Admin panel", "admin_back")],
    ]
    return t, KB(rows)


def v_sched():
    t = (f"🕒 <b>Jadval</b>\n\nJadval: <b>{'yoqilgan' if cfg('sched_on') == '1' else 'o‘chiq'}</b>\n"
         f"🌙 Uxlash: <b>{cfg('sched_start')}</b>   ☀️ Uyg'onish: <b>{cfg('sched_end')}</b>\n"
         f"Kunlar: <b>{sched_line().split(' · ')[-1] if cfg('sched_on') == '1' else '—'}</b>\n\n"
         "<i>Kunlar — uxlash boshlanadigan kun. Vaqt Toshkent bo'yicha.</i>")
    ds = set(cfg("sched_days"))
    names = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"]

    def adj(which):
        return [B(x, f"sl:t:{which}:{v}") for x, v in (("−1s", -60), ("−15m", -15), ("+15m", 15), ("+1s", 60))]
    rows = [
        [B(f"Jadval: {onoff('sched_on')}", "sl:sw:sched_on")],
        [B(f"🌙 Boshlanish: {cfg('sched_start')}", "sl:noop")], adj("s"),
        [B(f"☀️ Tugash: {cfg('sched_end')}", "sl:noop")], adj("e"),
        [B(("✅" if str(i + 1) in ds else "▫️") + n, f"sl:d:{i + 1}") for i, n in enumerate(names)],
        [B("22–06", "sl:p:2200:0600"), B("23–07", "sl:p:2300:0700"), B("00–08", "sl:p:0000:0800")],
        [B("⬅️ Orqaga", "sl:menu")],
    ]
    return t, KB(rows)


def v_tpl_list():
    rows_db = G["fetch_all"]("SELECT * FROM sl_tpl ORDER BY id")
    t = ("💬 <b>Avto-javob shablonlari</b>\n\nUxlaganda yozganlarga tasodifiy faol shablon yuboriladi.\n"
         "O'zgaruvchilar: <code>{name}</code> ism, <code>{wake}</code> uyg'onish vaqti, <code>{date}</code>, <code>{time}</code>")
    rows = [[B(f"{'✅' if r['active'] else '⏸'} #{r['id']} {plain(r['text'])[:32]}", f"sl:tv:{r['id']}")] for r in rows_db]
    rows.append([B("➕ Yangi shablon", "sl:tn")])
    rows.append([B("⬅️ Orqaga", "sl:menu")])
    return t, KB(rows)


def v_tpl(tid):
    r = G["fetch_one"]("SELECT * FROM sl_tpl WHERE id=?", (tid,))
    if not r:
        return v_tpl_list()
    n = len(TOKEN_RE.findall(r["text"]))
    t = (f"💬 <b>Shablon #{tid}</b> {'✅ faol' if r['active'] else '⏸ o‘chiq'}\n\n{esc_(plain(r['text']))}\n\n"
         f"🎭 Custom emoji: <b>{n}</b> ta"
         + ("\n<i>Avto-almashtirish yoqilgan: oddiy emoji faol paketdagi custom emoji'ga almashtiriladi.</i>" if cfg("automap") == "1" else ""))
    rows = [
        [B("👁 Ko'rish (Saved Messages)", f"sl:tp:{tid}")],
        [B("✏️ Matnni almashtirish", f"sl:te:{tid}"), B("➕ Emoji qo'shish", f"sl:tx:{tid}")],
        [B("⏸ O'chirish" if r["active"] else "▶️ Yoqish", f"sl:tt:{tid}"), B("🗑 O'chirish", f"sl:td:{tid}")],
        [B("⬅️ Shablonlar", "sl:tpl")],
    ]
    return t, KB(rows)


def packs():
    return G["fetch_all"]("SELECT * FROM sl_pack ORDER BY id")


def v_packs():
    ps = packs()
    t = ("🎭 <b>Custom emoji paketlari</b>\n\nPaketni <code>https://t.me/addemoji/NOMI</code> havolasi bilan qo'shing. "
         "Faol paketlardagi emoji'lar shablonlardagi oddiy emoji o'rniga avtomatik ishlatiladi.\n"
         "<i>Custom emoji yuborish uchun akkauntda Telegram Premium kerak.</i>")
    rows = []
    for p in ps:
        n = len(json.loads(p["data"] or "[]"))
        rows.append([B(f"{'✅' if p['active'] else '⏸'} {p['title'][:28]} ({n})", f"sl:pk:{p['id']}")])
    rows.append([B("➕ Paket qo'shish", "sl:pn")])
    rows.append([B("⬅️ Orqaga", "sl:menu")])
    return t, KB(rows)


def v_pack(pid):
    p = G["fetch_one"]("SELECT * FROM sl_pack WHERE id=?", (pid,))
    if not p:
        return v_packs()
    items = json.loads(p["data"] or "[]")
    sample = " ".join(a for _, a in items[:12])
    t = (f"🎭 <b>{esc_(p['title'])}</b>\n<code>t.me/addemoji/{esc_(p['short_name'])}</code>\nEmoji soni: <b>{len(items)}</b>\n"
         f"Ko'rinishi (oddiy belgilar): {esc_(sample)}\n\nHolat: {'✅ faol' if p['active'] else '⏸ o‘chiq'}")
    rows = [
        [B("👀 Barcha emoji", f"sl:pv:{pid}:0:v:0"), B("🌙 Status uchun tanlash", f"sl:pv:{pid}:0:s:0")],
        [B("⏸ O'chirish" if p["active"] else "▶️ Yoqish", f"sl:pa:{pid}"), B("🗑 Paketni o'chirish", f"sl:pd:{pid}")],
        [B("⬅️ Paketlar", "sl:pk")],
    ]
    return t, KB(rows)


def v_grid(pid, page, mode, tid):
    p = G["fetch_one"]("SELECT * FROM sl_pack WHERE id=?", (pid,))
    if not p:
        return v_packs()
    items = json.loads(p["data"] or "[]")
    per = 40
    pages = max(1, (len(items) + per - 1) // per)
    page = max(0, min(page, pages - 1))
    chunk = items[page * per:(page + 1) * per]
    if mode == "t":
        r = G["fetch_one"]("SELECT text FROM sl_tpl WHERE id=?", (tid,))
        head = f"➕ <b>Shablon #{tid}ga emoji qo'shish</b>\nHozirgi matn: {esc_(plain(r['text'])) if r else '—'}\n\nEmoji'ni bosing — matn oxiriga qo'shiladi."
    elif mode == "s":
        head = "🌙 <b>Status emoji</b> — bittasini tanlang (uxlaganda profilingizda ko'rinadi)."
    else:
        head = f"🎭 <b>{esc_(p['title'])}</b> — barcha emoji"
    rows = []
    for i in range(0, len(chunk), 8):
        rows.append([B(a or "⭐", f"sl:pc:{pid}:{page * per + i + j}:{mode}:{tid}" if mode != "v" else "sl:noop")
                     for j, (_, a) in enumerate(chunk[i:i + 8])])
    if pages > 1:
        rows.append([B("◀️", f"sl:pv:{pid}:{page - 1}:{mode}:{tid}"), B(f"{page + 1}/{pages}", "sl:noop"),
                     B("▶️", f"sl:pv:{pid}:{page + 1}:{mode}:{tid}")])
    back = f"sl:tv:{tid}" if mode == "t" else ("sl:st" if mode == "s" else f"sl:pk:{pid}")
    rows.append([B("⬅️ Orqaga", back)])
    return head, KB(rows)


def v_tx(tid):
    ps = packs()
    rows = [[B(f"🎭 {p['title'][:30]}", f"sl:pv:{p['id']}:0:t:{tid}")] for p in ps]
    rows.append([B("➕ Paket qo'shish", "sl:pn")])
    rows.append([B("⬅️ Orqaga", f"sl:tv:{tid}")])
    t = "Qaysi paketdan emoji qo'shamiz?" if ps else "Avval emoji paketi qo'shing (<code>t.me/addemoji/…</code> havolasi)."
    return t, KB(rows)


CONTACT_MODES = {"all": "Hammaga", "noncontacts": "Faqat kontaktda yo'qlarga", "contacts": "Faqat kontaktlarga"}
COOLDOWNS = [0, 30, 60, 180, 360]


def v_filters():
    cd = int(cflt("cooldown"))
    nv = G["fetch_one"]("SELECT COUNT(*) c FROM sl_vip WHERE kind='vip'")["c"]
    ni = G["fetch_one"]("SELECT COUNT(*) c FROM sl_vip WHERE kind='ignore'")["c"]
    t = (f"👥 <b>Filtrlar</b>\n\nJavob beriladi: <b>{CONTACT_MODES[cfg('contacts')]}</b>\n"
         f"Qayta javob: <b>{'uyqu davomida 1 marta' if cd == 0 else f'{cd} daqiqada 1 marta'}</b>\n"
         f"Shoshilinch so'zlar: {onoff('urgent_on')} <code>{esc_(cfg('urgent'))}</code>\n\n"
         "⭐ <b>VIP</b> — javob berilmaydi, lekin yozsa sizga darhol xabar keladi.\n🔇 <b>Ignor</b> — umuman e'tibor berilmaydi.")
    rows = [
        [B(f"👤 Kimga: {CONTACT_MODES[cfg('contacts')]}", "sl:cm")],
        [B(f"🔁 Qayta javob: {'1 marta' if cd == 0 else str(cd) + ' daq'}", "sl:cd")],
        [B(f"🚨 Shoshilinch: {onoff('urgent_on')}", "sl:sw:urgent_on"), B("✏️ So'zlar", "sl:ue")],
        [B(f"⭐ VIP ({nv})", "sl:vl:vip"), B(f"🔇 Ignor ({ni})", "sl:vl:ignore")],
        [B("⬅️ Orqaga", "sl:menu")],
    ]
    return t, KB(rows)


def v_vips(kind):
    rows_db = G["fetch_all"]("SELECT * FROM sl_vip WHERE kind=? ORDER BY rowid DESC LIMIT 30", (kind,))
    title = "⭐ VIP ro'yxati" if kind == "vip" else "🔇 Ignor ro'yxati"
    t = f"<b>{title}</b>\n" + ("\n".join(f"• {esc_(r['name'])} (<code>{r['user_id']}</code>)" for r in rows_db) or "Bo'sh.")
    rows = [[B(f"🗑 {r['name'][:25]}", f"sl:vd:{r['user_id']}:{kind}")] for r in rows_db]
    rows.append([B("➕ Qo'shish", f"sl:va:{kind}")])
    rows.append([B("⬅️ Orqaga", "sl:fl")])
    return t, KB(rows)


def v_status():
    t = ("🌙 <b>Uxlaganda profilni o'zgartirish</b>\n\n"
         f"Emoji-status: {onoff('status_on')} {esc_(cfg('status_alt')) if cfg('status_doc') else '(tanlanmagan)'}\n"
         f"Bio: {onoff('bio_on')} <code>{esc_(cfg('bio_text'))}</code>\n\n"
         "Uyg'onganingizda hammasi avtomatik tiklanadi.\n"
         + ("" if is_premium_acc() else "⚠️ <i>Emoji-status va 140 belgili bio uchun akkauntda Telegram Premium kerak.</i>"))
    rows = [
        [B(f"Emoji-status: {onoff('status_on')}", "sl:sw:status_on"), B("🎭 Emoji tanlash", "sl:stp")],
        [B(f"Bio: {onoff('bio_on')}", "sl:sw:bio_on"), B("✏️ Bio matni", "sl:be")],
        [B("🧪 Sinash: qo'llash", "sl:stt:1"), B("↩️ Tiklash", "sl:stt:0")],
        [B("⬅️ Orqaga", "sl:menu")],
    ]
    return t, KB(rows)


def v_report():
    c, r, u = today_stats()
    last = G["fetch_all"]("SELECT name, text, ts, replied FROM sl_log ORDER BY ts DESC LIMIT 8")
    t = f"📊 <b>Hisobot</b>\n\nBugun: <b>{u}</b> kishi yozdi, <b>{r}</b> ta avto-javob.\n\n<b>Oxirgilari:</b>\n"
    for x in last:
        t += f"• {dt.datetime.fromtimestamp(x['ts'], G['now']().tzinfo):%d.%m %H:%M} {esc_(x['name'])}{' ↩️' if x['replied'] else ''}: {esc_(x['text'][:50])}\n"
    if not last:
        t += "Hali yo'q.\n"
    rows = [[B("📬 Joriy sessiya hisoboti", "sl:rs"), B("🧹 Tozalash", "sl:rc")],
            [B(f"Uyg'onganda hisobot: {onoff('report')}", "sl:sw:report")], [B("⬅️ Orqaga", "sl:menu")]]
    return t, KB(rows)


def v_settings():
    t = "⚙️ <b>Sozlamalar</b>"
    rows = [
        [B(f"Funksiya: {onoff('enabled')}", "sl:sw:enabled")],
        [B(f"⌨️ «Yozmoqda…» effekti: {onoff('typing')}", "sl:sw:typing")],
        [B(f"🎭 Avto-almashtirish (oddiy → custom emoji): {onoff('automap')}", "sl:sw:automap")],
        [B(f"⭐ VIP bildirishnoma: {onoff('vip_notify')}", "sl:sw:vip_notify")],
        [B(f"🚦 Tezlik limiti: {cfg('rate')}/daq", "sl:rt")],
        [B("⬅️ Orqaga", "sl:menu")],
    ]
    return t, KB(rows)


def v_acc():
    t = f"🔐 <b>Akkaunt</b>\n\n{acc_line()}\n"
    if cfg("api_id"):
        t += f"API ID: <code>{esc_(cfg('api_id'))}</code>\n"
    t += ("\n<i>Sessiya shifrlangan holda bazada saqlanadi. Uni hech kimga bermang — u akkauntingizga to'liq kirish beradi. "
          "Kodni faqat tugmalar bilan kiriting (xabar qilib yozsangiz, Telegram kodni bekor qilishi mumkin).</i>")
    rows = []
    if CLIENT and ME:
        rows.append([B("🔄 Qayta ulash", "sl:rl"), B("🔌 Chiqish", "sl:lo")])
    else:
        rows.append([B("📱 Kirish (login)", "sl:lg")])
        if cfg("session"):
            rows.append([B("🔄 Qayta ulash", "sl:rl")])
    rows.append([B("🔑 API ID/HASH o'zgartirish", "sl:api")])
    rows.append([B("⬅️ Orqaga", "sl:menu")])
    return t, KB(rows)


def keypad(code):
    shown = " ".join(list(code) + ["•"] * max(0, 5 - len(code)))
    t = f"🔐 Telegram yuborgan kodni <b>tugmalar bilan</b> kiriting:\n\n<b>{shown}</b>"
    d = [B(str(i), f"sl:kp:{i}") for i in range(1, 10)]
    rows = [d[0:3], d[3:6], d[6:9], [B("⌫", "sl:kp:del"), B("0", "sl:kp:0"), B("✅ Yuborish", "sl:kp:ok")],
            [B("❌ Bekor", "sl:kp:cancel")]]
    return t, KB(rows)


# ======================================================================
# Callback'lar
# ======================================================================
SW_VIEW = {"sched_on": "sch", "enabled": "set", "typing": "set", "automap": "set", "vip_notify": "set",
           "urgent_on": "fl", "status_on": "st", "bio_on": "st", "report": "rp"}


def view_for(name):
    return {"menu": v_main, "sch": v_sched, "tpl": v_tpl_list, "pk": v_packs, "st": v_status, "fl": v_filters,
            "rp": v_report, "set": v_settings, "acc": v_acc}[name]()


async def show(call, view):
    await G["edit"](call, view[0], view[1])


async def prompt(call, text):
    await call.message.answer(text + "\n\nBekor qilish: /cancel")


async def disconnect_account(logout=False):
    global CLIENT, ME
    if CLIENT:
        try:
            if logout:
                await apply_status(False)
                await CLIENT.log_out()
            else:
                await CLIENT.disconnect()
        except Exception:
            logging.exception("Akkauntni uzishda xato")
    CLIENT, ME = None, None
    if logout:
        cset("session", "")


async def cb_sl(call: types.CallbackQuery, state: FSMContext):
    if not G["is_admin"](call.from_user.id):
        return await call.answer()
    p = call.data.split(":")
    a = p[1] if len(p) > 1 else "menu"
    if a != "kp":
        await state.clear()
    if a == "noop":
        return await call.answer()
    if a in ("menu", "sch", "tpl", "st", "fl", "rp", "set", "acc") or (a == "pk" and len(p) == 2):
        await call.answer()
        return await show(call, view_for(a))
    if a == "tog":
        sl, _, _ = sleep_state()
        n = G["now"]()
        if sl:
            cset("force", "0")
            cset("sleep_until", "0")
            cset("awake_until", str(next_end(n).timestamp()) if in_window(n) else "0")
        else:
            cset("force", "1")
            cset("awake_until", "0")
        await call.answer()
        await force_transition()
        return await show(call, v_main())
    if a == "for" and len(p) > 2 and p[2].isdigit():
        cset("force", "0")
        cset("awake_until", "0")
        cset("sleep_until", str(time.time() + int(p[2]) * 3600))
        await call.answer(f"😴 {p[2]} soatga uxlaysiz")
        await force_transition()
        return await show(call, v_main())
    if a == "sw" and len(p) > 2 and p[2] in SW_VIEW:
        flip(p[2])
        await call.answer("Saqlandi")
        if p[2] == "enabled":
            await force_transition()
        return await show(call, view_for(SW_VIEW[p[2]]))
    if a == "t" and len(p) > 3 and p[2] in ("s", "e"):
        key = "sched_start" if p[2] == "s" else "sched_end"
        cset(key, fmt_hm(hm(cfg(key)) + int(p[3])))
        await call.answer()
        return await show(call, v_sched())
    if a == "d" and len(p) > 2 and p[2].isdigit():
        ds = set(cfg("sched_days"))
        ds.symmetric_difference_update({p[2]})
        cset("sched_days", "".join(sorted(ds)))
        await call.answer()
        return await show(call, v_sched())
    if a == "p" and len(p) > 3:
        cset("sched_start", f"{p[2][:2]}:{p[2][2:]}")
        cset("sched_end", f"{p[3][:2]}:{p[3][2:]}")
        cset("sched_on", "1")
        await call.answer("Saqlandi")
        return await show(call, v_sched())
    # ---- shablonlar ----
    if a == "tv" and p[2:3] and p[2].isdigit():
        await call.answer()
        return await show(call, v_tpl(int(p[2])))
    if a == "tn":
        await call.answer()
        await state.set_state(SlStates.tpl_text)
        await state.update_data(mode="new")
        return await prompt(call, "💬 Yangi shablon matnini yozing.\nPremium bo'lsangiz, custom emoji'ni to'g'ridan-to'g'ri yozishingiz mumkin; "
                                  "bo'lmasa oddiy emoji yozing (avto-almashtirish ularni custom emoji qiladi).\n"
                                  "O'zgaruvchilar: {name} {wake} {date} {time}")
    if a == "te" and p[2:3] and p[2].isdigit():
        await call.answer()
        await state.set_state(SlStates.tpl_text)
        await state.update_data(mode="edit", tid=int(p[2]))
        return await prompt(call, "✏️ Yangi matnni yozing:")
    if a == "tt" and p[2:3] and p[2].isdigit():
        G["run"]("UPDATE sl_tpl SET active = 1 - active WHERE id=?", (int(p[2]),))
        await call.answer("Saqlandi")
        return await show(call, v_tpl(int(p[2])))
    if a == "td" and p[2:3] and p[2].isdigit():
        await call.answer()
        return await show(call, (f"🗑 Shablon #{p[2]} o'chirilsinmi?", KB([[B("✅ Ha", f"sl:tdy:{p[2]}"), B("❌ Yo'q", f"sl:tv:{p[2]}")]])))
    if a == "tdy" and p[2:3] and p[2].isdigit():
        G["run"]("DELETE FROM sl_tpl WHERE id=?", (int(p[2]),))
        await call.answer("O'chirildi")
        return await show(call, v_tpl_list())
    if a == "tx" and p[2:3] and p[2].isdigit():
        await call.answer()
        return await show(call, v_tx(int(p[2])))
    if a == "tp" and p[2:3] and p[2].isdigit():
        r = G["fetch_one"]("SELECT text FROM sl_tpl WHERE id=?", (int(p[2]),))
        if not CLIENT or not r:
            return await call.answer("Avval akkauntni ulang (🔐 Akkaunt)", show_alert=True)
        try:
            await send_away("me", ME.first_name or "do'stim", tpl=r["text"])
            return await call.answer("👁 Saved Messages'ga yuborildi" + ("" if is_premium_acc() else " (Premium yo'q: oddiy emoji bilan)"), show_alert=True)
        except Exception as ex:
            return await call.answer(f"Xato: {str(ex)[:150]}", show_alert=True)
    # ---- emoji paketlari ----
    if a == "pk" and p[2:3] and p[2].isdigit():
        await call.answer()
        return await show(call, v_pack(int(p[2])))
    if a == "pn":
        await call.answer()
        await state.set_state(SlStates.pk_link)
        return await prompt(call, "🎭 Emoji paketi havolasini yuboring:\n<code>https://t.me/addemoji/NOMI</code>")
    if a == "pv" and len(p) > 5 and p[2].isdigit() and p[3].lstrip("-").isdigit():
        await call.answer()
        return await show(call, v_grid(int(p[2]), int(p[3]), p[4], int(p[5]) if p[5].isdigit() else 0))
    if a == "pc" and len(p) > 5 and p[2].isdigit() and p[3].isdigit():
        pk = G["fetch_one"]("SELECT data FROM sl_pack WHERE id=?", (int(p[2]),))
        items = json.loads(pk["data"]) if pk else []
        i = int(p[3])
        if i >= len(items):
            return await call.answer()
        cid, alt = items[i]
        if p[4] == "t":
            G["run"]("UPDATE sl_tpl SET text = text || ? WHERE id=?", (f"⟪{cid}|{alt}⟫", int(p[5])))
            await call.answer(f"{alt} qo'shildi")
            return await show(call, v_grid(int(p[2]), i // 40, "t", int(p[5])))
        if p[4] == "s":
            cset("status_doc", cid)
            cset("status_alt", alt)
            cset("status_on", "1")
            await call.answer(f"{alt} status qilib tanlandi", show_alert=True)
            return await show(call, v_status())
        return await call.answer()
    if a == "pa" and p[2:3] and p[2].isdigit():
        G["run"]("UPDATE sl_pack SET active = 1 - active WHERE id=?", (int(p[2]),))
        await call.answer("Saqlandi")
        return await show(call, v_pack(int(p[2])))
    if a == "pd" and p[2:3] and p[2].isdigit():
        await call.answer()
        return await show(call, ("🗑 Paket o'chirilsinmi?", KB([[B("✅ Ha", f"sl:pdy:{p[2]}"), B("❌ Yo'q", f"sl:pk:{p[2]}")]])))
    if a == "pdy" and p[2:3] and p[2].isdigit():
        G["run"]("DELETE FROM sl_pack WHERE id=?", (int(p[2]),))
        await call.answer("O'chirildi")
        return await show(call, v_packs())
    # ---- filtrlar ----
    if a == "cm":
        ks = list(CONTACT_MODES)
        cset("contacts", ks[(ks.index(cfg("contacts")) + 1) % len(ks)])
        await call.answer()
        return await show(call, v_filters())
    if a == "cd":
        cur = int(cflt("cooldown"))
        cset("cooldown", COOLDOWNS[(COOLDOWNS.index(cur) + 1) % len(COOLDOWNS)] if cur in COOLDOWNS else 0)
        await call.answer()
        return await show(call, v_filters())
    if a == "ue":
        await call.answer()
        await state.set_state(SlStates.urgent)
        return await prompt(call, "🚨 Shoshilinch so'zlarni vergul bilan yozing.\nMasalan: <code>shoshilinch, zarur, urgent</code>")
    if a == "vl" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        return await show(call, v_vips(p[2]))
    if a == "va" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        await state.set_state(SlStates.vip_add)
        await state.update_data(kind=p[2])
        return await prompt(call, "Foydalanuvchining <b>ID</b> raqami, <b>@username</b>'i yoki undan <b>forward</b> qilingan xabarni yuboring:")
    if a == "vd" and len(p) > 3 and p[2].lstrip("-").isdigit():
        G["run"]("DELETE FROM sl_vip WHERE user_id=?", (int(p[2]),))
        await call.answer("O'chirildi")
        return await show(call, v_vips(p[3]))
    # ---- status / bio ----
    if a == "stp":
        ps = packs()
        if not ps:
            return await call.answer("Avval emoji paketi qo'shing (🎭 Emoji paketlar)", show_alert=True)
        await call.answer()
        rows = [[B(f"🎭 {x['title'][:30]}", f"sl:pv:{x['id']}:0:s:0")] for x in ps] + [[B("⬅️ Orqaga", "sl:st")]]
        return await show(call, ("🌙 Status emoji qaysi paketdan?", KB(rows)))
    if a == "be":
        await call.answer()
        await state.set_state(SlStates.bio_text)
        return await prompt(call, "✏️ Uxlaganda bio matni (<code>{wake}</code> — uyg'onish vaqti). 70 belgigacha (Premium: 140):")
    if a == "stt" and (p[2] if len(p) > 2 else "") in ("0", "1"):
        err = await apply_status(p[2] == "1")
        return await call.answer("✅ Bajarildi" if not err else f"⚠️ {err[:180]}", show_alert=bool(err))
    # ---- hisobot ----
    if a == "rs":
        await call.answer()
        return await call.message.answer(build_report(cfg("session_id"))[:4000])
    if a == "rc":
        G["run"]("DELETE FROM sl_log")
        await call.answer("Tozalandi")
        return await show(call, v_report())
    if a == "rt":
        opts = [5, 10, 20, 40]
        cur = int(cflt("rate"))
        cset("rate", opts[(opts.index(cur) + 1) % len(opts)] if cur in opts else 20)
        await call.answer()
        return await show(call, v_settings())
    # ---- akkaunt / login ----
    if a == "api":
        await call.answer()
        await state.set_state(SlStates.api_id)
        return await prompt(call, "🔑 <a href=\"https://my.telegram.org\">my.telegram.org</a> → API development tools → <b>api_id</b> (raqam) yuboring:")
    if a == "lg":
        if not HAS_TELETHON:
            return await call.answer("Avval o'rnating: pip install telethon", show_alert=True)
        await call.answer()
        if not (cfg("api_id") and cfg("api_hash")):
            await state.set_state(SlStates.api_id)
            return await prompt(call, "🔑 <a href=\"https://my.telegram.org\">my.telegram.org</a> → API development tools → yangi ilova yarating va <b>api_id</b> (raqam) yuboring:")
        await state.set_state(SlStates.phone)
        return await prompt(call, "📱 Telefon raqamingizni yuboring (masalan <code>+998901234567</code>):")
    if a == "rl":
        await call.answer("Ulanmoqda…")
        if HAS_TELETHON:
            await connect_saved()
        return await show(call, v_acc())
    if a == "lo":
        await call.answer()
        return await show(call, ("🔌 Akkauntdan chiqilsinmi? Sessiya Telegram'da ham tugatiladi, avto-javob to'xtaydi.",
                                 KB([[B("✅ Ha, chiqish", "sl:loy"), B("❌ Yo'q", "sl:acc")]])))
    if a == "loy":
        await disconnect_account(logout=True)
        await call.answer("Chiqildi")
        return await show(call, v_acc())
    if a == "kp":
        return await cb_keypad(call, state, p[2] if len(p) > 2 else "")
    await call.answer()


async def cb_keypad(call, state, op):
    c = LOGIN.get("client")
    if not c:
        # Callback eskirgan bo'lsa Telegram call.answer() ni rad etishi mumkin.
        # Bu holat botning qolgan ishini yiqitmasligi kerak.
        try:
            await call.answer("Seans tugagan. Qaytadan kiring.", show_alert=True)
        except TelegramBadRequest as exc:
            msg = str(exc).lower()
            if "query is too old" in msg or "response timeout expired" in msg or "query id is invalid" in msg:
                logging.debug("Uyqu rejimi: eskirgan callback javobi o'tkazib yuborildi.")
            else:
                raise
        return await show(call, v_acc())
    if op == "cancel":
        try:
            await c.disconnect()
        except Exception:
            pass
        LOGIN.clear()
        await call.answer()
        return await show(call, v_acc())
    if op.isdigit() and len(op) == 1:
        if len(LOGIN["code"]) < 6:
            LOGIN["code"] += op
    elif op == "del":
        LOGIN["code"] = LOGIN["code"][:-1]
    elif op == "ok":
        if len(LOGIN["code"]) < 5:
            return await call.answer("Kod to'liq emas", show_alert=True)
        try:
            await c.sign_in(LOGIN["phone"], LOGIN["code"], phone_code_hash=LOGIN["hash"])
        except SessionPasswordNeededError:
            await call.answer()
            await state.set_state(SlStates.password)
            return await call.message.answer("🔒 Ikki bosqichli parol (2FA) yoqilgan. Parolni yuboring (xabar darhol o'chiriladi):")
        except PhoneCodeInvalidError:
            LOGIN["code"] = ""
            await call.answer("❌ Kod noto'g'ri", show_alert=True)
        except PhoneCodeExpiredError:
            LOGIN.clear()
            await call.answer("Kod eskirdi. Qaytadan kiring.", show_alert=True)
            return await show(call, v_acc())
        except Exception as ex:
            await call.answer(f"Xato: {str(ex)[:150]}", show_alert=True)
        else:
            await call.answer("✅")
            return await finish_login(call.message)
    await call.answer()
    t, kb = keypad(LOGIN.get("code", ""))
    await G["edit"](call, t, kb)


async def finish_login(msg):
    c = LOGIN.get("client")
    sess = c.session.save()
    await c.disconnect()
    LOGIN.clear()
    cset("session", G["enc"](sess))
    ok = await connect_saved()
    t, kb = v_acc()
    await msg.answer(("✅ <b>Akkaunt ulandi!</b>\n\n" if ok else "⚠️ Sessiya saqlandi, lekin ulanib bo'lmadi.\n\n") + t, reply_markup=kb)


# ======================================================================
# Matnli kiritish (FSM)
# ======================================================================
async def _del(message):
    try:
        await message.delete()
    except Exception:
        pass


async def h_api_id(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    await _del(message)
    if not t.isdigit():
        return await message.answer("api_id faqat raqam. Qayta yuboring (bekor: /cancel):")
    await state.update_data(api_id=t)
    await state.set_state(SlStates.api_hash)
    await message.answer("Endi <b>api_hash</b> (32 ta harf-raqam) yuboring:")


async def h_api_hash(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip().lower()
    await _del(message)
    if not re.fullmatch(r"[0-9a-f]{32}", t):
        return await message.answer("api_hash 32 belgili bo'lishi kerak. Qayta yuboring (bekor: /cancel):")
    d = await state.get_data()
    cset("api_id", d.get("api_id", ""))
    cset("api_hash", t)
    await state.set_state(SlStates.phone)
    await message.answer("✅ Saqlandi.\n📱 Endi telefon raqamingizni yuboring (<code>+998901234567</code>):")


async def h_phone(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    if not HAS_TELETHON:
        return await message.answer("Telethon o'rnatilmagan: <code>pip install telethon</code>")
    raw = re.sub(r"[^\d+]", "", message.text or "")
    phone = raw if raw.startswith("+") else "+" + raw
    await _del(message)
    try:
        c = TelegramClient(StringSession(), int(cfg("api_id")), cfg("api_hash"), device_model="HEMIS Sleep", app_version="1.0")
        await c.connect()
        sent = await c.send_code_request(phone)
    except PhoneNumberInvalidError:
        return await message.answer("❌ Telefon raqami noto'g'ri. Qayta yuboring (bekor: /cancel):")
    except FloodWaitError as ex:
        await state.clear()
        return await message.answer(f"⏳ Telegram {ex.seconds} soniya kutishni so'radi. Keyinroq urinib ko'ring.")
    except Exception as ex:
        await state.clear()
        return await message.answer(f"❌ Xato: {esc_(str(ex)[:200])}\napi_id/api_hash to'g'riligini tekshiring (🔐 Akkaunt → API).")
    LOGIN.clear()
    LOGIN.update(client=c, phone=phone, hash=sent.phone_code_hash, code="")
    await state.clear()
    t, kb = keypad("")
    await message.answer(t, reply_markup=kb)


async def h_password(message: types.Message, state: FSMContext):
    c = LOGIN.get("client")
    pw = message.text or ""
    await _del(message)
    if not c:
        await state.clear()
        return await message.answer("Seans tugagan. Qaytadan kiring: /uyqu")
    try:
        await c.sign_in(password=pw)
    except PasswordHashInvalidError:
        return await message.answer("❌ Parol noto'g'ri. Qayta yuboring (bekor: /cancel):")
    except Exception as ex:
        await state.clear()
        return await message.answer(f"❌ Xato: {esc_(str(ex)[:200])}")
    await state.clear()
    await finish_login(message)


async def send_view(message, view):
    await message.answer(view[0], reply_markup=view[1])


async def h_tpl_text(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    text = msg_to_tpl(message).strip()
    if not text or len(text) > 1500:
        return await message.answer("Matn bo'sh yoki juda uzun (maks. 1500 belgi). Qayta yuboring:")
    d = await state.get_data()
    await state.clear()
    if d.get("mode") == "edit":
        tid = d["tid"]
        G["run"]("UPDATE sl_tpl SET text=? WHERE id=?", (text, tid))
    else:
        tid = G["insert"]("INSERT INTO sl_tpl (text, active) VALUES (?, 1)", (text,))
    await send_view(message, v_tpl(tid))


async def h_pk_link(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    m = re.search(r"(?:t\.me|telegram\.me)/addemoji/([A-Za-z0-9_]+)", message.text or "") or re.fullmatch(r"\s*([A-Za-z0-9_]{3,})\s*", message.text or "")
    if not m:
        return await message.answer("Havola noto'g'ri. Misol: <code>https://t.me/addemoji/NOMI</code>")
    name = m.group(1)
    try:
        ss = await G["bot"].get_sticker_set(name)
    except Exception as ex:
        return await message.answer(f"❌ Paket topilmadi: {esc_(str(ex)[:120])}")
    items = [[s.custom_emoji_id, s.emoji or "⭐"] for s in ss.stickers if getattr(s, "custom_emoji_id", None)]
    if not items:
        return await message.answer("❌ Bu custom emoji paketi emas (oddiy stiker paketi). <code>/addemoji/</code> havolasini yuboring.")
    await state.clear()
    G["run"]("INSERT INTO sl_pack (short_name, title, data, active) VALUES (?,?,?,1) "
             "ON CONFLICT(short_name) DO UPDATE SET title=excluded.title, data=excluded.data", (name, ss.title, json.dumps(items[:300])))
    pid = G["fetch_one"]("SELECT id FROM sl_pack WHERE short_name=?", (name,))["id"]
    await message.answer(f"✅ <b>{esc_(ss.title)}</b> qo'shildi ({len(items)} ta emoji).")
    await send_view(message, v_pack(pid))


async def h_urgent(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    words = ",".join(w.strip() for w in (message.text or "").split(",") if w.strip())[:300]
    cset("urgent", words)
    await state.clear()
    await send_view(message, v_filters())


async def h_bio(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    cset("bio_text", (message.text or "").strip()[:140])
    await state.clear()
    await send_view(message, v_status())


async def h_vip(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    kind = (await state.get_data()).get("kind", "vip")
    uid, name = None, ""
    fo = getattr(message, "forward_origin", None)
    fu = getattr(fo, "sender_user", None) or getattr(message, "forward_from", None)
    if fu:
        uid, name = fu.id, fu.full_name
    else:
        t = (message.text or "").strip()
        if re.fullmatch(r"\d{4,}", t):
            uid, name = int(t), t
        elif re.fullmatch(r"@?[A-Za-z0-9_]{4,}", t):
            if not CLIENT:
                return await message.answer("@username orqali qo'shish uchun avval akkauntni ulang yoki ID yuboring.")
            try:
                ent = await CLIENT.get_entity(t if t.startswith("@") else "@" + t)
                uid, name = ent.id, " ".join(x for x in (ent.first_name, getattr(ent, "last_name", None)) if x) or t
            except Exception:
                return await message.answer("Topilmadi. ID yoki forward qilingan xabarni yuboring.")
    if not uid:
        return await message.answer("ID, @username yoki forward qilingan xabar yuboring.")
    if CLIENT and name == str(uid):
        try:
            ent = await CLIENT.get_entity(uid)
            name = " ".join(x for x in (ent.first_name, getattr(ent, "last_name", None)) if x) or name
        except Exception:
            pass
    G["run"]("INSERT INTO sl_vip (user_id, name, kind) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, kind=excluded.kind",
             (uid, name, kind))
    await state.clear()
    await send_view(message, v_vips(kind))


async def cmd_uyqu(message: types.Message, state: FSMContext):
    if not G["is_admin"](message.from_user.id):
        return
    await state.clear()
    await send_view(message, v_main())


def setup(ns):
    missing = [k for k in NEEDED if k not in ns]
    if missing:
        raise RuntimeError("sleepmode.setup: hemis3.py da topilmadi: " + ", ".join(missing))
    G.update({k: ns[k] for k in NEEDED})
    dp = G["dp"]
    m = dp.message
    m.register(cmd_uyqu, Command("uyqu"))
    for st, h in ((SlStates.api_id, h_api_id), (SlStates.api_hash, h_api_hash), (SlStates.phone, h_phone),
                  (SlStates.password, h_password), (SlStates.tpl_text, h_tpl_text), (SlStates.pk_link, h_pk_link),
                  (SlStates.vip_add, h_vip), (SlStates.urgent, h_urgent), (SlStates.bio_text, h_bio)):
        m.register(h, StateFilter(st))
    dp.callback_query.register(cb_sl, F.data.startswith("sl:"))
    logging.info("Uyqu rejimi yuklandi")


def start():
    init_tables()
    if not HAS_TELETHON:
        logging.warning("Uyqu rejimi: Telethon o'rnatilmagan (pip install telethon)")
    spawn(sleep_loop())
