import datetime as dt
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import plus_core as pc  # noqa: E402


class SM2(unittest.TestCase):
    def test_again_resets(self):
        e, i, r = pc.sm2(2.5, 10, 4, 1)
        self.assertEqual((i, r), (1, 0))
        self.assertLess(e, 2.5)

    def test_growth(self):
        e, i, r = pc.sm2(2.5, 0, 0, 4)
        self.assertEqual((i, r), (1, 1))
        e, i, r = pc.sm2(e, i, r, 4)
        self.assertEqual((i, r), (6, 2))
        e, i, r = pc.sm2(e, i, r, 5)
        self.assertGreater(i, 6)

    def test_ease_floor(self):
        e = 2.5
        for _ in range(20):
            e, _, _ = pc.sm2(e, 1, 0, 0)
        self.assertGreaterEqual(e, 1.3)

    def test_parse_cards(self):
        t = "Faraday qonuni | induksiya EYUK\n1) Om qonuni - I=U/R\nbo'sh qator\n\nA :: B"
        self.assertEqual(pc.parse_cards(t), [("Faraday qonuni", "induksiya EYUK"), ("Om qonuni", "I=U/R"), ("A", "B")])
        self.assertEqual(len(pc.parse_cards("a|b\n" * 500, limit=10)), 10)


class Gamify(unittest.TestCase):
    def test_levels(self):
        self.assertEqual(pc.level_of(0), 1)
        self.assertEqual(pc.level_of(25), 2)
        self.assertEqual(pc.level_of(100), 3)
        for lv in range(1, 12):
            self.assertEqual(pc.level_of(pc.xp_for_level(lv)), lv)

    def test_bar_width(self):
        for xp in (0, 10, 24, 25, 99, 5000):
            self.assertEqual(len(pc.level_bar(xp)), 10)

    def test_streak(self):
        self.assertEqual(pc.next_streak(None, "2026-10-28", 0), (1, True))
        self.assertEqual(pc.next_streak("2026-10-27", "2026-10-28", 3), (4, True))
        self.assertEqual(pc.next_streak("2026-10-25", "2026-10-28", 3), (1, True))
        self.assertEqual(pc.next_streak("2026-10-28", "2026-10-28", 3), (3, False))

    def test_badges(self):
        s = dict(xp=120, streak=3, best_streak=3, pomodoros=0, cards_done=0)
        names = [n for _, n in pc.badges_of(s)]
        self.assertIn("3 kunlik streak", names)
        self.assertIn("100 XP", names)
        self.assertNotIn("500 XP", names)


class Calc(unittest.TestCase):
    def test_need(self):
        r = pc.need_points(40, 50, 5)
        self.assertEqual(r["status"], "ok")
        self.assertEqual(r["need"], 46)
        self.assertAlmostEqual(r["percent"], 92.0)
        self.assertEqual(pc.need_points(50, 90, 5)["status"], "impossible")
        self.assertEqual(pc.need_points(90, 100, 5)["status"], "already")
        self.assertEqual(pc.need_points(30, 40, 3)["status"], "ok")
        with self.assertRaises(ValueError):
            pc.need_points(60, 50, 5)
        with self.assertRaises(ValueError):
            pc.need_points(10, 50, 2)

    def test_gpa(self):
        self.assertEqual(pc.gpa_of(pc.parse_gpa("5x4 4x3 5*2")), round((20 + 12 + 10) / 9, 2))
        self.assertEqual(pc.parse_gpa("4.5x2, 5x3"), [(4.5, 2.0), (5.0, 3.0)])
        for bad in ("", "abc", "6x3", "5x0"):
            with self.assertRaises(ValueError):
                pc.parse_gpa(bad)
        need = pc.gpa_needed([(4.0, 10)], 10, 4.5)
        self.assertEqual(need, 5.0)


class Dates(unittest.TestCase):
    def test_parse(self):
        t = dt.date(2026, 10, 28)
        self.assertEqual(pc.parse_any_date("15.12.2026", t), dt.date(2026, 12, 15))
        self.assertEqual(pc.parse_any_date("2026-12-15", t), dt.date(2026, 12, 15))
        self.assertEqual(pc.parse_any_date("5.11", t), dt.date(2026, 11, 5))
        self.assertEqual(pc.parse_any_date("5.1", t), dt.date(2027, 1, 5))
        self.assertIsNone(pc.parse_any_date("x", t))
        self.assertIsNone(pc.parse_any_date("31.02", t))

    def test_plan(self):
        t = dt.date(2026, 10, 28)
        plan = pc.study_plan(t, dt.date(2026, 11, 7), ["a", "b", "c", "d", "e"])
        self.assertEqual(plan[-1][0], dt.date(2026, 11, 6))
        self.assertEqual(sum(len(x) for _, x in plan[:-1]), 5)
        self.assertTrue(all(t <= d < dt.date(2026, 11, 7) for d, _ in plan))
        short = pc.study_plan(t, dt.date(2026, 10, 29), ["a", "b"], review_day=True)
        self.assertEqual(len(short), 1)
        with self.assertRaises(ValueError):
            pc.study_plan(t, t, ["a"])
        with self.assertRaises(ValueError):
            pc.study_plan(t, dt.date(2026, 11, 1), [])

    def test_ics(self):
        ev = [{"title": "Fizika, imtihon; 1", "date": dt.date(2026, 11, 5), "time": "09:30", "minutes": 90, "desc": "A\nB"},
              {"title": "Vazifa " + "x" * 120, "date": dt.date(2026, 11, 6), "time": None}]
        s = pc.build_ics(ev, stamp=dt.datetime(2026, 10, 28, 1, 2, 3))
        self.assertTrue(s.startswith("BEGIN:VCALENDAR\r\n"))
        self.assertTrue(s.endswith("END:VCALENDAR\r\n"))
        self.assertIn("DTSTART;TZID=Asia/Tashkent:20261105T093000", s)
        self.assertIn("DTEND;TZID=Asia/Tashkent:20261105T110000", s)
        self.assertIn("DTSTART;VALUE=DATE:20261106", s)
        self.assertIn("Fizika\\, imtihon\\; 1", s)
        self.assertEqual(s.count("BEGIN:VEVENT"), 2)
        for line in s.split("\r\n"):
            self.assertLessEqual(len(line.encode()), 75)


class Misc(unittest.TestCase):
    def test_promo(self):
        row = {"active": 1, "expires": "2026-12-01", "max_uses": 2, "used": 1}
        d = dt.date(2026, 10, 28)
        self.assertIsNone(pc.promo_check(row, False, d))
        self.assertIn("foydalanib", pc.promo_check(row, True, d))
        self.assertIn("limit", pc.promo_check({**row, "used": 2}, False, d))
        self.assertIn("muddati", pc.promo_check({**row, "expires": "2026-10-01"}, False, d))
        self.assertIn("topilmadi", pc.promo_check(None, False, d))
        self.assertEqual(pc.norm_code(" ab-c 1!"), "AB-C1")

    def test_keys(self):
        k = pc.new_api_key()
        self.assertTrue(k.startswith("hk_"))
        self.assertEqual(pc.hash_key(k), pc.hash_key(k))
        self.assertNotEqual(pc.new_api_key(), k)

    def test_poll(self):
        self.assertEqual(pc.parse_poll("Q | a | b"), ("Q", ["a", "b"]))
        for bad in ("Q | a", "", "Q|" + "|".join("x" * 3 + str(i) for i in range(12))):
            with self.assertRaises(ValueError):
                pc.parse_poll(bad)
        self.assertEqual(pc.duel_result(3, 3), "draw")
        self.assertEqual(pc.duel_result(4, 3), "p1")
        self.assertEqual(len(pc.bar(3, 10)), 10)
        self.assertEqual(len(pc.bar(0, 0)), 10)

    def test_backups(self):
        names = ["hemis_20260101.db", "hemis_20260103.db", "hemis_20260102.db", "x.db", "hemis_20260104.db"]
        self.assertEqual(pc.backups_to_delete(names, 2), ["hemis_20260101.db", "hemis_20260102.db"])
        self.assertEqual(pc.backups_to_delete(names, 10), [])


if __name__ == "__main__":
    unittest.main()
