import json
import unittest
from archive_parser import parse_telegram_export


class TelegramExportParserTests(unittest.TestCase):
    def make_export(self, messages):
        return json.dumps({"chats": {"list": [{"name": "Chat", "id": 42, "messages": messages}]}}).encode()

    def test_flattens_text_entities_and_keeps_metadata(self):
        data = self.make_export([{
            "id": 7, "type": "message", "date_unixtime": "1700000000",
            "from": "Ali", "text": ["Salom ", {"type": "bold", "text": "dunyo"}],
        }])
        rows = parse_telegram_export(data)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0:5], ("Chat", "42", "7", "Ali", "Salom dunyo"))
        self.assertEqual(rows[0][5], 1700000000.0)

    def test_skips_service_and_media_only_messages(self):
        data = self.make_export([
            {"type": "service", "text": "service"},
            {"type": "message", "text": ""},
            {"type": "message", "text": "OK"},
        ])
        self.assertEqual([r[4] for r in parse_telegram_export(data)], ["OK"])

    def test_limits_message_count(self):
        data = self.make_export([{"type": "message", "text": str(i)} for i in range(20)])
        self.assertEqual(len(parse_telegram_export(data, max_messages=3)), 3)

    def test_rejects_oversized_file(self):
        with self.assertRaises(ValueError):
            parse_telegram_export(b"12345", max_bytes=4)

    def test_rejects_invalid_json_and_missing_chat_list(self):
        with self.assertRaises(ValueError):
            parse_telegram_export(b"not json")
        with self.assertRaises(ValueError):
            parse_telegram_export(b'{"chats": {}}')


if __name__ == "__main__":
    unittest.main()
