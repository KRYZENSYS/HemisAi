"""Plus moduli oqimlari: haqiqiy SQLite + soxta aiogram/aiohttp (aiogram o'rnatilmagan bo'lsa). CI'da aiogram bo'lsa o'tkazib yuboriladi."""
import asyncio
import datetime as dt
import html
import importlib.util
import json
import os
import sqlite3
import sys
import tempfile
import types as pytypes
import unittest

TZ = dt.timezone(dt.timedelta(hours=5))  # bot vaqt mintaqasi (Toshkent), testlar ham shu soatdan foydalanadi

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
REAL_AIOGRAM = importlib.util.find_spec("aiogram") is not None


def install_stubs():
    def mod(name, **attrs):
        m = pytypes.ModuleType(name)
        m.__dict__.update(attrs)
        sys.modules[name] = m
        return m

    class Any_:
        def __getattr__(self, k):
            return Any_()

        def __call__(self, *a, **k):
            return Any_()

        def __eq__(self, o):
            return Any_()

        def __invert__(self):
            return Any_()

        def __or__(self, o):
            return Any_()

        def __and__(self, o):
            return Any_()
        __hash__ = object.__hash__

    class Btn:
        def __init__(self, text, callback_data=None, url=None, web_app=None):
            self.text, self.callback_data, self.url, self.web_app = text, callback_data, url, web_app

    class Kb:
        def __init__(self, inline_keyboard):
            self.inline_keyboard = inline_keyboard

    class Message:
        pass

    class CallbackQuery:
        pass

    class BufferedInputFile:
        def __init__(self, data, filename=None):
            self.data, self.filename = data, filename

    class State:
        def __set_name__(self, owner, name):
            self.name = f"{owner.__name__}:{name}"

    class StatesGroup:
        pass

    types_m = mod("aiogram.types", Message=Message, CallbackQuery=CallbackQuery, BufferedInputFile=BufferedInputFile,
                  InlineKeyboardButton=Btn, InlineKeyboardMarkup=Kb, WebAppInfo=lambda url: url)
    mod("aiogram", BaseMiddleware=object, F=Any_(), types=types_m)
    mod("aiogram.filters", Command=lambda *a, **k: ("cmd", a), StateFilter=lambda *a: ("state", a))
    mod("aiogram.fsm", )
    mod("aiogram.fsm.context", FSMContext=object)
    mod("aiogram.fsm.state", State=State, StatesGroup=StatesGroup)
    mod("aiohttp", web=pytypes.SimpleNamespace(Response=lambda **k: pytypes.SimpleNamespace(headers={}, **k)))
    return types_m


@unittest.skipIf(REAL_AIOGRAM, "haqiqiy aiogram bor - soxta muhit kerak emas")
class PlusFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.types = install_stubs()
        import plus
        import plus_core
        cls.plus, cls.core = plus, plus_core

    def setUp(self):
        from cryptography.fernet import Fernet
        self.tmp = tempfile.mkdtemp()
        self.dbf = os.path.join(self.tmp, "t.db")
        self.fernet = Fernet(Fernet.generate_key())
        self.out = []
        self.edits = []
        self.docs = []
        self.handlers = {"message": [], "callback": []}
        self.routes = {}
        T = self.types
        test = self

        def db():
            c = sqlite3.connect(self.dbf)
            c.row_factory = sqlite3.Row
            return c

        def fetch_all(sql, p=()):
            with db() as c:
                return c.execute(sql, p).fetchall()

        def fetch_one(sql, p=()):
            with db() as c:
                return c.execute(sql, p).fetchone()

        def run(sql, p=()):
            c = db()
            try:
                cur = c.execute(sql, p)
                c.commit()
                return cur.rowcount
            finally:
                c.close()

        def insert(sql, p=()):
            c = db()
            try:
                cur = c.execute(sql, p)
                c.commit()
                return cur.lastrowid
            finally:
                c.close()
        with db() as c:
            c.executescript("""
            CREATE TABLE users (user_id INTEGER PRIMARY KEY, token TEXT, full_name TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, is_blocked INTEGER DEFAULT 0, last_seen TIMESTAMP);
            CREATE TABLE settings (user_id INTEGER PRIMARY KEY, semester TEXT);
            CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, text TEXT);
            CREATE TABLE reminders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, text TEXT, remind_at TEXT, sent INTEGER DEFAULT 0);
            CREATE TABLE sent_log (user_id INTEGER, key TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id, key));
            CREATE TABLE ai_usage (user_id INTEGER, day TEXT, n INTEGER DEFAULT 0, tokens INTEGER DEFAULT 0, PRIMARY KEY (user_id, day));
            CREATE TABLE hub_users (user_id INTEGER PRIMARY KEY, credits INTEGER DEFAULT 0, premium_until TEXT);
            CREATE TABLE hub_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount INTEGER, status TEXT, paid TEXT);
            """)
        ADMIN = 1
        for uid, name in ((1, "Admin Adminov"), (2, "Ali Valiyev"), (3, "Sardor Karimov"), (4, "Dilnoza Aliyeva")):
            run("INSERT INTO users (user_id, token, full_name) VALUES (?, ?, ?)", (uid, "eyJ-token-%d" % uid, name))
        self.ns = {
            "dp": pytypes.SimpleNamespace(
                message=pytypes.SimpleNamespace(register=lambda fn, *f: test.handlers["message"].append((fn, f)), outer_middleware=lambda mw: None),
                callback_query=pytypes.SimpleNamespace(register=lambda fn, *f: test.handlers["callback"].append((fn, f)), outer_middleware=lambda mw: None)),
            "bot": None, "ADMIN_ID": ADMIN, "is_admin": lambda u: u == ADMIN, "esc": html.escape, "e": html.escape,
            "now": lambda: dt.datetime.now(TZ), "dig": lambda d, *k, default=None: default, "nm": lambda d, k, default="": default,
            "first": lambda d, ks: next((d[k] for k in ks if k in d), None), "unwrap": lambda d: d.get("data", []),
            "parse_date": lambda s: dt.date.fromisoformat(s) if s else None, "fmt_date": lambda d: d.strftime("%d.%m.%Y"),
            "fetch": self.fake_fetch, "fetch_all": fetch_all, "fetch_one": fetch_one, "run": run, "insert": insert,
            "safe_send": self.safe_send, "get_user_token": lambda u: (fetch_one("SELECT token FROM users WHERE user_id=?", (u,)) or [None])[0],
            "claim": lambda u, k: run("INSERT OR IGNORE INTO sent_log (user_id, key) VALUES (?, ?)", (u, k)) == 1,
            "get_all_user_ids": lambda: [1, 2, 3, 4], "get_main_keyboard": lambda u: None, "interrupted": self.interrupted,
            "sem_params": lambda u: None, "subj_name": lambda it: it.get("subject", "Fan"), "exam_date_of": lambda it: dt.date.fromisoformat(it["date"]),
            "db": db, "edit": self.edit, "B_PLUS": "✨ Plus", "DB_NAME": self.dbf, "set_blocked": lambda u, v: True,
            "ai_dialog": self.ai_dialog, "ai_media_parts": self.media_parts, "ai_quiz": self.ai_quiz, "ai_slot": self.ai_slot,
            "ai_count": lambda *a, **k: None, "AIGate": type("AIGate", (Exception,), {}), "GeminiError": type("GeminiError", (Exception,), {}),
            "ai_err_text": str, "ai_available": lambda: True, "gemini_generate": None, "ai_text_models": lambda: [],
            "R": self.FakeR(self.routes), "jres": lambda d, status=200: {"json": d, "status": status},
            "WebErr": type("WebErr", (Exception,), {"__init__": lambda s, c, st=400: (setattr(s, "code", c), setattr(s, "status", st), None)[-1]}),
            "TZ": TZ, "WEB_APP_URL": "https://example.org", "FERNET": self.fernet, "is_blocked": lambda u: False,
            "w_schedule": self.w_schedule,
        }
        self.dialog_calls = []
        self.plus.G.clear()
        self.plus.setup(self.ns)
        self.plus.init_tables()
        self.plus.CHK.clear()

    # ---- soxta muhit
    class FakeR:
        def __init__(self, routes):
            self.routes = routes

        def get(self, path):
            def deco(fn):
                self.routes[path] = fn
                return fn
            return deco

    async def fake_fetch(self, uid, ep, params=None, ttl=0):
        if "exam" in ep:
            d = (dt.datetime.now(TZ).date() + dt.timedelta(days=5)).isoformat()
            return {"data": [{"date": d, "subject": "Fizika"}]}, "ok"
        return {"data": []}, "ok"

    async def safe_send(self, uid, text, kb=None):
        self.out.append((uid, text, kb))
        return True

    async def interrupted(self, message, state):
        return False

    async def edit(self, call, text, kb=None):
        self.edits.append((text, kb))

    async def ai_dialog(self, message, text, media=None, kind=None, prefs=None, history=True, uid=None):
        self.dialog_calls.append((text, media, history))

    async def media_parts(self, message):
        return [], None, None

    async def ai_quiz(self, topic, parts, n):
        items = [{"question": f"Savol {i}", "options": ["a", "b", "c", "d"], "correct": 1, "explanation": "izoh"} for i in range(n)]
        return items, 10

    def ai_slot(self, uid):
        import contextlib

        @contextlib.asynccontextmanager
        async def cm():
            yield
        return cm()

    async def w_schedule(self, request):
        return pytypes.SimpleNamespace(headers={}, uid=request["uid"])

    def user(self, uid):
        return pytypes.SimpleNamespace(id=uid, full_name=f"User {uid}", is_bot=False)

    def msg(self, uid, text=None, **kw):
        T, test = self.types, self

        class M(T.Message):
            def __init__(s):
                s.from_user, s.text, s.caption = test.user(uid), text, None
                s.photo = s.document = s.voice = None
                s.__dict__.update(kw)
                s.chat = pytypes.SimpleNamespace(id=uid)

            async def answer(s, txt, reply_markup=None, **k):
                test.out.append((uid, txt, reply_markup))
                return pytypes.SimpleNamespace(edit_text=lambda t, reply_markup=None: test.edit_out(t), delete=lambda: asyncio.sleep(0))

            async def answer_document(s, doc, caption=None, **k):
                test.docs.append((uid, doc, caption))

            async def answer_photo(s, *a, **k):
                test.docs.append((uid, a, None))
        return M()

    async def edit_out(self, t):
        self.edits.append((t, None))

    def call(self, uid, data):
        T, test = self.types, self

        class C(T.CallbackQuery):
            def __init__(s):
                s.from_user, s.data = test.user(uid), data
                s.message = test.msg(uid)
                s.alerts = []

            async def answer(s, text=None, show_alert=False, **k):
                s.alerts.append((text, show_alert))
        return C()

    class State_:
        def __init__(self):
            self.data, self.name = {}, None

        async def set_state(self, s):
            self.name = s

        async def get_data(self):
            return dict(self.data)

        async def update_data(self, **kw):
            self.data.update(kw)

        async def clear(self):
            self.data, self.name = {}, None

    def go(self, coro):
        return asyncio.run(coro)

    async def press(self, uid, data, state=None):
        st = state or self.State_()
        c = self.call(uid, data)
        await self.plus.cb_plus(c, st)
        return c, st

    def last_text(self):
        return (self.edits[-1][0] if self.edits else "") + " | " + (self.out[-1][1] if self.out else "")

    def buttons(self, kb):
        return [b.callback_data for row in kb.inline_keyboard for b in row if b.callback_data]

    # ---- testlar
    def test_registration(self):
        self.assertGreaterEqual(len(self.handlers["message"]), 30)
        self.assertEqual(len(self.handlers["callback"]), 1)
        self.assertIn("/px", self.routes)
        self.assertIn("/open/v1/{what}", self.routes)
        self.assertIn("/api/px/stats", self.routes)

    def test_menu_and_login_gate(self):
        async def f():
            st = self.State_()
            await self.plus.cmd_plus(self.msg(2, "/plus"), st)
            self.assertIn("Plus", self.out[-1][1])
            b = self.buttons(self.out[-1][2])
            self.assertIn("px:s:study", b)
            self.assertNotIn("px:adm", b)
            await self.plus.cmd_plus(self.msg(1, "/plus"), st)
            self.assertIn("px:adm", self.buttons(self.out[-1][2]))
            self.out.clear()
            await self.plus.cmd_plus(self.msg(99, "/plus"), st)
            self.assertIn("/start", self.out[-1][1])
        self.go(f())

    def test_cards_srs_flow(self):
        async def f():
            st = self.State_()
            await self.plus.h_card_add(self.msg(2, "Om qonuni | I=U/R\nFaraday | EYuK"), st)
            self.assertEqual(self.plus.cards_summary(2), (2, 2))
            await self.press(2, "px:cr")
            self.assertIn("Om qonuni", self.edits[-1][0])
            cid = self.plus.next_card(2)["id"]
            await self.press(2, f"px:cs:{cid}")
            self.assertIn("I=U/R", self.edits[-1][0])
            await self.press(2, f"px:cg:{cid}:good")
            r = self.ns["fetch_one"]("SELECT * FROM px_cards WHERE id=?", (cid,))
            self.assertEqual((r["reps"], r["interval"]), (1, 1))
            self.assertGreater(r["due"], dt.datetime.now(TZ).date().isoformat())
            self.assertEqual(self.plus.xp_stats(2)["cards_done"], 1)
            await self.press(2, "px:cdel2")
            self.assertEqual(self.plus.cards_summary(2)[0], 0)
        self.go(f())

    def test_calc_gpa_plan(self):
        async def f():
            st = self.State_()
            await self.plus.h_calc(self.msg(2, "40 50 5"), st)
            self.assertIn("46", self.out[-1][1])
            await self.plus.h_calc(self.msg(2, "abc"), st)
            self.assertIn("⚠️", self.out[-1][1])
            await self.plus.h_gpa(self.msg(2, "5x4 4x3\nmaqsad 4.5 yangi 20"), st)
            self.assertIn("GPA", self.out[-1][1])
            self.assertIn("kerak", self.out[-1][1])
            exam = (dt.datetime.now(TZ).date() + dt.timedelta(days=8)).strftime("%d.%m.%Y")
            await self.plus.h_plan(self.msg(2, f"{exam}\nMavzu1\nMavzu2, Mavzu3"), st)
            n = self.ns["fetch_one"]("SELECT COUNT(*) n FROM px_plan WHERE user_id=2")["n"]
            self.assertGreaterEqual(n, 3)
            day = dt.datetime.now(TZ).date().isoformat()
            await self.plus.send_morning_plans(day)
            self.assertTrue(any("o'qish rejasi" in t for _, t, _ in self.out))
            await self.press(2, f"px:pd:{day}")
            self.assertGreaterEqual(self.plus.xp_stats(2)["xp"], 5)
        self.go(f())

    def test_calendar_and_ics(self):
        async def f():
            self.ns["run"]("INSERT INTO reminders (user_id, text, remind_at) VALUES (2, 'Kitob qaytar', ?)",
                           ((dt.datetime.now() + dt.timedelta(days=2)).replace(microsecond=0).isoformat(),))
            evs = await self.plus.collect_events(2)
            kinds = {e["kind"] for e in evs}
            self.assertTrue({"🧪", "🔔"} <= kinds)
            await self.press(2, "px:cal")
            self.assertIn("Fizika", self.edits[-1][0])
            await self.press(2, "px:ics")
            self.assertEqual(self.docs[-1][1].filename, "hemis_kalendar.ics")
            self.assertIn(b"BEGIN:VCALENDAR", self.docs[-1][1].data)
        self.go(f())

    def test_pomodoro_start_stop(self):
        async def f():
            await self.press(2, "px:pm:25:5")
            self.assertIn(2, self.plus.POMO_TASKS)
            await asyncio.sleep(0)
            await self.press(2, "px:pomostop")
            await asyncio.sleep(0)
            self.assertNotIn(2, self.plus.POMO)
        self.go(f())

    def test_streak_levels_and_leaderboard(self):
        async def f():
            self.assertEqual(self.plus.checkin(2, "Ali Valiyev"), 1)
            self.assertIsNone(self.plus.checkin(2, "Ali Valiyev"))
            self.plus.add_xp(3, 500, "t")
            self.plus.ensure_xp(3, "Sardor Karimov")
            await self.press(2, "px:top")
            txt = self.edits[-1][0]
            self.assertLess(txt.index("Sardor"), txt.index("Ali"))
            await self.press(2, "px:vis")
            await self.press(2, "px:top")
            self.assertNotIn("Ali V.", self.edits[-1][0])
            await self.press(2, "px:me")
            self.assertIn("Daraja", self.edits[-1][0])
        self.go(f())

    def test_promo_and_gift(self):
        hub = pytypes.ModuleType("hub")
        hub.G = {"x": 1}
        hub.credits = {}

        def add_credits(uid, n):
            self.ns["run"]("INSERT OR IGNORE INTO hub_users (user_id, credits) VALUES (?, 0)", (uid,))
            self.ns["run"]("UPDATE hub_users SET credits = credits + ? WHERE user_id=?", (n, uid))
        hub.add_credits = add_credits
        hub.add_premium = lambda uid, d: None
        hub.ensure_user = lambda uid: self.ns["run"]("INSERT OR IGNORE INTO hub_users (user_id, credits) VALUES (?, 0)", (uid,))
        sys.modules["hub"] = hub
        try:
            async def f():
                st = self.State_()
                await self.plus.h_adm_promo(self.msg(2, "KOD credits 5 1"), st)  # admin emas
                self.assertIsNone(self.ns["fetch_one"]("SELECT 1 FROM px_promo"))
                await self.plus.h_adm_promo(self.msg(1, "YANGI25 credits 5 1 30"), st)
                ok, txt = self.plus.redeem(2, "yangi25")
                self.assertTrue(ok)
                self.assertEqual(self.ns["fetch_one"]("SELECT credits FROM hub_users WHERE user_id=2")[0], 5)
                self.assertFalse(self.plus.redeem(2, "YANGI25")[0])
                self.assertFalse(self.plus.redeem(3, "YANGI25")[0])  # limit 1
                self.assertEqual(self.ns["fetch_one"]("SELECT credits FROM hub_users WHERE user_id=3"), None)
                await self.plus.h_gift(self.msg(2, "4 3"), st)
                self.assertEqual(self.ns["fetch_one"]("SELECT credits FROM hub_users WHERE user_id=2")[0], 2)
                self.assertEqual(self.ns["fetch_one"]("SELECT credits FROM hub_users WHERE user_id=4")[0], 3)
                await self.plus.h_gift(self.msg(2, "4 30"), st)
                self.assertIn("yetarli", self.out[-1][1])
                self.assertEqual(self.ns["fetch_one"]("SELECT credits FROM hub_users WHERE user_id=2")[0], 2)
            self.go(f())
        finally:
            sys.modules.pop("hub", None)

    def test_groups_poll_attendance(self):
        async def f():
            st = self.State_()
            self.ns["run"]("INSERT INTO px_roles (user_id, role) VALUES (3, 'sardor')")
            await self.plus.h_grp_name(self.msg(2, "Guruh X"), st)   # sardor emas
            self.assertIsNone(self.ns["fetch_one"]("SELECT 1 FROM px_groups"))
            await self.plus.h_grp_name(self.msg(3, "Fizika-21"), st)
            g = self.ns["fetch_one"]("SELECT * FROM px_groups")
            await self.plus.h_grp_join(self.msg(2, g["code"].lower()), st)
            await self.plus.h_grp_join(self.msg(4, g["code"]), st)
            self.assertEqual(len(self.plus.members(g["id"])), 3)
            self.out.clear()
            await self.plus.a_grp_attend(self.call(3, ""), st, [str(g["id"])])
            sent = [(u, kb) for u, t, kb in self.out if "Davomat" in t]
            self.assertEqual({u for u, _ in sent}, {2, 3, 4})
            pid = self.ns["fetch_one"]("SELECT id FROM px_polls")["id"]
            await self.press(2, f"px:v:{pid}:0")
            await self.press(99, f"px:v:{pid}:0")
            await self.press(3, f"px:pr:{pid}")
            txt = self.edits[-1][0]
            self.assertIn("Keldi: <b>1</b>", txt)
            self.assertIn("Dilnoza", txt)
            await self.press(2, f"px:pr:{pid}")  # a'zo natijani ko'ra olmaydi
            self.assertEqual(self.edits[-1][0], txt)
            await self.plus.h_grp_poll(self.msg(3, "Dars bormi? | Ha | Yo'q"), self.State_())  # state'siz gid yo'q
            st2 = self.State_()
            await st2.update_data(gid=g["id"])
            await self.plus.h_grp_poll(self.msg(3, "Dars bormi? | Ha | Yo'q"), st2)
            self.assertEqual(self.ns["fetch_one"]("SELECT COUNT(*) FROM px_polls")[0], 2)
        self.go(f())

    def test_board_moderation_and_relay(self):
        async def f():
            st = self.State_()
            await st.update_data(kind="market", title="Fizika kitobi", body="Yangi holatda")
            await self.plus.h_brd_extra(self.msg(2, "25 000 so'm"), st)
            r = self.ns["fetch_one"]("SELECT * FROM px_board")
            self.assertEqual(r["status"], "pending")
            self.assertTrue(any(u == 1 and "Yangi e'lon" in t for u, t, _ in self.out))
            await self.press(4, "px:bl:market")
            self.assertIn("Hozircha e'lon yo'q", self.edits[-1][0])
            await self.press(4, f"px:mod:brd:{r['id']}:ok")   # moderator emas
            self.assertEqual(self.ns["fetch_one"]("SELECT status FROM px_board")[0], "pending")
            await self.press(1, f"px:mod:brd:{r['id']}:ok")
            self.assertEqual(self.ns["fetch_one"]("SELECT status FROM px_board")[0], "approved")
            await self.press(4, "px:bl:market")
            self.assertIn(f"px:bv:{r['id']}", self.buttons(self.edits[-1][1]))
            await self.press(4, f"px:bv:{r['id']}")
            self.assertIn(f"px:bm:{r['id']}", self.buttons(self.edits[-1][1]))
            st4 = self.State_()
            await st4.update_data(to=2, ref="E'lon", bid=r["id"])
            self.out.clear()
            await self.plus.h_relay(self.msg(4, "Hali bormi?"), st4)
            self.assertEqual(self.out[0][0], 2)
            await self.press(4, f"px:bd:{r['id']}")   # egasi emas
            self.assertIsNotNone(self.ns["fetch_one"]("SELECT 1 FROM px_board"))
            await self.press(2, f"px:bd:{r['id']}")
            self.assertIsNone(self.ns["fetch_one"]("SELECT 1 FROM px_board"))
        self.go(f())

    def test_anon_reviews_slots(self):
        async def f():
            st = self.State_()
            await self.plus.h_anon(self.msg(2, "Imtihon qachon bo'ladi, bilasizmi?"), st)
            aid = self.ns["fetch_one"]("SELECT id FROM px_anon")["id"]
            self.assertTrue(any(u == 1 and "Anonim savol" in t for u, t, _ in self.out))
            self.assertFalse(any("Ali" in t for u, t, _ in self.out if u == 1))
            sta = self.State_()
            await sta.update_data(aid=aid)
            self.out.clear()
            await self.plus.h_adm_reply(self.msg(1, "Dekanat e'lon qiladi"), sta)
            self.assertEqual(self.out[0][0], 2)
            for _ in range(3):
                await self.plus.h_anon(self.msg(2, "Yana bitta savol yozaman"), st)
            self.assertIn("limit", self.out[-1][1])
            std = self.State_()
            await std.update_data(subj="Fizika", rating=4)
            await self.plus.h_rev_comment(self.msg(2, "Yaxshi fan"), std)
            await std.update_data(subj="Fizika", rating=2)
            await self.plus.h_rev_comment(self.msg(2, "/skip"), std)   # yangilanadi, ko'paymaydi
            self.assertEqual(self.ns["fetch_one"]("SELECT COUNT(*), MAX(rating) FROM px_reviews")[:], (1, 2))
            # slot
            self.ns["run"]("INSERT INTO px_roles (user_id, role) VALUES (3, 'teacher')")
            d = (dt.datetime.now(TZ).date() + dt.timedelta(days=2)).strftime("%d.%m.%Y")
            await self.plus.h_slot_note(self.msg(3, f"{d} 15:00 Kurs ishi"), self.State_())
            sid = self.ns["fetch_one"]("SELECT id FROM px_slots")["id"]
            await self.plus.h_slot_note(self.msg(2, f"{d} 16:00"), self.State_())   # o'qituvchi emas
            self.assertEqual(self.ns["fetch_one"]("SELECT COUNT(*) FROM px_slots")[0], 1)
            await self.press(2, f"px:sb:{sid}")
            await self.press(4, f"px:sb:{sid}")   # band
            self.assertEqual(self.ns["fetch_one"]("SELECT student FROM px_slots")[0], 2)
            c, _ = await self.press(4, f"px:sb:{sid}")
            self.assertTrue(c.alerts and c.alerts[0][1])
            evs = await self.plus.collect_events(2)
            self.assertTrue(any(e["kind"] == "🕒" for e in evs))
        self.go(f())

    def test_duel(self):
        async def f():
            st = self.State_()
            await self.plus.h_duel_topic(self.msg(2, "Faraday"), st)
            d = self.ns["fetch_one"]("SELECT * FROM px_duels")
            await self.plus.h_duel_join(self.msg(2, d["code"]), self.State_())   # o'zi
            self.assertIsNone(self.ns["fetch_one"]("SELECT p2 FROM px_duels")[0])
            await self.plus.h_duel_join(self.msg(4, d["code"]), self.State_())
            for q in range(5):
                await self.press(2, f"px:dq:{d['id']}")
                await self.press(2, f"px:da:{d['id']}:{q}:1")    # to'g'ri
                await self.press(2, f"px:da:{d['id']}:{q}:1")    # takror - hisobga olinmaydi
            self.out.clear()
            for q in range(5):
                await self.press(4, f"px:da:{d['id']}:{q}:0")    # noto'g'ri
            r = self.ns["fetch_one"]("SELECT * FROM px_duels")
            self.assertEqual((r["s1"], r["s2"], r["d1"], r["d2"]), (5, 0, 5, 5))
            res = [t for u, t, _ in self.out if "Duel natijasi" in t]
            self.assertEqual(len(res), 2)
            self.assertEqual(self.plus.xp_stats(2)["xp"] >= 20, True)
        self.go(f())

    def test_export_delete(self):
        async def f():
            self.plus.add_xp(2, 10, "t")
            await self.plus.h_card_add(self.msg(2, "A | B"), self.State_())
            self.ns["run"]("INSERT INTO notes (user_id, text) VALUES (2, 'qayd')")
            await self.press(2, "px:export")
            data = json.loads(self.docs[-1][1].data)
            self.assertEqual(len(data["px_cards"]), 1)
            self.assertNotIn("eyJ-token-2", json.dumps(data))
            await self.press(2, "px:del2")
            for t, c in (("users", "user_id"), ("px_cards", "user_id"), ("px_xp", "user_id"), ("notes", "user_id")):
                self.assertEqual(self.ns["fetch_one"](f"SELECT COUNT(*) FROM {t} WHERE {c}=2")[0], 0, t)
            self.assertEqual(self.ns["fetch_one"]("SELECT COUNT(*) FROM users WHERE user_id=3")[0], 1)
        self.go(f())

    def test_api_key_and_open_api(self):
        async def f():
            await self.press(2, "px:apin")
            key = self.out[-1][1].split("<code>")[1].split("</code>")[0]
            self.assertTrue(key.startswith("hk_"))
            self.assertNotIn(key, self.ns["fetch_one"]("SELECT key_hash FROM px_apikeys WHERE user_id=2")[0])
            handler = self.routes["/open/v1/{what}"]

            def req(what, k):
                class Rq(dict):
                    headers = {"X-API-Key": k}
                    match_info = {"what": what}
                return Rq()
            resp = await handler(req("schedule", key))
            self.assertEqual(resp.uid, 2)
            with self.assertRaises(Exception) as cm:
                await handler(req("schedule", "hk_wrong"))
            self.assertEqual(cm.exception.status, 401)
            with self.assertRaises(Exception) as cm:
                await handler(req("nope", key))
            self.assertEqual(cm.exception.status, 404)
            for _ in range(29):
                await handler(req("schedule", key))
            with self.assertRaises(Exception) as cm:
                await handler(req("schedule", key))
            self.assertEqual(cm.exception.status, 429)
            stats = self.routes["/api/px/stats"]
            with self.assertRaises(Exception) as cm:
                await stats({"uid": 2})
            self.assertEqual(cm.exception.status, 403)
            out = await stats({"uid": 1})
            self.assertEqual(out["json"]["users"], 4)
            self.assertEqual(len(out["json"]["series"]["new"]), 30)
        self.go(f())

    def test_ai_studio(self):
        async def f():
            st = self.State_()
            await self.press(2, "px:ai:simple", st)
            await st.update_data(tool="simple")
            await self.plus.h_ai_in(self.msg(2, "Faraday qonuni"), st)
            text, media, hist = self.dialog_calls[-1]
            self.assertIn("Faraday qonuni", text)
            self.assertFalse(hist)
            st2 = self.State_()
            await st2.update_data(tool="doc")
            await self.plus.h_ai_in(self.msg(2, "x" * 300), st2)
            self.assertIn(2, self.plus.DOC_MEM)
            await self.plus.h_docchat(self.msg(2, "Asosiy g'oya nima?"), st2)
            self.assertIn("Faqat yuqoridagi hujjatga", self.dialog_calls[-1][0])
            self.plus.DOC_MEM[2] = (0, [])
            await self.plus.h_docchat(self.msg(2, "yana"), st2)
            self.assertIn("muddati", self.out[-1][1])
        self.go(f())

    def test_maintenance_backup_tokens_stats(self):
        async def f():
            self.assertEqual(self.plus.plain_token_count(), 4)
            n, err = self.plus.migrate_tokens()
            self.assertEqual((n, err), (4, None))
            self.assertEqual(self.plus.plain_token_count(), 0)
            tok = self.ns["fetch_one"]("SELECT token FROM users WHERE user_id=2")[0]
            self.assertTrue(tok.startswith("enc:"))
            self.assertEqual(self.fernet.decrypt(tok[4:].encode()).decode(), "eyJ-token-2")
            self.assertEqual(self.plus.migrate_tokens()[0], 0)
            self.plus.BACKUP_DIR = os.path.join(self.tmp, "bk")
            p = self.plus.make_backup()
            self.assertTrue(os.path.exists(p))
            chk = sqlite3.connect(p)
            self.assertEqual(chk.execute("SELECT COUNT(*) FROM users").fetchone()[0], 4)
            chk.close()
            self.ns["run"]("INSERT INTO px_board (kind, title, body, extra, owner, status, created, expires) VALUES ('lost','x','y','z',2,'approved','2020-01-01T00:00:00','2020-01-02T00:00:00')")
            self.plus.cleanup()
            self.assertIsNone(self.ns["fetch_one"]("SELECT 1 FROM px_board"))
            h = self.plus.health_info()
            self.assertEqual(h["plain_tokens"], 0)
            await self.press(1, "px:ast")
            self.assertIn("Statistika", self.edits[-1][0])
            c, _ = await self.press(2, "px:ae")   # admin emas -> hech narsa
            self.assertEqual(self.plus.plain_token_count(), 0)
        self.go(f())


if __name__ == "__main__":
    unittest.main()
