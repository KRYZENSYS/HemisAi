# -*- coding: utf-8 -*-
"""
aimode.py - "AI avto-javob": Telethon (userbot) orqali SHAXSIY Telegram akkauntingizga yozganlarga
sun'iy intellekt (Gemini / Groq / OpenRouter / istalgan OpenAI-mos API) javob beradi.
Hammasi Admin Panel -> «🤖 AI avto-javob» (/aimode) ichidagi inline tugmalar orqali boshqariladi.

Ulash: patch_aimode.py ni ishga tushiring (yoki qo'lda: hemis3.py da  `import aimode as _aimode;
_aimode.setup(globals())`  va main() da  `_aimode.start()`). Admin paneldagi tugma callback'i: "am:menu".
Eslatma: hemis3.py da "ai:" prefiksi va /ai buyrug'i bot ichidagi Gemini yordamchiga tegishli, shuning uchun
bu modul "am:" prefiksi va /aimode buyrug'ini ishlatadi. Uyqu rejimi (sleepmode) faol bo'lganda bu modul
javob bermaydi (ikki marta javob ketmasligi uchun).
Kerak:  pip install telethon aiohttp
"""
import asyncio
import collections
import json
import logging
import random
import re
import sys
import time
from contextlib import closing

import aiohttp
from aiogram import F, types
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

try:
    from telethon import TelegramClient, events
    from telethon.errors import (FloodWaitError, PasswordHashInvalidError, PhoneCodeExpiredError,
                                 PhoneCodeInvalidError, PhoneNumberInvalidError, SessionPasswordNeededError)
    from telethon.sessions import StringSession
    HAS_TELETHON = True
except ImportError:  # modul baribir yuklanadi, panel o'rnatish yo'riqnomasini ko'rsatadi
    HAS_TELETHON = False

NEEDED = ["dp", "bot", "ADMIN_ID", "is_admin", "esc", "now", "fetch_one", "fetch_all", "run", "insert",
          "safe_send", "interrupted", "edit", "enc", "dec", "db"]
G = {}

DEFAULT_SYSTEM = (
    "Sen {owner}ning shaxsiy AI yordamchisisan va Telegram'da unga yozganlarga u nomidan javob berasan. "
    "Qisqa, do'stona va aniq yoz. Foydalanuvchi qaysi tilda yozsa, shu tilda javob ber. "
    "Agar kimdir sendan odammisan yoki bot deb jiddiy so'rasa, AI yordamchi ekaningni ayt. "
    "Pul o'tkazish, parol, kod yoki shaxsiy ma'lumot haqida va'da berma va so'rama; bunday masalalarda "
    "{owner} o'zi javob berishini ayt. Bilmagan narsangni o'ylab topma. Bugun: {date}, vaqt: {time}."
)

D = {
    "enabled": "1", "api_id": "", "api_hash": "", "session": "",
    "provider": "gemini",
    "gemini_key": "", "gemini_model": "gemini-2.5-flash",
    "groq_key": "", "groq_model": "llama-3.3-70b-versatile",
    "openrouter_key": "", "openrouter_model": "meta-llama/llama-3.3-70b-instruct:free",
    "custom_key": "", "custom_model": "", "custom_url": "",
    "system": DEFAULT_SYSTEM,
    "temp": "0.7", "history": "10", "contacts": "all", "rate": "20", "typing": "1",
    "delay": "2", "pause": "30", "maxchars": "600", "notify": "0", "disclose": "0",
}
PROV = {"gemini": "Gemini", "groq": "Groq", "openrouter": "OpenRouter", "custom": "OpenAI-mos (custom)"}
OPENAI_BASE = {"groq": "https://api.groq.com/openai/v1", "openrouter": "https://openrouter.ai/api/v1"}

CLIENT = None
ME = None
TASKS = set()
RATE = collections.deque()
LOCKS = set()          # hozir javob tayyorlanayotgan foydalanuvchilar
PENDING = set()        # javob kutayotgan (yangi xabar yozgan) foydalanuvchilar
SENDING = set()        # AI hozir yozayotgan chatlar (o'z xabarini "qo'lda yozdi" deb o'ylamaslik uchun)
OWN_IDS = collections.deque(maxlen=500)
PAUSE = {}             # user_id -> pauza tugash vaqti (egasi qo'lda yozganda)
LOGIN = {}
LAST_ERR = {"t": 0.0}


class AmStates(StatesGroup):
    api_id = State()
    api_hash = State()
    phone = State()
    password = State()
    system = State()
    key = State()
    model = State()
    url = State()
    vip_add = State()
    test = State()


class AIError(Exception):
    pass


# ======================================================================
# Sozlama va baza
# ======================================================================
def init_tables():
    with closing(G["db"]()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS ai_cfg (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS ai_hist (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, role TEXT, text TEXT, ts REAL);
        CREATE INDEX IF NOT EXISTS ai_hist_u ON ai_hist (user_id, id);
        CREATE TABLE IF NOT EXISTS ai_vip (user_id INTEGER PRIMARY KEY, name TEXT, kind TEXT DEFAULT 'vip');
        CREATE TABLE IF NOT EXISTS ai_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT,
                                           inbound TEXT, outbound TEXT, ts REAL);
        """)
        conn.commit()


def cfg(k):
    r = G["fetch_one"]("SELECT value FROM ai_cfg WHERE key=?", (k,))
    v = r["value"] if r and r["value"] is not None else D.get(k, "")
    if not v and k in ("api_id", "api_hash"):
        # Uyqu rejimida (sleepmode) allaqachon kiritilgan bo'lsa, qayta so'ramaymiz
        try:
            r2 = G["fetch_one"]("SELECT value FROM sl_cfg WHERE key=?", (k,))
            v = (r2["value"] if r2 and r2["value"] else "") or v
        except Exception:
            pass
    return v


def cset(k, v):
    G["run"]("INSERT INTO ai_cfg (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


def cflt(k):
    try:
        return float(cfg(k))
    except ValueError:
        return 0.0


def flip(k):
    cset(k, "0" if cfg(k) == "1" else "1")


def esc_(s):
    return G["esc"](str(s))


def get_key(p):
    v = cfg(p + "_key")
    return (G["dec"](v) or "") if v else ""


def notify_admin(text, kb=None):
    return G["safe_send"](G["ADMIN_ID"], text, kb) if kb else G["safe_send"](G["ADMIN_ID"], text)


def spawn(coro):
    t = asyncio.create_task(coro)
    TASKS.add(t)
    t.add_done_callback(TASKS.discard)


def sleep_active():
    """Uyqu rejimi (sleepmode.py) hozir uxlayotgan bo'lsa True: o'sha javob beradi, AI aralashmaydi."""
    try:
        mod = sys.modules.get("sleepmode")
        return bool(mod and mod.sleep_state()[0])
    except Exception:
        return False


def owner_name():
    return (ME.first_name if ME and ME.first_name else "egam")


def system_prompt():
    n = G["now"]()
    s = (cfg("system") or DEFAULT_SYSTEM)
    for k, v in (("{owner}", owner_name()), ("{date}", f"{n:%d.%m.%Y}"), ("{time}", f"{n:%H:%M}")):
        s = s.replace(k, v)
    return s + f"\nJavobni {int(cflt('maxchars'))} belgidan oshirma. Markdown belgilarini (*, #, `) ishlatma."


# ======================================================================
# AI provayderlar
# ======================================================================
def _err_text(data):
    try:
        e = data.get("error")
        if isinstance(e, dict):
            return str(e.get("message", e))[:160]
        return str(e or data)[:160]
    except Exception:
        return str(data)[:160]


async def ai_complete(msgs, system):
    """msgs: [[role('user'|'model'), text], ...] -> javob matni."""
    p = cfg("provider")
    key, model = get_key(p), cfg(p + "_model")
    if not key:
        raise AIError(f"{PROV[p]} uchun API kalit kiritilmagan")
    if not model:
        raise AIError(f"{PROV[p]} uchun model nomi kiritilmagan")
    temp = cflt("temp")
    timeout = aiohttp.ClientTimeout(total=45)
    async with aiohttp.ClientSession(timeout=timeout) as s:
        if p == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
            body = {
                "systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": r, "parts": [{"text": t}]} for r, t in msgs],
                "generationConfig": {"temperature": temp, "maxOutputTokens": 2048},
            }
            async with s.post(url, json=body, headers={"x-goog-api-key": key}) as r:
                data = await r.json(content_type=None)
                if r.status != 200:
                    raise AIError(f"Gemini {r.status}: {_err_text(data)}")
            cands = data.get("candidates") or []
            parts = ((cands[0].get("content") or {}).get("parts") or []) if cands else []
            text = "".join(x.get("text", "") for x in parts if not x.get("thought"))
        else:
            base = cfg("custom_url").rstrip("/") if p == "custom" else OPENAI_BASE[p]
            if not base:
                raise AIError("Custom provayder uchun API manzil (base URL) kiritilmagan")
            body = {
                "model": model, "temperature": temp, "max_tokens": 1024,
                "messages": [{"role": "system", "content": system}]
                            + [{"role": "user" if r == "user" else "assistant", "content": t} for r, t in msgs],
            }
            async with s.post(base + "/chat/completions", json=body, headers={"Authorization": f"Bearer {key}"}) as r:
                data = await r.json(content_type=None)
                if r.status != 200:
                    raise AIError(f"{PROV[p]} {r.status}: {_err_text(data)}")
            ch = data.get("choices") or []
            text = ((ch[0].get("message") or {}).get("content") or "") if ch else ""
    text = (text or "").strip()
    if not text:
        raise AIError("AI bo'sh javob qaytardi")
    return text


# ======================================================================
# Suhbat tarixi
# ======================================================================
def save_hist(uid, role, text):
    G["run"]("INSERT INTO ai_hist (user_id, role, text, ts) VALUES (?,?,?,?)", (uid, role, text[:2000], time.time()))


def load_hist(uid):
    n = max(2, int(cflt("history")) or 10)
    rows = list(reversed(G["fetch_all"]("SELECT role, text FROM ai_hist WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, n))))
    out = []
    for r in rows:
        role = "user" if r["role"] == "user" else "model"
        if out and out[-1][0] == role:
            out[-1][1] += "\n" + r["text"]
        else:
            out.append([role, r["text"]])
    while out and out[0][0] != "user":
        out.pop(0)
    return out


def list_kind(uid):
    r = G["fetch_one"]("SELECT kind FROM ai_vip WHERE user_id=?", (uid,))
    return r["kind"] if r else None


# ======================================================================
# Telethon: ulanish va javob berish
# ======================================================================
async def connect_saved():
    global CLIENT, ME
    if not HAS_TELETHON or not (cfg("api_id") and cfg("api_hash") and cfg("session")):
        return False
    sess = G["dec"](cfg("session"))
    if not sess:
        logging.error("AI rejimi: sessiyani ochib bo'lmadi (ENCRYPTION_KEY o'zgargan bo'lishi mumkin).")
        return False
    if CLIENT:
        try:
            await CLIENT.disconnect()
        except Exception:
            pass
    c = TelegramClient(StringSession(sess), int(cfg("api_id")), cfg("api_hash"), device_model="AI Assistant", app_version="1.0")
    await c.connect()
    if not await c.is_user_authorized():
        await c.disconnect()
        return False
    c.add_event_handler(on_msg, events.NewMessage(incoming=True))
    c.add_event_handler(on_own, events.NewMessage(outgoing=True))
    CLIENT, ME = c, await c.get_me()
    logging.info("AI rejimi: akkaunt ulandi (%s)", ME.first_name)
    return True


async def on_msg(event):
    try:
        await handle_msg(event)
    except Exception:
        logging.exception("AI rejimi: xabarni qayta ishlashda xato")


async def on_own(event):
    """Egasi qo'lda yozsa: suhbatga qo'shamiz va shu odam uchun AI'ni vaqtincha to'xtatamiz."""
    try:
        if not event.is_private or event.chat_id in SENDING or event.id in OWN_IDS:
            return
        text = (event.raw_text or "").strip()
        if text:
            save_hist(event.chat_id, "model", text)
        pm = int(cflt("pause"))
        if pm > 0:
            PAUSE[event.chat_id] = time.time() + pm * 60
    except Exception:
        logging.exception("AI rejimi: o'z xabarini qayta ishlashda xato")


async def handle_msg(event):
    if not event.is_private or event.out or cfg("enabled") != "1":
        return
    if sleep_active():
        return
    sender = await event.get_sender()
    if (not sender or getattr(sender, "bot", False) or getattr(sender, "is_self", False)
            or getattr(sender, "deleted", False) or sender.id in (777000, 42777)):
        return
    uid = sender.id
    name = " ".join(x for x in (getattr(sender, "first_name", ""), getattr(sender, "last_name", "")) if x) or str(uid)
    kind = list_kind(uid)
    if kind == "ignore":
        return
    text = (event.raw_text or "").strip()[:2000] or ("[foydalanuvchi media yubordi]" if event.media else "")
    if not text:
        return
    save_hist(uid, "user", text)
    if kind == "vip":
        await notify_admin(f"⭐ <b>VIP</b> yozdi: {esc_(name)}\n{esc_(text[:200])}")
        G["insert"]("INSERT INTO ai_log (user_id, name, inbound, outbound, ts) VALUES (?,?,?,?,?)", (uid, name, text[:300], "", time.time()))
        return
    mode, contact = cfg("contacts"), bool(getattr(sender, "contact", False))
    if (mode == "noncontacts" and contact) or (mode == "contacts" and not contact):
        return
    if PAUSE.get(uid, 0) > time.time():
        return
    PENDING.add(uid)
    if uid in LOCKS:
        return
    LOCKS.add(uid)
    try:
        for _ in range(3):
            if uid not in PENDING:
                break
            t = time.time()
            while RATE and t - RATE[0] > 60:
                RATE.popleft()
            if len(RATE) >= max(1, int(cflt("rate"))):
                PENDING.discard(uid)
                break
            RATE.append(t)
            if not await ai_reply(sender, uid, name, text):
                break
    finally:
        LOCKS.discard(uid)


async def ai_reply(peer, uid, name, last_text):
    """AI javobini tayyorlab yuboradi. Muvaffaqiyatli bo'lsa True."""
    delay = cflt("delay")

    async def work():
        if delay > 0:
            await asyncio.sleep(random.uniform(delay * 0.5, delay * 1.5))
        PENDING.discard(uid)
        hist = load_hist(uid)
        if not hist or hist[-1][0] != "user":
            return None
        return await ai_complete(hist, system_prompt())

    try:
        if cfg("typing") == "1":
            async with CLIENT.action(peer, "typing"):
                reply = await work()
        else:
            reply = await work()
    except Exception as ex:
        logging.warning("AI rejimi: javob olinmadi: %s", ex)
        if time.time() - LAST_ERR["t"] > 120:
            LAST_ERR["t"] = time.time()
            await notify_admin(f"⚠️ <b>AI xatosi</b> ({esc_(PROV[cfg('provider')])}): {esc_(str(ex)[:250])}")
        return False
    if not reply:
        return False
    reply = ("🤖 " if cfg("disclose") == "1" else "") + reply[:3500]
    SENDING.add(uid)
    try:
        msg = await CLIENT.send_message(peer, reply)
        OWN_IDS.append(msg.id)
    finally:
        await asyncio.sleep(0.5)
        SENDING.discard(uid)
    save_hist(uid, "model", reply)
    G["insert"]("INSERT INTO ai_log (user_id, name, inbound, outbound, ts) VALUES (?,?,?,?,?)",
                (uid, name, last_text[:300], reply[:300], time.time()))
    if cfg("notify") == "1":
        await notify_admin(f"🤖 <b>{esc_(name)}</b>:\n{esc_(last_text[:150])}\n↩️ {esc_(reply[:200])}")
    return True


async def ai_loop():
    await asyncio.sleep(5)
    last_clean = 0.0
    while True:
        try:
            if HAS_TELETHON and CLIENT is None and cfg("session"):
                await connect_saved()
            if time.time() - last_clean > 3600:
                last_clean = time.time()
                G["run"]("DELETE FROM ai_hist WHERE ts < ?", (time.time() - 7 * 86400,))
                G["run"]("DELETE FROM ai_log WHERE ts < ?", (time.time() - 14 * 86400,))
                for k in [k for k, v in PAUSE.items() if v < time.time()]:
                    PAUSE.pop(k, None)
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception("AI rejimi tsikli xatosi")
        await asyncio.sleep(30)


# ======================================================================
# Panel (inline tugmalar)
# ======================================================================
def B(text, data=None, url=None):
    return InlineKeyboardButton(text=text, url=url) if url else InlineKeyboardButton(text=text, callback_data=data)


def KB(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def onoff(k):
    return "✅" if cfg(k) == "1" else "❌"


def today_stats():
    t0 = G["now"]().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    r = G["fetch_one"]("SELECT COUNT(DISTINCT user_id) u, COALESCE(SUM(outbound<>''),0) r FROM ai_log WHERE ts>=?", (t0,))
    return r["u"], r["r"]


def is_premium_acc():
    return bool(ME and getattr(ME, "premium", False))


def acc_line():
    if not HAS_TELETHON:
        return "⚠️ Telethon o'rnatilmagan (<code>pip install telethon</code>)"
    if CLIENT and ME:
        nm = esc_(" ".join(x for x in (ME.first_name, ME.last_name) if x) or "akkaunt")
        un = f" @{ME.username}" if ME.username else ""
        return f"✅ {nm}{un}"
    return "❌ Ulanmagan" + (" (saqlangan sessiya bor, ulanmoqda…)" if cfg("session") else "")


def v_main():
    p = cfg("provider")
    hol = "🟢 <b>AI yoqilgan</b>" if cfg("enabled") == "1" else "⛔ <b>AI o'chirilgan</b>"
    u, r = today_stats()
    t = (f"🤖 <b>AI avto-javob</b>\n\n{hol}\n👤 Akkaunt: {acc_line()}\n"
         f"🧠 Provayder: <b>{PROV[p]}</b> · <code>{esc_(cfg(p + '_model') or '—')}</code> · kalit: {'✅' if get_key(p) else '❌'}\n"
         f"📊 Bugun: yozganlar <b>{u}</b>, AI javoblari <b>{r}</b>")
    rows = [
        [B(f"AI: {onoff('enabled')}", "am:sw:enabled"), B("🧪 Sinash", "am:tst")],
        [B("🧠 AI provayder", "am:prov"), B("📝 Prompt (xarakter)", "am:sys")],
        [B("👥 Filtrlar / VIP", "am:fl"), B("📊 Hisobot", "am:rp")],
        [B("⚙️ Sozlamalar", "am:set"), B("🔐 Akkaunt", "am:acc")],
        [B("⬅️ Admin panel", "admin_back")],
    ]
    return t, KB(rows)


def v_prov():
    p = cfg("provider")
    t = (f"🧠 <b>AI provayder</b>\n\nTanlangan: <b>{PROV[p]}</b>\nModel: <code>{esc_(cfg(p + '_model') or '—')}</code>\n"
         f"API kalit: {'✅ kiritilgan' if get_key(p) else '❌ yo`q'}")
    if p == "custom":
        t += f"\nManzil: <code>{esc_(cfg('custom_url') or '—')}</code>"
    t += "\n\n<i>Kalit shifrlangan holda saqlanadi. Model nomini istalgan vaqt o'zgartirishingiz mumkin.</i>"
    rows = [[B(("🔘 " if k == p else "⚪ ") + v + (" ✅" if get_key(k) else ""), f"am:ps:{k}")] for k, v in PROV.items()]
    rows.append([B("🔑 API kalit", f"am:pk:{p}"), B("🏷 Model", f"am:pm:{p}")])
    if p == "custom":
        rows.append([B("🌐 API manzil (base URL)", "am:pu")])
    rows.append([B("⬅️ Orqaga", "am:menu")])
    return t, KB(rows)


def v_sys():
    t = ("📝 <b>AI prompti (xarakter va qoidalar)</b>\n\n"
         f"<code>{esc_(cfg('system')[:2500])}</code>\n\n"
         "<i>O'zgaruvchilar: {owner} — ismingiz, {date}, {time}.</i>")
    rows = [[B("✏️ O'zgartirish", "am:se"), B("↩️ Standart", "am:sr")], [B("⬅️ Orqaga", "am:menu")]]
    return t, KB(rows)


CONTACT_MODES = {"all": "Hammaga", "noncontacts": "Faqat kontaktda yo'qlarga", "contacts": "Faqat kontaktlarga"}


def v_filters():
    nv = G["fetch_one"]("SELECT COUNT(*) c FROM ai_vip WHERE kind='vip'")["c"]
    ni = G["fetch_one"]("SELECT COUNT(*) c FROM ai_vip WHERE kind='ignore'")["c"]
    t = (f"👥 <b>Filtrlar</b>\n\nAI javob beradi: <b>{CONTACT_MODES[cfg('contacts')]}</b>\n\n"
         "⭐ <b>VIP</b> — AI javob bermaydi, lekin yozsa sizga darhol xabar keladi.\n"
         "🔇 <b>Ignor</b> — AI umuman e'tibor bermaydi.\n\n"
         "<i>Guruhlar, botlar va kanallarga AI hech qachon javob bermaydi.</i>")
    rows = [
        [B(f"👤 Kimga: {CONTACT_MODES[cfg('contacts')]}", "am:cm")],
        [B(f"⭐ VIP ({nv})", "am:vl:vip"), B(f"🔇 Ignor ({ni})", "am:vl:ignore")],
        [B("⬅️ Orqaga", "am:menu")],
    ]
    return t, KB(rows)


def v_vips(kind):
    rows_db = G["fetch_all"]("SELECT * FROM ai_vip WHERE kind=? ORDER BY rowid DESC LIMIT 30", (kind,))
    title = "⭐ VIP ro'yxati" if kind == "vip" else "🔇 Ignor ro'yxati"
    t = f"<b>{title}</b>\n" + ("\n".join(f"• {esc_(r['name'])} (<code>{r['user_id']}</code>)" for r in rows_db) or "Bo'sh.")
    rows = [[B(f"🗑 {r['name'][:25]}", f"am:vd:{r['user_id']}:{kind}")] for r in rows_db]
    rows.append([B("➕ Qo'shish", f"am:va:{kind}")])
    rows.append([B("⬅️ Orqaga", "am:fl")])
    return t, KB(rows)


# (kalit, nom, variantlar, birlik)
CYCLES = {
    "rate": ("🚦 Tezlik limiti", [5, 10, 20, 40], "/daq"),
    "history": ("🧵 Kontekst", [4, 10, 20, 30], " xabar"),
    "pause": ("⏸ Qo'lda yozsam AI pauza", [0, 15, 30, 60, 180], " daq"),
    "delay": ("⏱ Javob kechikishi", [0, 2, 5, 10], " s"),
    "temp": ("🌡 Ijodkorlik", [0.3, 0.7, 1.0], ""),
    "maxchars": ("📏 Javob uzunligi", [300, 600, 1000, 2000], " belgi"),
}


def cyc_label(k):
    name, _, unit = CYCLES[k]
    v = cfg(k)
    if k == "pause" and v in ("0", "0.0"):
        return f"{name}: o'chiq"
    return f"{name}: {v}{unit}"


def v_settings():
    t = ("⚙️ <b>Sozlamalar</b>\n\n<i>«Qo'lda yozsam AI pauza» — siz o'zingiz biror kishiga yozsangiz, "
         "AI shu odamga ko'rsatilgan vaqt davomida javob bermaydi.</i>")
    rows = [
        [B(f"⌨️ «Yozmoqda…» effekti: {onoff('typing')}", "am:sw:typing")],
        [B(f"🤖 Javob boshida «🤖» belgisi: {onoff('disclose')}", "am:sw:disclose")],
        [B(f"🔔 Har javob haqida menga xabar: {onoff('notify')}", "am:sw:notify")],
    ] + [[B(cyc_label(k), f"am:cy:{k}")] for k in CYCLES] + [[B("⬅️ Orqaga", "am:menu")]]
    return t, KB(rows)


def v_report():
    u, r = today_stats()
    last = G["fetch_all"]("SELECT name, inbound, outbound, ts FROM ai_log ORDER BY ts DESC LIMIT 8")
    t = f"📊 <b>Hisobot</b>\n\nBugun: <b>{u}</b> kishi yozdi, <b>{r}</b> ta AI javobi.\n\n<b>Oxirgilari:</b>\n"
    import datetime as _dt
    for x in last:
        t += (f"• {_dt.datetime.fromtimestamp(x['ts'], G['now']().tzinfo):%d.%m %H:%M} <b>{esc_(x['name'])}</b>: "
              f"{esc_((x['inbound'] or '')[:40])}{' ↩️ ' + esc_(x['outbound'][:40]) if x['outbound'] else ' ⭐'}\n")
    if not last:
        t += "Hali yo'q.\n"
    rows = [[B("🧹 Tozalash (log + suhbat xotirasi)", "am:rc")], [B("⬅️ Orqaga", "am:menu")]]
    return t, KB(rows)


def v_acc():
    t = f"🔐 <b>Akkaunt</b>\n\n{acc_line()}\n"
    if cfg("api_id"):
        t += f"API ID: <code>{esc_(cfg('api_id'))}</code>\n"
        t += "<i>(Agar Uyqu rejimida kiritilgan bo'lsa, shu API ID/HASH ishlatiladi; sessiya esa alohida.)</i>\n"
    t += ("\n<i>Sessiya shifrlangan holda bazada saqlanadi. Uni hech kimga bermang — u akkauntingizga to'liq kirish beradi. "
          "Kodni faqat tugmalar bilan kiriting (xabar qilib yozsangiz, Telegram kodni bekor qilishi mumkin).</i>")
    rows = []
    if CLIENT and ME:
        rows.append([B("🔄 Qayta ulash", "am:rl"), B("🔌 Chiqish", "am:lo")])
    else:
        rows.append([B("📱 Kirish (login)", "am:lg")])
        if cfg("session"):
            rows.append([B("🔄 Qayta ulash", "am:rl")])
    rows.append([B("🔑 API ID/HASH o'zgartirish", "am:api")])
    rows.append([B("⬅️ Orqaga", "am:menu")])
    return t, KB(rows)


def keypad(code):
    shown = " ".join(list(code) + ["•"] * max(0, 5 - len(code)))
    t = f"🔐 Telegram yuborgan kodni <b>tugmalar bilan</b> kiriting:\n\n<b>{shown}</b>"
    d = [B(str(i), f"am:kp:{i}") for i in range(1, 10)]
    rows = [d[0:3], d[3:6], d[6:9], [B("⌫", "am:kp:del"), B("0", "am:kp:0"), B("✅ Yuborish", "am:kp:ok")],
            [B("❌ Bekor", "am:kp:cancel")]]
    return t, KB(rows)


# ======================================================================
# Callback'lar
# ======================================================================
SW_VIEW = {"enabled": "menu", "typing": "set", "disclose": "set", "notify": "set"}


def view_for(name):
    return {"menu": v_main, "prov": v_prov, "sys": v_sys, "fl": v_filters, "rp": v_report,
            "set": v_settings, "acc": v_acc}[name]()


async def show(call, view):
    await G["edit"](call, view[0], view[1])


async def prompt(call, text):
    await call.message.answer(text + "\n\nBekor qilish: /cancel")


async def disconnect_account(logout=False):
    global CLIENT, ME
    if CLIENT:
        try:
            if logout:
                await CLIENT.log_out()
            else:
                await CLIENT.disconnect()
        except Exception:
            logging.exception("Akkauntni uzishda xato")
    CLIENT, ME = None, None
    if logout:
        cset("session", "")


async def cb_ai(call: types.CallbackQuery, state: FSMContext):
    if not G["is_admin"](call.from_user.id):
        return await call.answer()
    p = call.data.split(":")
    a = p[1] if len(p) > 1 else "menu"
    if a != "kp":
        await state.clear()
    if a == "noop":
        return await call.answer()
    if a in ("menu", "prov", "sys", "fl", "rp", "set", "acc"):
        await call.answer()
        return await show(call, view_for(a))
    if a == "sw" and len(p) > 2 and p[2] in SW_VIEW:
        flip(p[2])
        await call.answer("Saqlandi")
        return await show(call, view_for(SW_VIEW[p[2]]))
    if a == "cy" and len(p) > 2 and p[2] in CYCLES:
        opts = [str(x) for x in CYCLES[p[2]][1]]
        cur = cfg(p[2])
        cur = cur if cur in opts else (str(float(cur)) if cur.replace(".", "", 1).isdigit() and str(float(cur)) in opts else "")
        cset(p[2], opts[(opts.index(cur) + 1) % len(opts)] if cur in opts else opts[0])
        await call.answer()
        return await show(call, v_settings())
    # ---- provayder ----
    if a == "ps" and len(p) > 2 and p[2] in PROV:
        cset("provider", p[2])
        await call.answer("Saqlandi")
        return await show(call, v_prov())
    if a == "pk" and len(p) > 2 and p[2] in PROV:
        await call.answer()
        await state.set_state(AmStates.key)
        await state.update_data(prov=p[2])
        return await prompt(call, f"🔑 <b>{PROV[p[2]]}</b> API kalitini yuboring (xabar darhol o'chiriladi):")
    if a == "pm" and len(p) > 2 and p[2] in PROV:
        await call.answer()
        await state.set_state(AmStates.model)
        await state.update_data(prov=p[2])
        return await prompt(call, f"🏷 <b>{PROV[p[2]]}</b> model nomini yuboring.\nHozirgi: <code>{esc_(cfg(p[2] + '_model') or '—')}</code>")
    if a == "pu":
        await call.answer()
        await state.set_state(AmStates.url)
        return await prompt(call, "🌐 OpenAI-mos API manzilini yuboring (<code>/chat/completions</code> siz).\nMasalan: <code>https://api.openai.com/v1</code>")
    # ---- prompt ----
    if a == "se":
        await call.answer()
        await state.set_state(AmStates.system)
        return await prompt(call, "📝 AI uchun yangi prompt yuboring (maks. 3000 belgi).\nO'zgaruvchilar: {owner} {date} {time}")
    if a == "sr":
        cset("system", DEFAULT_SYSTEM)
        await call.answer("Standart tiklandi")
        return await show(call, v_sys())
    # ---- sinash ----
    if a == "tst":
        await call.answer()
        await state.set_state(AmStates.test)
        return await prompt(call, "🧪 Istalgan savol yuboring — AI hozirgi sozlamalar bilan javob beradi (hech kimga yuborilmaydi).")
    # ---- filtrlar ----
    if a == "cm":
        ks = list(CONTACT_MODES)
        cset("contacts", ks[(ks.index(cfg("contacts")) + 1) % len(ks)])
        await call.answer()
        return await show(call, v_filters())
    if a == "vl" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        return await show(call, v_vips(p[2]))
    if a == "va" and (p[2] if len(p) > 2 else "") in ("vip", "ignore"):
        await call.answer()
        await state.set_state(AmStates.vip_add)
        await state.update_data(kind=p[2])
        return await prompt(call, "Foydalanuvchining <b>ID</b> raqami, <b>@username</b>'i yoki undan <b>forward</b> qilingan xabarni yuboring:")
    if a == "vd" and len(p) > 3 and p[2].lstrip("-").isdigit():
        G["run"]("DELETE FROM ai_vip WHERE user_id=?", (int(p[2]),))
        await call.answer("O'chirildi")
        return await show(call, v_vips(p[3]))
    # ---- hisobot ----
    if a == "rc":
        G["run"]("DELETE FROM ai_log")
        G["run"]("DELETE FROM ai_hist")
        await call.answer("Tozalandi")
        return await show(call, v_report())
    # ---- akkaunt / login ----
    if a == "api":
        await call.answer()
        await state.set_state(AmStates.api_id)
        return await prompt(call, "🔑 <a href=\"https://my.telegram.org\">my.telegram.org</a> → API development tools → <b>api_id</b> (raqam) yuboring:")
    if a == "lg":
        if not HAS_TELETHON:
            return await call.answer("Avval o'rnating: pip install telethon", show_alert=True)
        await call.answer()
        if not (cfg("api_id") and cfg("api_hash")):
            await state.set_state(AmStates.api_id)
            return await prompt(call, "🔑 <a href=\"https://my.telegram.org\">my.telegram.org</a> → API development tools → yangi ilova yarating va <b>api_id</b> (raqam) yuboring:")
        await state.set_state(AmStates.phone)
        return await prompt(call, "📱 Telefon raqamingizni yuboring (masalan <code>+998901234567</code>):")
    if a == "rl":
        await call.answer("Ulanmoqda…")
        if HAS_TELETHON:
            await connect_saved()
        return await show(call, v_acc())
    if a == "lo":
        await call.answer()
        return await show(call, ("🔌 Akkauntdan chiqilsinmi? Sessiya Telegram'da ham tugatiladi, AI avto-javob to'xtaydi.",
                                 KB([[B("✅ Ha, chiqish", "am:loy"), B("❌ Yo'q", "am:acc")]])))
    if a == "loy":
        await disconnect_account(logout=True)
        await call.answer("Chiqildi")
        return await show(call, v_acc())
    if a == "kp":
        return await cb_keypad(call, state, p[2] if len(p) > 2 else "")
    await call.answer()


async def cb_keypad(call, state, op):
    c = LOGIN.get("client")
    if not c:
        try:
            await call.answer("Seans tugagan. Qaytadan kiring.", show_alert=True)
        except TelegramBadRequest as exc:
            msg = str(exc).lower()
            if "query is too old" in msg or "response timeout expired" in msg or "query id is invalid" in msg:
                logging.debug("AI rejimi: eskirgan callback javobi o'tkazib yuborildi.")
            else:
                raise
        return await show(call, v_acc())
    if op == "cancel":
        try:
            await c.disconnect()
        except Exception:
            pass
        LOGIN.clear()
        await call.answer()
        return await show(call, v_acc())
    if op.isdigit() and len(op) == 1:
        if len(LOGIN["code"]) < 6:
            LOGIN["code"] += op
    elif op == "del":
        LOGIN["code"] = LOGIN["code"][:-1]
    elif op == "ok":
        if len(LOGIN["code"]) < 5:
            return await call.answer("Kod to'liq emas", show_alert=True)
        try:
            await c.sign_in(LOGIN["phone"], LOGIN["code"], phone_code_hash=LOGIN["hash"])
        except SessionPasswordNeededError:
            await call.answer()
            await state.set_state(AmStates.password)
            return await call.message.answer("🔒 Ikki bosqichli parol (2FA) yoqilgan. Parolni yuboring (xabar darhol o'chiriladi):")
        except PhoneCodeInvalidError:
            LOGIN["code"] = ""
            await call.answer("❌ Kod noto'g'ri", show_alert=True)
        except PhoneCodeExpiredError:
            LOGIN.clear()
            await call.answer("Kod eskirdi. Qaytadan kiring.", show_alert=True)
            return await show(call, v_acc())
        except Exception as ex:
            await call.answer(f"Xato: {str(ex)[:150]}", show_alert=True)
        else:
            await call.answer("✅")
            return await finish_login(call.message)
    await call.answer()
    t, kb = keypad(LOGIN.get("code", ""))
    await G["edit"](call, t, kb)


async def finish_login(msg):
    c = LOGIN.get("client")
    sess = c.session.save()
    await c.disconnect()
    LOGIN.clear()
    cset("session", G["enc"](sess))
    ok = await connect_saved()
    t, kb = v_acc()
    await msg.answer(("✅ <b>Akkaunt ulandi!</b>\n\n" if ok else "⚠️ Sessiya saqlandi, lekin ulanib bo'lmadi.\n\n") + t, reply_markup=kb)


# ======================================================================
# Matnli kiritish (FSM)
# ======================================================================
async def _del(message):
    try:
        await message.delete()
    except Exception:
        pass


async def send_view(message, view):
    await message.answer(view[0], reply_markup=view[1])


async def h_api_id(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    await _del(message)
    if not t.isdigit():
        return await message.answer("api_id faqat raqam. Qayta yuboring (bekor: /cancel):")
    await state.update_data(api_id=t)
    await state.set_state(AmStates.api_hash)
    await message.answer("Endi <b>api_hash</b> (32 ta harf-raqam) yuboring:")


async def h_api_hash(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip().lower()
    await _del(message)
    if not re.fullmatch(r"[0-9a-f]{32}", t):
        return await message.answer("api_hash 32 belgili bo'lishi kerak. Qayta yuboring (bekor: /cancel):")
    d = await state.get_data()
    cset("api_id", d.get("api_id", ""))
    cset("api_hash", t)
    await state.set_state(AmStates.phone)
    await message.answer("✅ Saqlandi.\n📱 Endi telefon raqamingizni yuboring (<code>+998901234567</code>):")


async def h_phone(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    if not HAS_TELETHON:
        return await message.answer("Telethon o'rnatilmagan: <code>pip install telethon</code>")
    raw = re.sub(r"[^\d+]", "", message.text or "")
    phone = raw if raw.startswith("+") else "+" + raw
    await _del(message)
    try:
        c = TelegramClient(StringSession(), int(cfg("api_id")), cfg("api_hash"), device_model="AI Assistant", app_version="1.0")
        await c.connect()
        sent = await c.send_code_request(phone)
    except PhoneNumberInvalidError:
        return await message.answer("❌ Telefon raqami noto'g'ri. Qayta yuboring (bekor: /cancel):")
    except FloodWaitError as ex:
        await state.clear()
        return await message.answer(f"⏳ Telegram {ex.seconds} soniya kutishni so'radi. Keyinroq urinib ko'ring.")
    except Exception as ex:
        await state.clear()
        return await message.answer(f"❌ Xato: {esc_(str(ex)[:200])}\napi_id/api_hash to'g'riligini tekshiring (🔐 Akkaunt → API).")
    LOGIN.clear()
    LOGIN.update(client=c, phone=phone, hash=sent.phone_code_hash, code="")
    await state.clear()
    t, kb = keypad("")
    await message.answer(t, reply_markup=kb)


async def h_password(message: types.Message, state: FSMContext):
    c = LOGIN.get("client")
    pw = message.text or ""
    await _del(message)
    if not c:
        await state.clear()
        return await message.answer("Seans tugagan. Qaytadan kiring: /aimode")
    try:
        await c.sign_in(password=pw)
    except PasswordHashInvalidError:
        return await message.answer("❌ Parol noto'g'ri. Qayta yuboring (bekor: /cancel):")
    except Exception as ex:
        await state.clear()
        return await message.answer(f"❌ Xato: {esc_(str(ex)[:200])}")
    await state.clear()
    await finish_login(message)


async def h_system(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t or len(t) > 3000:
        return await message.answer("Matn bo'sh yoki juda uzun (maks. 3000 belgi). Qayta yuboring:")
    cset("system", t)
    await state.clear()
    await send_view(message, v_sys())


async def h_key(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    v = (message.text or "").strip()
    await _del(message)
    if len(v) < 8 or " " in v:
        return await message.answer("Kalit noto'g'ri ko'rinadi. Qayta yuboring (bekor: /cancel):")
    pv = (await state.get_data()).get("prov", cfg("provider"))
    cset(pv + "_key", G["enc"](v))
    await state.clear()
    await message.answer("✅ Kalit saqlandi va shifrlandi.")
    await send_view(message, v_prov())


async def h_model(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    v = (message.text or "").strip()
    if not v or len(v) > 120 or " " in v:
        return await message.answer("Model nomi noto'g'ri. Qayta yuboring (bekor: /cancel):")
    pv = (await state.get_data()).get("prov", cfg("provider"))
    cset(pv + "_model", v)
    await state.clear()
    await send_view(message, v_prov())


async def h_url(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    v = (message.text or "").strip().rstrip("/")
    if not re.fullmatch(r"https?://\S+", v):
        return await message.answer("Manzil <code>https://...</code> ko'rinishida bo'lishi kerak. Qayta yuboring:")
    cset("custom_url", v)
    await state.clear()
    await send_view(message, v_prov())


async def h_test(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    t = (message.text or "").strip()
    if not t:
        return await message.answer("Matn yuboring (bekor: /cancel):")
    wait = await message.answer("⏳ AI o'ylayapti…")
    try:
        ans = await ai_complete([["user", t[:2000]]], system_prompt())
        await wait.edit_text(f"🤖 <b>{PROV[cfg('provider')]}</b>:\n\n{esc_(ans[:3500])}")
    except Exception as ex:
        await wait.edit_text(f"❌ {esc_(str(ex)[:300])}")
    await state.clear()
    await send_view(message, v_main())


async def h_vip(message: types.Message, state: FSMContext):
    if await G["interrupted"](message, state):
        return
    kind = (await state.get_data()).get("kind", "vip")
    uid, name = None, ""
    fo = getattr(message, "forward_origin", None)
    fu = getattr(fo, "sender_user", None) or getattr(message, "forward_from", None)
    if fu:
        uid, name = fu.id, fu.full_name
    else:
        t = (message.text or "").strip()
        if re.fullmatch(r"\d{4,}", t):
            uid, name = int(t), t
        elif re.fullmatch(r"@?[A-Za-z0-9_]{4,}", t):
            if not CLIENT:
                return await message.answer("@username orqali qo'shish uchun avval akkauntni ulang yoki ID yuboring.")
            try:
                ent = await CLIENT.get_entity(t if t.startswith("@") else "@" + t)
                uid, name = ent.id, " ".join(x for x in (ent.first_name, getattr(ent, "last_name", None)) if x) or t
            except Exception:
                return await message.answer("Topilmadi. ID yoki forward qilingan xabarni yuboring.")
    if not uid:
        return await message.answer("ID, @username yoki forward qilingan xabar yuboring.")
    if CLIENT and name == str(uid):
        try:
            ent = await CLIENT.get_entity(uid)
            name = " ".join(x for x in (ent.first_name, getattr(ent, "last_name", None)) if x) or name
        except Exception:
            pass
    G["run"]("INSERT INTO ai_vip (user_id, name, kind) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, kind=excluded.kind",
             (uid, name, kind))
    await state.clear()
    await send_view(message, v_vips(kind))


async def cmd_ai(message: types.Message, state: FSMContext):
    if not G["is_admin"](message.from_user.id):
        return
    await state.clear()
    await send_view(message, v_main())


def setup(ns):
    missing = [k for k in NEEDED if k not in ns]
    if missing:
        raise RuntimeError("aimode.setup: hemis3.py da topilmadi: " + ", ".join(missing))
    G.update({k: ns[k] for k in NEEDED})
    dp = G["dp"]
    m = dp.message
    m.register(cmd_ai, Command("aimode"))
    for st, h in ((AmStates.api_id, h_api_id), (AmStates.api_hash, h_api_hash), (AmStates.phone, h_phone),
                  (AmStates.password, h_password), (AmStates.system, h_system), (AmStates.key, h_key),
                  (AmStates.model, h_model), (AmStates.url, h_url), (AmStates.vip_add, h_vip),
                  (AmStates.test, h_test)):
        m.register(h, StateFilter(st))
    dp.callback_query.register(cb_ai, F.data.startswith("am:"))
    logging.info("AI rejimi yuklandi")


def start():
    init_tables()
    if not HAS_TELETHON:
        logging.warning("AI rejimi: Telethon o'rnatilmagan (pip install telethon)")
    spawn(ai_loop())
